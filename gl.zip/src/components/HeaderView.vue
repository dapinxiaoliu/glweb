<template>
  <div>
    <div class="header">
      <div class="header-top w1200">
        <a href="/"><img src="../assets/logo.jpg" ></a>
        <a href=""><img src="../assets/tel.jpg" ></a>
      </div>
      <div class="searchbox">
        <input type="text" placeholder="搜案例、搜律师">
        <button @click="chazhao">搜索</button>
      </div>
      <div class="nav chonggou">
        <ul class="w1200">
          <li><router-link to="/">冠领首页</router-link></li>
          <li><router-link to="/yewu">全球业务</router-link></li>
          <li><router-link to="/branch">冠领机构</router-link></li>
          <li><router-link to="/tv">冠领央视</router-link></li>
          <li><router-link to="/case">胜诉案例</router-link></li>
          <li><router-link to="/newslist">冠领新闻</router-link></li>
          <li><router-link to="/lawyer">律师团队</router-link></li>
          <li><router-link to="/notice">冠领公告</router-link></li>
          <li><router-link to="/honor">冠领荣誉</router-link></li>
          <li><router-link to="/about/1497.html">关于我们</router-link></li>
        </ul>
      </div>
    </div>
    <!-- 侧边悬浮窗 -->
    <div class="xuanfu">
      <ul>
      	<li><router-link to="">
          <img src="../assets/ywicon01.png" class="xuanfushow">
          <img src="../assets/ywicon01-s.png" class="xuanfuimg">
          <strong>在线咨询</strong>
        </router-link></li>
        <li><router-link to="">
          <img src="../assets/ywicon02.png" class="xuanfushow">
          <img src="../assets/ywicon02-s.png" class="xuanfuimg">
          <strong>电话咨询</strong>
          <div class="showbox">全球咨询电话<strong>400-8789-888</strong></div>
        </router-link></li>
        <li><router-link to="">
          <img src="../assets/ywicon03.png" class="xuanfushow">
          <img src="../assets/ywicon03-s.png" class="xuanfuimg">
          <strong>官方微信</strong>
           <div class="showbox"><img src="@/assets/leftewm.jpg" ></div>
        </router-link></li>
        <li><router-link to="">
          <img src="../assets/ywicon04.png" class="xuanfushow">
          <img src="../assets/ywicon04-s.png" class="xuanfuimg">
          <strong>主任团队</strong>
        </router-link></li>
        <li class="backtop">
          <img src="../assets/ywicon05.png" >
          <strong>返回顶部</strong>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import $ from 'jquery'
export default {
  name: 'HeaderView',
  data(){
    return {

    }
  },
  methods:{
    chazhao(){
      alert('暂未开放')
    }
  },
  updated(){

  },
  mounted(){
    //返回顶部
    $('.backtop').click(function(){
      $('body,html').animate({
        scrollTop: 0
      },
      800);
      return false;
    })
     $('.chonggou li').click(function(){
        //清除所有
        localStorage.clear();
     })

  }
}
</script>

<style scope lang="scss">
  // @import 'swiper/css/swiper.min.css';
  .setcolor{
    // color: #b80816;
  }
  .xuanfu{
    width: 94px;
    height: 474px;
    position: fixed;
    right: 30px;
    top: 167px;
    z-index: 999;
    ul{
      border: 1px solid #b80816;
      box-sizing: border-box;
      border-radius: 4px;

      li:hover{
        background:  #b80816;
         overflow: inherit;
      }
      li:hover a{
        color: #fff !important;
      }
      li:hover::after{
        background: transparent;
      }
      li:hover .xuanfushow{
        opacity: 0;
        display: none;
      }
      li:hover .xuanfuimg{
        opacity: 1;
        display: block;
      }
      .xuanfuimg,.xuanfushow{
        transition: all .2s linear 0s;
      }
      li:hover .showbox{
        transform: translateX(-51%);
        opacity: 1;
        color: #333;

      }
      li:nth-child(3) .showbox{
        width: 200px;
        height: auto;
        left: -118%;
        padding: 0;
        img{
          margin: 0 auto;
          width: 100%;
        }
      }
      li.backtop{
        cursor: pointer;
        background-color: #efecec;
      }
      li.backtop:hover{
        background-color: #efecec !important;
      }
      li{
        height: 94px;
        background: #fff;
        width: 100%;
        text-align: center;
        overflow: hidden;
        border: 1px solid transparent;
        box-sizing: border-box;
        position: relative;
        transition: all .2s linear 0s;
        img{
          margin: 27px auto 10px;
        }
        .xuanfuimg{
          opacity: 0;
          display: none;
        }
        a{
          display: block;
        }
        .showbox{
            height: 94px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0px 0px 8px #d3c2b7;
            display: flex;
            align-items: center;
            flex-direction: column;
            justify-content: center;
            padding: 0 20px;
            position: absolute;
            top: 0;
            left: -100%;
            transition: all .3s linear;
            opacity: 0;
            z-index: -1;
            strong{
              display: block;
              font-size: 18px;
              font-weight: bold;
              color: #b80816;
              white-space: nowrap;
            }
        }
      }
      li:first-child::after{
          height: 0;
      }
      li:first-child{
        border-radius: 5px 5px 0 0;
        background-color: #b80816;
        .xuanfushow{
          opacity: 0;
          display: none;
        }
        .xuanfuimg{
          display: block;
          opacity: 1;
        }
        strong{
          color: #fff;
        }
      }
      li:last-child{
        border-radius: 0 0 5px 5px;
      }
      li::after{
        content: "";
        position: absolute;
        width: 56px;
        height: 1px;
        background-color: #efecec;
        bottom: 0;
        left: 50%;
        margin-left: -28px;

      }
      li:last-child:hover{
        background: #fff;

      }
      li:last-child:hover a{
         color: #333 !important;
      }

    }

  }
  .header{
    background: #fff;
    position: relative;
    .searchbox{
      position: absolute;
      top: 20%;
      left: 50%;
      margin-left: -100px;
      height: 40px;
      width: 337px;
      border: 1px solid #b80816;
      box-sizing: border-box;
      display: flex;
      button{
        font-size: 18px;
        color: #fff;
        height: 100%;
        border: none;
        flex:1;
        background: #b80816 url('../assets/chazhao.png') no-repeat 20px center;
        cursor: pointer;
        text-indent: 26px;
      }
      input{
        font-size: 18px;
        height: 100%;
        padding: 0;
        margin: 0;
        outline: none;
        border: none;
        text-indent: 10px;
        color: #999999;
        width: 237px;
      }
      ::-webkit-input-placeholder{
        font-size: 18px;
        color: #999999;
      }
    }
    .header-top{
      height: 100px;
      display: flex;
      justify-content: space-between;
      align-items: center;

    }
    .nav{
      background: #b80816;
      ul{
        height: 55px;
        line-height: 55px;
        display: flex;
        justify-content: space-around;
        li{
          display: flex;
          align-items: center;
          font-size: 20px;
          position: relative;
          a{
            color: #fff;
            display: block;
            height: 100%;
          }
          a:hover{
            color: #fff !important;
          }
          a::after{
            content: " ";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 4px;
            transition: all .2s linear 0s;
          }

          //
        }
        li a:hover::after{
          background: #fff;
        }

      }
    }

  }
</style>
