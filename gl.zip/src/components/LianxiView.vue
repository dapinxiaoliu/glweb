<template>
  <!-- 联系我们 -->
  <div class="ours w1200 combox">
    <h2>
      <strong>联系我们</strong>
    </h2>

    <div class="ourswrap">
      <div class="swiper oursrun">
        <div class="swiper-wrapper">
          <div class="swiper-slide"><router-link to="/branch/beijing.html"><img src="@/assets/ourimg01.jpg" ><p>北京冠领</p></router-link></div>
          <div class="swiper-slide"><router-link to="/branch/shanghai.html"><img src="@/assets/shanghai.jpg" ><p>上海冠领</p></router-link></div>
          <div class="swiper-slide"><router-link to="/branch/shenzhen.html"><img src="@/assets/shenzhen.jpg" ><p>深圳冠领</p></router-link></div>
          <div class="swiper-slide"><router-link to="/branch/xian.html"><img src="@/assets/xian.jpg" ><p>西安冠领</p></router-link></div>
          <div class="swiper-slide"><router-link to="/branch/kunming.html"><img src="@/assets/kunming.jpg" ><p>昆明冠领</p></router-link></div>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
      </div>
    </div>
  </div>
</template>

<script>
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  // import Swiper from 'swiper'
  // import '/swiper/swiper.css'
  // alert(Swiper)
  export default {
    name: 'LianxiView',
    data(){
      return {}
    },
    mounted(){
      //联系我们
      var swiper = new Swiper(".oursrun", {
        spaceBetween: 20,
        loop: true,
        slidesPerView: 5,
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
      });
    }
  }
</script>

<style scoped="scoped" lang="scss">

  .ours{
    h2{
      strong{
        background-image: url(../assets/icon05.jpg);
      }
    }
    .ourswrap{
      background-color: #fff;
      height: 254px;
      margin-top: 20px;
      overflow: hidden;
      display: flex;
      align-items: center;
      position: relative;
      .oursrun{
         width: 1100px;
         // overflow: hidden;
         margin: 0 auto;
      }
      .swiper-slide{
        img{
          width: 205px;
          height: 140px;
        }
        p{
          text-align: center;
          font-size: 14px;
          color: #333;
          margin-top: 10px;
          
        }
      }
    }
    .swiper-button-next,.swiper-button-prev{
      // border: 1px solid red;
      width: 48px;
      height: 254px;
      top: 8px;
      background: #fff;
      color: #999999;
    }
    .swiper-button-next:after, .swiper-button-prev:after{
      font-size: 38px;
    }
    .swiper-button-next:hover,.swiper-button-prev:hover{
      color: #b80816;
    }
    .swiper-button-next{
      right: 0;
    }
    .swiper-button-prev{
      left: 0;
    }
  }
</style>
