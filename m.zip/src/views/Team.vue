<template>
  <div class="team">
    <div class="comban">
      <img src="../assets/lawyerban.jpg" >
      <div>
        <strong>律师团队</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="teamwrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>律师团队</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="search m20">
        <p><input type="text" placeholder="请输入律师姓名" v-model="inputName"><button @click="searchName">搜索</button></p>
        <span v-if="isshow">共找到结果 <em>{{totalNum}}</em> 条</span>
      </div>
      <div class="zhiwei m20">
        <strong>按职位搜索：</strong>
        <div class="zhiweibox">
          <span @click="getZhiwei(13)">律所主任</span>
          <span @click="getZhiwei(31)">专家顾问</span>
          <span @click="getZhiwei(14)">律师团队</span>
          <span @click="getZhiwei(16)">律师助理</span>
        </div>
      </div>
      <div class="teambox">
        <ul class="m20">
        	<li v-for="item,index in lawyerData" :key="index"  >
            <router-link :to="{path:'/lawyer/'+item.id+'.html'}">
            <div class="teamboxleft"><img :src="item.thumb" ></div>
            <div class="teamboxright">
              <strong>{{item.title}}</strong>
              <div><span>{{item.zhicheng}}</span></div>
              <p>个人简介：{{item.description}}</p>
              <em>全球咨询热线：400-8789-888</em>
            </div>
            </router-link>
          </li>

        </ul>
        <div class="page" v-if="isSearch == 's'">
          <el-pagination
            background
            hide-on-single-page
            @current-change='sfenye'
            current-page=1
            layout="prev, pager, next"
            prev-text="上一页"
            next-text="下一页"
            pager-count= 5
            :page-count='lastPage'
            :key='inputName'>
          </el-pagination>
        </div>
        <div class="page" v-else-if="zhiweisearch == 's'">
          <el-pagination
            background
            hide-on-single-page
            @current-change='zhiweipage'
            current-page=1
            layout="prev, pager, next"
            prev-text="上一页"
            next-text="下一页"
            pager-count= 5
            :page-count='lastPage'
            :key='lmid'>
          </el-pagination>
        </div>
        <div class="page" v-else>
           <el-pagination
             background
             hide-on-single-page
             @current-change="compage"
             layout="prev, pager, next"
             prev-text="上一页"
             next-text="下一页"
             :page-sizes=pageSize
             :pager-count= 5
             :page-count=lastPage
             :key='morenid'>
           </el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default {
    name:'Team',
    data(){
      return{
        isshownum:0,
        zhiweisearch:'',
        isSearch:'',
        inputName:'',
        pageSize:10,
        lawyerData:[],
        lastPage:'',
        totalNum:0,
        morenid:'',
        lmid:0,
        isshow:0
      }
    },
    methods:{
      getLawyer(){
        let that = this
        that.morenid = Math.random()
        request({
          url: 'team/allteam?page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lawyerData = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[21].length
                    val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                    that.lawyerData.push(val)
                });
                // console.log(that.lawyerData);
                that.lawyerData = jsondata['data']['data']
                that.lastPage = newData['last_page']
                that.totalNum = newData['total']
              }
            }
          }]
        })
      },
      searchName(){
        let that = this
        that.isshownum = 's'
        that.zhiweisearch = ''
        that.isSearch = ''
        if(that.inputName == ''){
          that.getLawyer()
          that.isshow = 1
          return false;
        }
        that.isshow = 1
        that.isSearch = 's'
        request({
          url: '/team/sousuo?name='+that.inputName+'&page=1&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lawyerData = []
              if(jsondata['total'] == 0){
                that.loadtext = '没有数据'

              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[21].length
                    val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                    that.lawyerData.push(val)
                });
                // that.lawyerData = jsondata['data']['data']
              that.lastPage = newData['last_page']
              that.totalNum = newData['total']
              }
            }
          }]
        })
      },
      getZhiwei(lmid){
        let that = this
        that.lmid = lmid
        that.isshownum = 's'
        that.zhiweisearch = 's'
        that.isSearch = ''

        request({
          url: '/team/read?id='+lmid+'&page=1&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lawyerData = []
              if(jsondata['total'] == 0){
                that.loadtext = '没有数据'

              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[21].length
                    val['thumb'] ='http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                    that.lawyerData.push(val)
                });
                // that.lawyerData = jsondata['data']['data']
              that.pageSize = newData['per_page']
              that.lastPage = newData['last_page']
              that.totalNum = newData['total']
              that.isshow = 1
              }
            }
          }]
        })
      },
      compage(val){
        let that = this
        that.loading = true
        request({
          url: 'team/allteam?page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              // console.log(jsondata)
              that.lawyerData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  if(val['thumb'].length > 50){
                      let thumb = val['thumb'].split(':')
                      let thumblength = thumb[21].length
                      val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                  }
                  that.lawyerData.push(val)
              });
              that.lastPage = newData['last_page']
              // that.totalNum = newData['total']
            }
          }]
        })
      },
      sfenye(val){
        let that = this
        that.loading = true
        request({
          url: '/team/sousuo?name='+that.inputName+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              // console.log(jsondata)
              that.lawyerData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[21].length
                  val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                  // console.log(val);
                  that.lawyerData.push(val)
              });
              that.pageSize = newData['per_page']
              that.lastPage = newData['last_page']
            }
          }]
        })
      },
      // 职位搜索分页
      zhiweipage(val){
        let that = this
        that.loading = true
        request({
          url: '/team/read?id='+that.lmid+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              // console.log(jsondata)
              that.lawyerData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[21].length
                  val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                  // console.log(val);
                  that.lawyerData.push(val)
              });
              that.pageSize = newData['per_page']
              that.lastPage = newData['last_page']
            }
          }]
        })
      }
    },
    watch:{
      lawyerData:{
        handler(news){
          this.lawyerData = news
        }
      },
      totalNum(val){
        this.totalNum = val
      },
      isSearch(val){
      }



    },
    mounted() {
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'lawyer'){
          $(".chonggou a[href$='/lawyer']").attr('class','router-link-active')
        }
      })

      let zhiweibox = $('.zhiweibox span')
      zhiweibox.click(function(){
        $(this).addClass('curr').siblings().removeClass('curr')
        $('.teambox').hide(0,function(){
          $('.teambox').fadeIn()
        })
      })
      $('.search button').click(function(){
        $('.zhiweibox span').removeClass('curr')
      })
      this.getLawyer()
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .team{
    .curr{
      color: #b80816 !important;
      border: 1px solid #b80816 !important;
    }
    .comban{
      div{
        color: #333;
      }
    }
    .teamwrap{
      .search{
        margin-top: .25rem;
        display: flex;
        align-items: center;
        p{
          margin-right: .3rem;
          white-space: nowrap;
        }
        em{
          color: #b80816;
        }
        input{
          height: .5rem;
          box-sizing: border-box;
          border: 1px solid #b80816;
          width: 3.25rem;
          text-indent: .15rem;
          font-size: .24rem;
          line-height: .5rem;
          color: #333;
          border-radius: 0;
        }
        input::-ms-input-placeholder{
          font-size: .24rem;
        }
        button{
          width: 1.4rem;
          background: #b80816 url(../assets/chazhao.png) no-repeat .3rem center / .22rem;
          color: #fff;
          height: .5rem;
          vertical-align: bottom;
          text-indent: .3rem;
          cursor: pointer;
          font-size: .24rem;
        }
        span{
          white-space: nowrap;
          font-size: .24rem;
        }
      }
      .zhiwei{
        display: flex;
        align-items: center;
        margin-top: .25rem;
        margin-bottom: .4rem;
        justify-content: space-between;
        .zhiweibox{
          flex: 1;
          display: flex;
          justify-content: space-between;
        }
        strong{
          font-size: .26rem;
          font-weight: bold;
        }
        span{
          font-size: .24rem;
          color:#333333;
          height: .5rem;
          width: 1.3rem;
          box-sizing: border-box;
          border: 1px solid #eeeeee;
          text-align: center;
          line-height: .5rem;
          cursor: pointer;
          white-space: nowrap;
        }
      }
      .teambox{
        ul{
          li{
            margin-bottom: .25rem;
            a{
              display: flex;
              justify-content: space-between;
              .teamboxleft{
                width: 1.9rem;
              }
              .teamboxright{
                position: relative;
                width: 4.85rem;
                strong{
                  font-size: .28rem;
                  line-height: 100%;
                  margin-bottom: .15rem;
                  display: block;
                  margin-top: .05rem;
                }
                div{
                  display: flex;
                  span:first-child{
                    margin-right: .2rem;
                  }
                  span{
                    font-size: .24rem;
                    color: #7a7878;
                    display: inline-block;
                    width: 1.5rem;
                    height: .4rem;
                    background: #f9eced;
                    text-align: center;
                    line-height: .4rem;
                    border-radius: .06rem;
                  }
                }
                p{
                  font-size: .24rem;
                  line-height: .36rem;
                  margin-top: .2rem;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2;
                  overflow: hidden;
                }
                em{
                  font-size: .24rem;
                  color: #b80816;
                  display:block;
                  margin-top: .18rem;
                  background: url(../assets/dianhua.png) no-repeat left center / .24rem;
                  text-indent: .3rem;
                  white-space: nowrap;
                  position: absolute;
                  bottom: .1rem;
                }
              }
            }
          }
        }
      }
    }
  }
</style>
