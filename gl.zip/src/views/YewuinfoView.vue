<template>
  <div class="yewuinfo">
    <div class="linebanbox">
      <img src="../assets/yewuinfoline.jpg" class="autoc">
      <div class="linebanhead">
        <strong>民事诉讼</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="yewuwrap w1200">
      <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;<router-link to="/yewu">业务领域</router-link>&nbsp;>&nbsp;民商事诉讼与仲裁</div>
      <div class="yewuintro">
        <div class="yewuintrol">
          <h2>民商事诉讼与仲裁</h2>
          <div class="yewuintrowrap">
            <div class="yewuintrowraph">


            <p>以民商事法律所调整的社会关系为内容的案件或纠纷，都在民商事诉讼的涉及范畴内。</p>
            <p>冠领律师事务所素有“诉讼大所”之称，民商诉讼业务部是冠领律所大部门之一，也是一支以转职法官和资深律师为核心的“专家派”、“技术派”律师团队。</p>
            <p><strong>冠领民商诉讼部</strong>拥有律师五十多名，其中法学硕士25人、法学博士6人，20余位律师执业十年以上，其中有多名民商事审判背景的法官顾问、从事法学教育的专家教授、仲裁委仲裁员、海归律师。该部门律师已承办上千起疑难复杂民商事案件，具有丰富的办案经验和娴熟的出庭技巧。</p>
            <p>部门成员在法律理论和实务处理都有较高水平，并深入研究某一专业领域的法律理论，总结各专业领域纠纷的实务经验，可以受您委托参与国内外机构和企业的常年法律顾问。尤其是在公司纠纷、合同领域、物权争议、金融诉讼、家事/医疗领域，冠领民商诉讼律师以“专业化+团队化”的服</p>
            <p>部门成员在法律理论和实务处理都有较高水平，并深入研究某一专业领域的法律理论，总结各专业领域纠纷的实务经验，可以受您委托参与国内外机构和企业的常年法律顾问。尤其是在公司纠纷、合同领域、物权争议、金融诉讼、家事/医疗领域，冠领民商诉讼律师以“专业化+团队化”的服</p>
            <p>部门成员在法律理论和实务处理都有较高水平，并深入研究某一专业领域的法律理论，总结各专业领域纠纷的实务经验，可以受您委托参与国内外机构和企业的常年法律顾问。尤其是在公司纠纷、合同领域、物权争议、金融诉讼、家事/医疗领域，冠领民商诉讼律师以“专业化+团队化”的服</p>
            <p>部门成员在法律理论和实务处理都有较高水平，并深入研究某一专业领域的法律理论，总结各专业领域纠纷的实务经验，可以受您委托参与国内外机构和企业的常年法律顾问。尤其是在公司纠纷、合同领域、物权争议、金融诉讼、家事/医疗领域，冠领民商诉讼律师以“专业化+团队化”的服</p>
            <p>部门成员在法律理论和实务处理都有较高水平，并深入研究某一专业领域的法律理论，总结各专业领域纠纷的实务经验，可以受您委托参与国内外机构和企业的常年法律顾问。尤其是在公司纠纷、合同领域、物权争议、金融诉讼、家事/医疗领域，冠领民商诉讼律师以“专业化+团队化”的服</p>
            </div>
          </div>

          <router-link to="" class="morelink">查看更多></router-link>
        </div>
        <div class="yewuintror">
          <routerlink to="">
            <img src="../assets/yewuxgtd.jpg" >
            <strong>相关团队</strong>
          </routerlink>
        </div>
      </div>

    </div>

    <div class="yewurun">
      <strong>刑事诉讼</strong>
      <div class="yewurunbox w1200">
        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide">取保候审</div>
            <div class="swiper-slide">无罪辩护</div>
            <div class="swiper-slide">人身损害类犯罪</div>
            <div class="swiper-slide">财产损害类犯罪</div>
            <div class="swiper-slide">经济犯罪</div>
            <div class="swiper-slide">贪污贿赂犯罪</div>
            <div class="swiper-slide">公共安全犯罪</div>
          </div>
        </div>
        <div thumbsSlider="" class="swiper mySwiper2">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>婚姻家庭</h3>
               <p>北京冠领律师事务所对于婚姻家庭的纠纷有较为专业与系统的法律服务。</p>
               <p>以从事二十余年最高法院商事审判的资深法官为业务顾问，拥有二十多位在公司实务领域经验丰富的资深律师的公司纠纷事务团队，为客户提供公司治理、股东出资、股权转让、公司决议、公司设立、公司合并、上市公司收购、损害股东利益责任等纠纷的法律服务。</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>婚姻家庭</h3>
               <p>北京冠领律师事务所对于婚姻家庭的纠纷有较为专业与系统的法律服务。</p>
               <p>以从事二十余年最高法院商事审判的资深法官为业务顾问，拥有二十多位在公司实务领域经验丰富的资深律师的公司纠纷事务团队，为客户提供公司治理、股东出资、股权转让、公司决议、公司设立、公司合并、上市公司收购、损害股东利益责任等纠纷的法律服务。</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>婚姻家庭</h3>
               <p>北京冠领律师事务所对于婚姻家庭的纠纷有较为专业与系统的法律服务。</p>
               <p>以从事二十余年最高法院商事审判的资深法官为业务顾问，拥有二十多位在公司实务领域经验丰富的资深律师的公司纠纷事务团队，为客户提供公司治理、股东出资、股权转让、公司决议、公司设立、公司合并、上市公司收购、损害股东利益责任等纠纷的法律服务。</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>婚姻家庭</h3>
                <p>北京冠领律师事务所对于婚姻家庭的纠纷有较为专业与系统的法律服务。</p>
                <p>以从事二十余年最高法院商事审判的资深法官为业务顾问，拥有二十多位在公司实务领域经验丰富的资深律师的公司纠纷事务团队，为客户提供公司治理、股东出资、股权转让、公司决议、公司设立、公司合并、上市公司收购、损害股东利益责任等纠纷的法律服务。</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>婚姻家庭</h3>
                <p>北京冠领律师事务所对于婚姻家庭的纠纷有较为专业与系统的法律服务。</p>
                <p>以从事二十余年最高法院商事审判的资深法官为业务顾问，拥有二十多位在公司实务领域经验丰富的资深律师的公司纠纷事务团队，为客户提供公司治理、股东出资、股权转让、公司决议、公司设立、公司合并、上市公司收购、损害股东利益责任等纠纷的法律服务。</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>婚姻家庭</h3>
                <p>北京冠领律师事务所对于婚姻家庭的纠纷有较为专业与系统的法律服务。</p>
                <p>以从事二十余年最高法院商事审判的资深法官为业务顾问，拥有二十多位在公司实务领域经验丰富的资深律师的公司纠纷事务团队，为客户提供公司治理、股东出资、股权转让、公司决议、公司设立、公司合并、上市公司收购、损害股东利益责任等纠纷的法律服务。</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>婚姻家庭</h3>
                <p>北京冠领律师事务所对于婚姻家庭的纠纷有较为专业与系统的法律服务。</p>
                <p>以从事二十余年最高法院商事审判的资深法官为业务顾问，拥有二十多位在公司实务领域经验丰富的资深律师的公司纠纷事务团队，为客户提供公司治理、股东出资、股权转让、公司决议、公司设立、公司合并、上市公司收购、损害股东利益责任等纠纷的法律服务。</p>
              </div>
            </div>

          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
    <!-- 经典案例 -->
    <div class="jdal w1200">
      <strong>经典案例</strong>
      <div class="jdalwrap">
        <div class="jdalwrapbox">
          <ul>
          	<li><router-link to="">冠领代理河北涿州商品房预售合同纠纷案达成调冠领..</router-link></li>
          	<li><router-link to="">冠领代理河北涿州商品房预售合同纠纷案达成调冠领..</router-link></li>
          	<li><router-link to="">冠领代理河北涿州商品房预售合同纠纷案达成调冠领..</router-link></li>
          	<li><router-link to="">冠领代理河北涿州商品房预售合同纠纷案达成调冠领..</router-link></li>
          	<li><router-link to="">冠领代理河北涿州商品房预售合同纠纷案达成调冠领..</router-link></li>
          	<li><router-link to="">冠领代理河北涿州商品房预售合同纠纷案达成调冠领冠领代理河北涿州商品房预售合同纠纷案达成调冠领..</router-link></li>
          </ul>
          <router-link to="" class="morelink">查看更多></router-link>
        </div>
        <img src="../assets/anliimg.jpg" >
      </div>
    </div>

    <!-- 相关新闻 -->
    <div class="aboutnew">
      <div class="aboutnewwrap w1200">
        <strong>相关新闻</strong>
        <div class="aboutnewbox">
          <div class="aboutnewzw">
            <div class="aboutnewl"><img src="../assets/newleft.jpg" ></div>
            <ul>
            	<li><router-link to="">夫妻离婚时一方有过错，离婚抚养权该如何判定如何判定 ...</router-link><span>2021-10-23</span></li>
            	<li><router-link to="">夫妻离婚时一方有过错，离婚抚养权该如何判定如何判定 ...</router-link><span>2021-10-23</span></li>
            	<li><router-link to="">夫妻离婚时一方有过错，离婚抚养权该如何判定如何判定 ...</router-link><span>2021-10-23</span></li>
            	<li><router-link to="">夫妻离婚时一方有过错，离婚抚养权该如何判定如何判定 ...</router-link><span>2021-10-23</span></li>
            	<li><router-link to="">夫妻离婚时一方有过错，离婚抚养夫妻离婚时一方有过错，离婚权该如何判定如何判定 ...</router-link><span>2021-10-23</span></li>
            </ul>
          </div>
          <router-link to="" class="morelink">查看更多></router-link>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper/js/swiper.min.js'
  export default{
    name: 'YewuinfoView',
    data(){
      return{
        isActive: false
      }
    },
    methods:{

    },
    computed(){

    },
    mounted(){
      $(".chonggou a").attr('class','')
      if(this.$route.name == 'ywinfo'){
        $(".chonggou a[href='/yewu']").attr('class','router-link-active')
      }
      let islock = false;
      let yewuintrowraph = $('.yewuintrowraph')
      let morelink = $('.yewuintrol .morelink')
      morelink.click(function(){
        if(islock == false){
          islock = true
          $('.yewuintrowrap').animate({
            height: yewuintrowraph.height()
          },500,function(){
            morelink.html('收起更多>')
          })

        }else{
          islock = false
          $('.yewuintrowrap').animate({
            height: '268px'
          },500,function(){
            morelink.html('查看更多>')
          })

        }

      })

      var swiper = new Swiper(".mySwiper", {
        spaceBetween: 10,
        slidesPerView: 9,
        // slidesPerView: "auto",
        freeMode: true,
        watchSlidesProgress: false,
      });
      var swiper2 = new Swiper(".mySwiper2", {
        spaceBetween: 0,
        slidesPerView: 1,
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        thumbs: {
          swiper: swiper,
        },
      });
    }
  }
</script>

<style scoped="scoped" lang="scss">
  @import '/swiper/css/swiper.min.css';
  .yewuinfo{

    .yewuwrap{

      .yewuintro{
        display: flex;
        justify-content: space-between;
        .yewuintrol{
          width: 810px;
          h2{
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            position: relative;
            padding-left: 18px;
            line-height: 100%;
            margin-top: 40px;
            margin-bottom: 10px;
          }
          h2::before{
            content: "";
            width: 8px;
            height: 20px;
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: -9px;
            background-color: #b80816;

          }
          .yewuintrowrap{
            height: 268px;
            overflow: hidden;
          }
          p{
            font-size: 18px;
            color: #666666;
            text-indent: 2em;
            line-height: 28px;
            strong{
              font-weight: bold;
              color: #333;
            }
          }
          p:nth-of-type(3){
            margin-top: 12px;
          }
          a{
            margin-right: 0;
          }
        }
        .yewuintror{
          margin-top: 40px;
          position: relative;
          cursor: pointer;
          strong{
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 58px;
            color: #fff;
            width: 114px;
            border-bottom: 3px solid #fff;
            text-align: center;
            left: 50%;
            margin-left: -57px;
            padding-bottom: 5px;
            transition: all .3s linear 0s;
          }
        }
        .yewuintror:Hover strong{
          transform: scale(1.1);
          top: 55px;
        }
      }
    }
    .yewurun{
      height: 492px;
      margin-top: 60px;
      min-width: 1200px;
      background: url(../assets/yewurunbg.jpg) no-repeat center;
      overflow: hidden;
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        color: #fff;
        margin-top: 60px;
        line-height: 100%;
        margin-bottom: 40px;
      }
      .yewurunbox{
        position: relative;
        .swiper{
          width: 1100px;
          margin: 0 auto;
        }
        .mySwiper{
          // overflow: hidden;
          .swiper-wrapper{
            display: flex;
            flex-wrap: wrap;
          }
          .swiper-slide:nth-child(9){
            margin-right: 0 !important;
          }
          .swiper-slide::after{
            content: "";
            width: 20px;
            height: 20px;
            background-color: #fff;
            position: absolute;
            bottom: -35px;
            left: 50%;
            margin-left: -10px;
            transform: rotate(45deg);
            opacity: 0;
            transition: all .2s linear 0s;
          }
          .swiper-slide{
            position: relative;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            padding: 0 15px;
            white-space: nowrap;
            width: auto !important;
            height: 40px;
            background: rgba(255,255,255,.2);
            text-align: center;
            line-height: 40px;
            transition: all .3s linear 0s;
            margin-top: 10px;
          }
          .swiper-slide-thumb-active{
            background: #b80816;
          }
          .swiper-slide-thumb-active::after{
            opacity: 1;
          }
        }
        .mySwiper2{
          margin-top: 25px;
          overflow: hidden;
          .swiper-button-next, .swiper-button-prev{
            top: 62%;
            background-repeat: no-repeat;
            background-position: center;
          }
          .swiper-button-next{
            background-image: url(../assets/right.png);
          }
          .swiper-button-prev{
            background-image: url(../assets/left.png);
          }
          .swiper-button-next:Hover{
            background-image: url(../assets/right-s.png);
          }
          .swiper-button-prev:hover{
            background-image: url(../assets/left-s.png);
          }
          .swiper-button-next:after, .swiper-button-prev:after{
           content: "";
          }

          .swiper-slide{
            background: #fff;
            padding-bottom: 30px;
            .swiperbox{
              padding: 0 54px;
              h3{
                font-size: 20px;
                color: #414141;
                line-height: 100%;
                padding: 30px 0 22px 0;
                border-bottom: 1px solid #dfdfdf;
                margin-bottom: 18px;
              }
              p{
                line-height: 28px;
                font-size: 18px;
              }
            }
          }
        }
      }
    }
    .jdal{
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      .jdalwrap{
        position: relative;
        img{
          position: absolute;
          top: 51px;
          left: 615px;
          z-index: -1;
        }
        .jdalwrapbox::before{
          content: "";
          height: 35px;
          width: 16px;
          background-color: #b80816;
          position: absolute;
          top: 0;
          left: 28px;
        }
        .jdalwrapbox{
          padding-bottom: 42px;
          position: relative;
          width: 762px;
          box-shadow: 0 0 8px #d9d9d9;
          overflow: hidden;
          background: #fff;
          ul{
            margin-top: 28px;
            margin-left: 72px;
            width: 618px;

            li:before{
              content: "";
              width: 5px;
              height: 5px;
              background: #666666;
              position: absolute;
              left: 0;
              top: 50%;
              margin-top: -2.5px;

            }
            li:hover::before{
              background-color: #b80816;
            }
            li:hover{
              background-image: url(../assets/linebg-s.png);
            }
            li{
              position: relative;
              padding-bottom: 17px;
              padding-top: 17px;
              border-bottom: 1px solid #eaeaea;
              padding-left: 15px;
              line-height: 20px;
              background: url(../assets/linebg.png) no-repeat 594px center;
              a{
                font-size: 18px;
                color: #666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                padding-right: 50px;
              }
            }
          }
        }
        .morelink{
          margin-right: 70px;
        }

      }

    }
    .aboutnew{

      margin-top: 89px;
      background: url(../assets/yewunewbg.jpg) no-repeat top center;
      .aboutnewwrap{
        position: relative;
        overflow: hidden;
        height: 533px;
        strong{
          font-size: 30px;
          color: #fff;
          display: block;
          line-height: 100%;
          text-align: center;
          margin-top: 45px;
          margin-bottom: 36px;
        }
        .aboutnewbox{
          background: #fff;
          height: 420px;
          width: 100%;
          position: absolute;
          top: 110px;

          .aboutnewzw{
            display: flex;
          }
          ul{
            width: 618px;
            box-shadow: 0 0 8px #b5b5b5;
            padding: 30px 45px;
            li:hover{
              background-image: url(../assets/newicon-s.jpg);
            }
            li{
              height: 56px;
              border-bottom: 1px solid #eaeaea;
              line-height: 56px;
              display: flex;
              justify-content: space-between;
              background: url(../assets/newicon.jpg) no-repeat 3px center;
              padding-left: 31px;
              a{
                font-size: 18px;
                color: #666666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 75%;
              }
              span{
                font-size: 16px;
                color: #666666;
              }
            }
          }
        }
        .morelink{
          position: absolute;
          bottom: 35px;
          right: 0;
          margin-right: 45px;
        }
      }
    }
    .yewuline{
      margin-top: 50px;
    }
  }
</style>
