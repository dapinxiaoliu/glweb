<template>
  <div class="jigouinfo">
    <div class="linebanbox">
      <img src="@/assets/jg-line.jpg" class="autoc">
      <div class="linebanhead">
        <strong>冠领机构</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="jigouwrap w1200">
      <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;<router-link to="/branch">冠领机构</router-link>&nbsp;>&nbsp;西安冠领</div>
      <div class="yewuintro">
        <div class="yewuintrol">
          <h2>西安冠领</h2>
          <div class="yewuintrowrap">
            <div class="yewuintrowraph">
            <p>北京冠领（西安）律师事务所位于历史悠久的西安古城。冠领律所汇聚了百余名国内外知名法学院毕业的专业人才，具有坚实的理论功底和丰富的实践经验。 冠领律所专门从事公司债务纠纷、房产纠纷、合同纠纷、婚姻继承、交通事故、民间借贷、涉外诉讼和刑事辩护的专业化、团队化办案的优秀律师团队，能极大满足不同客户的法律需求，秉承“胜诉共赢”的办案理念，真正彰显了“受人之托忠人之事”的立足至本。</p>


            </div>
          </div>

          <router-link to="" class="morelink" style="display: none;">查看更多></router-link>
        </div>
        <div class="yewuintror">
          <router-link to="/lawyer">
            <img src="@/assets/yewuxgtd.jpg" >
            <strong><router-link to="/lawyer">律师团队</router-link></strong>
          </router-link>
        </div>
      </div>

    </div>
    <div class="jigouinfotypebg">
      <strong>专业领域</strong>
      <ul class="w1200">
      	<li><router-link to="/yewu/minshi.html">民事诉讼</router-link></li>
      	<li><router-link to="/yewu/gongsi.html">公司业务</router-link></li>
      	<li><router-link to="/yewu/xingshi.html">刑事诉讼</router-link></li>
      	<li><router-link to="/yewu/shangshi.html">商事业务</router-link></li>
      </ul>
    </div>
    <!-- 经典案例 -->
    <div class="jdal w1200">
      <strong>经典案例</strong>
      <div class="jdalwrap">
        <div class="jdalwrapbox" v-loading="anliloading" :element-loading-text="loadtext">
          <ul>
          	<li v-for="item,index in anliData" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
          </ul>
          <router-link to="/case/" class="morelink">查看更多></router-link>
        </div>
        <img src="@/assets/anliimg.jpg" >
      </div>
    </div>
    <!-- 相关新闻 -->
    <div class="aboutnew">
      <div class="aboutnewwrap w1200">
        <strong>相关新闻</strong>
        <div class="aboutnewbox" v-loading="newsloading" :element-loading-text="loadtext">
          <div class="aboutnewzw">
            <div class="aboutnewl"><img src="@/assets/newleft.jpg" ></div>
            <ul>
            	<li v-for="item,index in newsData" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">{{item.title}}</router-link><span>2021-10-23</span></li>
            </ul>
          </div>
          <router-link to="/newslist/" class="morelink">查看更多></router-link>
        </div>
      </div>
    </div>
    <!-- 地址 -->
    <div class="addbox w1200">
      <div class="addboxtop addboxcom">
        <div class="addboxtopl">
          <strong>联系方式</strong>
          <p>陕西省西安市雁塔区雁翔路旺座曲江K座1804室</p>
          <p>400-8789-888(24小时)</p>
        </div>
        <div class="addboxrun">
          <div class="swiper mySwiper">
            <div class="swiper-wrapper">
              <div class="swiper-slide"><img src="@/assets/xa2.jpg" ></div>
              <div class="swiper-slide"><img src="@/assets/xa1.jpg" ></div>
              <div class="swiper-slide"><img src="@/assets/xa3.jpg" ></div>
              <div class="swiper-slide"><img src="@/assets/xa4.jpg" ></div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
          </div>
        </div>
      </div>
      <div class="addboxbot addboxcom">
        <div class="addboxtopl">
          <strong>到所方式</strong>
          <p><em>自驾</em>旺座曲江K座</p>
          <p><em>地铁</em>5号线到黄渠头地铁站下车B口出站</p>
          <p><em>公交</em>公交37路、45路、128路、187路等登高路黄渠头三路口下车；公交25路、48路、111路、269路、521路等华商集团下车</p>
        </div>
        <div class="map" id="admap">
          <!-- <img src="@/assets/map.jpg" > -->
        </div>
      </div>

    </div>
    <div class="yewuline"><img src="@/assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  import {request} from '../../network/request.js'
  import GLOBAL from '../../global/global.js'
  import { BMPGL } from '../../map/map.js'
  export default{
    name: 'JigouinfoView',
    data(){
      return {
        anliData:[],
        newsData:[],
        loadtext:'数据加载中...',
        anliloading:false,
        newsloading:false,
        ak:'w1ZAZ1thAXkNOCNO5K0WCBo6dXkfMAbC'
      }
    },
    methods:{
      getBranch(){
        let that = this
        that.anliloading  = true
        that.loadtext = '数据加载中...'
        request({
          url: '/Jigou/jganli?id=4',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
              that.anliData = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.anliloading = false
                let newData = jsondata['data'];
                that.anliData = newData
              }
          }]
        })
      },
      getnews(){
        let that = this
        that.newsloading  = true
        that.loadtext = '数据加载中...'
        request({
          url: '/Jigou/jgnews?id=53',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
              that.newsData = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.newsloading = false
                let newData = jsondata['data'];
                that.newsData = newData
              }
          }]
        })
      },
      initMap() {
        // 传入密钥获取地图回调。
        BMPGL(this.ak).then((BMapGL) => {
          // 创建地图实例
          let map = new BMapGL.Map("admap");
          // 创建点坐标 axios => res 获取的初始化定位坐标
          let point = new BMapGL.Point(109.020413,34.216575)
          // 初始化地图，设置中心点坐标和地图级别
          map.centerAndZoom(point, 16)
          //开启鼠标滚轮缩放
          map.enableScrollWheelZoom(true)

          // 创建点标记
          let marker = new BMapGL.Marker(point);
          map.addOverlay(marker);
          // 创建信息窗口
          let opts = {
              width: 200,
              height: 100,
              title: '北京冠领（西安）律师事务所'
          };
          let infoWindow = new BMapGL.InfoWindow('地址：陕西省西安市雁塔区雁翔路旺座曲江K座1804室', opts);
          // 点标记添加点击事件
          marker.addEventListener('click', function () {
              map.openInfoWindow(infoWindow, point); // 开启信息窗口
          });

        })
        .catch((err)=>{
          console.log(err)
        })
      }
    },
    mounted(){
      this.getBranch()
      this.getnews()
      this.initMap()
      $(".chonggou a").attr('class','')
      if(this.$route.name == 'jginfo'){
        $(".chonggou a[href='/jigou']").attr('class','router-link-active')
      }
      let islock = false;
      let yewuintrowraph = $('.yewuintrowraph')
      let morelink = $('.yewuintrol .morelink')
      morelink.click(function(){
        if(islock == false){
          islock = true
          $('.yewuintrowrap').animate({
            height: yewuintrowraph.height()
          },500,function(){
            morelink.html('收起更多>')
          })

        }else{
          islock = false
          $('.yewuintrowrap').animate({
            height: '268px'
          },500,function(){
            morelink.html('查看更多>')
          })

        }
      })

      var swiper = new Swiper(".mySwiper", {
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .jigouinfo{
    .jigouwrap{
      .yewuintro{
        display: flex;
        justify-content: space-between;
        .yewuintrol{
          width: 810px;
          h2{
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            position: relative;
            padding-left: 18px;
            line-height: 100%;
            margin-top: 40px;
            margin-bottom: 10px;
          }
          h2::before{
            content: "";
            width: 8px;
            height: 20px;
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: -9px;
            background-color: #b80816;

          }
          .yewuintrowrap{
            height: 268px;
            overflow: hidden;
          }
          p{
            font-size: 18px;
            color: #666666;
            text-indent: 2em;
            line-height: 28px;
            strong{
              font-weight: bold;
              color: #333;
            }
          }
          p:nth-of-type(3){
            margin-top: 12px;
          }
          a{
            margin-right: 0;
          }
        }
        .yewuintror{
          margin-top: 40px;
          position: relative;
          cursor: pointer;
          strong{
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 58px;
            color: #fff;
            width: 114px;
            border-bottom: 3px solid #fff;
            text-align: center;
            left: 50%;
            margin-left: -57px;
            padding-bottom: 5px;
            transition: all .3s linear 0s;
            a,a:hover{
              color: #fff !important;
            }
          }
        }
        .yewuintror:Hover strong{
          transform: scale(1.1);
          top: 55px;
        }
      }
    }
    .jigouinfotypebg{
      height: 340px;
      margin-top: 60px;
      background: url(../../assets/jigouinfotypebg.jpg) no-repeat center;
      overflow: hidden;
      strong{
        display: block;
        text-align: center;
        font-size: 30px;
        color: #fff;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      ul{
        display: flex;
        flex-wrap: wrap;
        justify-content: flex-start;
        li:hover{
          background: #b80816;
        }
        li{
          font-size: 18px;
          font-weight: bold;
          color: #fff;
          text-align: center;
          height: 60px;
          width: 280px;
          line-height: 60px;
          background: rgba(255,255,255,.3);
          margin-bottom: 20px;
          cursor: pointer;
          transition: all .3s linear 0s;
          margin-right: 20px;
          a{
            color: #fff;
            display: block;
            width: 100%;
          }
          a:Hover{
            color: #fff!important;
          }
        }

      }
    }
    .jdal{
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      .jdalwrap{
        position: relative;
        img{
          position: absolute;
          top: 51px;
          left: 615px;
          z-index: -1;
        }
        .jdalwrapbox::before{
          content: "";
          height: 35px;
          width: 16px;
          background-color: #b80816;
          position: absolute;
          top: 0;
          left: 28px;
        }
        .jdalwrapbox{
          height: 470px;
          padding-bottom: 42px;
          position: relative;
          width: 762px;
          box-shadow: 0 0 8px #d9d9d9;
          overflow: hidden;
          background: #fff;
          ul{
            margin-top: 28px;
            margin-left: 72px;
            width: 618px;

            li:before{
              content: "";
              width: 5px;
              height: 5px;
              background: #666666;
              position: absolute;
              left: 0;
              top: 50%;
              margin-top: -2.5px;

            }
            li:hover::before{
              background-color: #b80816;
            }
            li:hover{
              background-image: url(../../assets/linebg-s.png);
            }
            li{
              position: relative;
              padding-bottom: 17px;
              padding-top: 17px;
              border-bottom: 1px solid #eaeaea;
              padding-left: 15px;
              line-height: 20px;
              background: url(../../assets/linebg.png) no-repeat 594px center;
              a{
                font-size: 18px;
                color: #666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                padding-right: 50px;
              }
            }
          }
        }
        .morelink{
          margin-right: 70px;
        }
      }
    }
    .aboutnew{
      margin-top: 89px;
      background: url(../../assets/yewunewbg.jpg) no-repeat top center;
      .aboutnewwrap{
        position: relative;
        overflow: hidden;
        height: 533px;
        strong{
          font-size: 30px;
          color: #fff;
          display: block;
          line-height: 100%;
          text-align: center;
          margin-top: 45px;
          margin-bottom: 36px;
        }
        .aboutnewbox{
          background: #fff;
          height: 420px;
          width: 100%;
          position: absolute;
          top: 110px;

          .aboutnewzw{
            display: flex;
          }
          ul{
            width: 618px;
            box-shadow: 0 0 8px #b5b5b5;
            padding: 30px 45px;
            li:hover{
              background-image: url(../../assets/newicon-s.jpg);
            }
            li{
              height: 56px;
              border-bottom: 1px solid #eaeaea;
              line-height: 56px;
              display: flex;
              justify-content: space-between;
              background: url(../../assets/newicon.jpg) no-repeat 3px center;
              padding-left: 31px;
              a{
                font-size: 18px;
                color: #666666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 75%;
              }
              span{
                font-size: 16px;
                color: #666666;
              }
            }
          }
        }
        .morelink{
          position: absolute;
          bottom: 35px;
          right: 0;
          margin-right: 45px;
        }
      }
    }
    .addbox{
      margin-top: 55px;
      .addboxtop,.addboxcom{
        display: flex;
        justify-content: space-between;
        .addboxtopl{
          height: 244px;
          width: 440px;
          background-image: linear-gradient(to right, #f9f5f2, #fff);
          background-image: -webkit-linear-gradient(to right, #f9f5f2, #fff);
          background-image: -moz-linear-gradient(to right, #f9f5f2, #fff);
          background-image: -ms-linear-gradient(to right, #f9f5f2, #fff);
          border-left: 3px solid #b80816;
          overflow: hidden;
          strong{
            font-weight: bold;
            color: #333;
            font-size: 20px;
            position: relative;
            display: block;
            margin-left: 34px;
            padding-left: 17px;
            margin-top: 35px;
            margin-bottom: 20px;
          }
          strong::after{
            content: "";
            position: absolute;
            width: 8px;
            height: 20px;
            left: 0;
            top: 3px;
            background: #b80816;
          }
          p{
            margin-left: 50px;
            font-size: 20px;
            color: #666666;
            line-height: 30px;
            background-position: left 6px;
            background-repeat: no-repeat;
            background-image: url(../../assets/mapicon.jpg);
            padding-left: 26px;
          }
          p:nth-of-type(2){
            margin-top: 8px;
            background-image: url(../../assets/telicon.jpg);
          }
        }
        .addboxrun{
          width: 600px;
          overflow: hidden;
          position: relative;
          .swiper-button-next, .swiper-button-prev{
            background-repeat: no-repeat;
            background-position: center;
          }
          .swiper-button-next{
            background-image: url(../../assets/right.png);
          }
          .swiper-button-prev{
            background-image: url(../../assets/left.png);
          }
          .swiper-button-next:Hover{
            background-image: url(../../assets/right-s.png);
          }
          .swiper-button-prev:hover{
            background-image: url(../../assets/left-s.png);
          }
          .swiper-button-next:after, .swiper-button-prev:after{
           content: "";
          }

        }
      }
      .addboxbot{
        display: flex;
        justify-content: space-between;
        margin-top: 60px;
        .addboxtopl{
          width: 525px;
          p{
            margin-top: 8px;
            em{
              margin-right: 6px;
            }
            background-position: 3px 6px;
            padding-left: 28px;
          }
          p:nth-of-type(1){
            background-image: url(../../assets/zijia.png);
            background-position: left 6px;
          }
          p:nth-of-type(2){
            background-image: url(../../assets/ditie.jpg)
          }
          p:nth-of-type(3){
            background-image: url(../../assets/gongjiao.png);
            background-position: 4px 6px;
          }
        }
      }
    }

  }
</style>
