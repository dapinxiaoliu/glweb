<template>
    <!-- footer -->
    <div class="footer">
      <div class="footertop">
          <h2>北京冠领律师事务所</h2>
          <p>全球咨询热线：400-8789-888</p>
          <p>办案监督电话：010-51077632</p>          <p>邮     编：100052</p>          <p>邮     箱：69576000@qq.com</p>          <p>办案监督电话：010-51077632</p>          <p>地     址：北京市西城区宣武门外大街庄胜广场中央办公楼5层、6层、15层、13层1309-1312</p>
          <div class="chat"><img src="../assets/chat.jpg" ><p>官方微信</p></div>
      </div>
      <div class="footerbottom">
        <p>《中华人民共和国电信与信息服务业务经营许可证》</p>
        <p>北京冠领律师事务所拆迁官网@版权所有 京ICP备14040642号-1</p>
      </div>
    </div>
</template>

<script>
</script>

<style lang="scss" scoped="scoped">
  .footer{
    background: #f3f3f3;
    overflow: hidden;
    .footertop{
      margin: .5rem .3rem 0;
      padding-bottom: .2rem;
      position: relative;
      p{
        font-size: .26rem;
        color: #666;
        line-height: .36rem;
        letter-spacing: -.005rem;
        padding: .05rem 0;
      }
      h2{
        font-size: .4rem;
        font-weight: bold;
        color: #666666;
        margin-bottom: .1rem;
      }
      .chat{
        width: 1.52rem;
        position: absolute;
        right: 0;
        top: 0;
        p{
          text-align: center;
          font-size: .26rem;
          line-height: 100%;
          margin-top: .1rem;
        }
      }
    }
    .footerbottom{
      border-top: 1px solid #d9d9d9;
      padding-top: .2rem;
      padding-bottom: .4rem;
      p{
        font-size: .26rem;
        text-align: center;
        color: #666;
        line-height: .3rem;
      }
    }
  }
</style>
