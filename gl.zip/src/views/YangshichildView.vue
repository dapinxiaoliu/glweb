<template>
  <div class="yschild">
    <div class="yschildwrap">
      <div class="yschilditem">
        <router-link :to="{path: '/yangshi/ysvideo/index.html'}">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
      <div class="yschilditem">
        <router-link to="">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
      <div class="yschilditem">
        <router-link to="">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
      <div class="yschilditem">
        <router-link to="">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
      <div class="yschilditem">
        <router-link to="">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
      <div class="yschilditem">
        <router-link to="">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
      <div class="yschilditem">
        <router-link to="">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
      <div class="yschilditem">
        <router-link to="">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮央视《法律讲堂》周旭亮央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
      <div class="yschilditem">
        <router-link to="">
          <h2><img src="../assets/fengmian.jpg" ></h2>
          <p>央视《法律讲堂》周旭亮主讲《"喜得儿子"却被骗》</p>
        </router-link>
      </div>
    </div>
    <div class="page">
        <div class="pageleft"><button>首页</button><button>上一页</button></div>
        <div class="pagemid">
          <ul class="pageul">
          	<li class="xuanzhong">1</li>
          	<li>2</li>
          	<li>3</li>
          	<li>4</li>
          	<li class="pagenull">...</li>
          	<li>8</li>
          </ul>
        </div>
        <div class="pageright"><button>下一页</button><p>共<em>8</em>页<em>12</em>条数据</p></div>
    </div>
  </div>
</template>

<script>
</script>

<style lang="scss" scoped="scoped">

  .yschild{

    .yschildwrap{
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      .yschilditem{
        box-shadow: 0 0 8px #c5c1c1;
        width: 290px;
        background: #fff;
        overflow: hidden;
        margin-bottom: 20px;
        h2{
          width: 280px;
          height: 180px;
          margin: 4px auto 0;
          overflow: hidden;

        }
        p{
          font-size: 18px;
          margin: 20px 15px;
          line-height: 28px;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
        }
      }
    }
  }
</style>
