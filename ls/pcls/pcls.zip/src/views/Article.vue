<template>
	<div class="article">
		<div class="tvwrap w12">
			<div class="tvwrapleft comborder">
				<h2 class="comtitle">
					<strong>{{lmname}}</strong>
					<span>当前位置：
					<a href="/">北京冠领律师事务所拆迁官网<em>></em> </a>
					<router-link v-if="locallink" :to="{path:breadcrumbList[0]['path']}">{{breadcrumbList[0]['name']}}<em>></em></router-link>
					
					<div @click="goback()" class="searchhide" :to="{path:breadcrumbList[0]['path']+'?id='+catid}" v-if="showmb">{{lmname}} <em>></em> </div> 
					<router-link  class="searchhide"  :to="{path:breadcrumbList[0]['path']}" v-else>{{lmname}} <em>></em></router-link>
					</span> 
				</h2>
				<div class="content">
					<h3>{{title}}</h3>
					<div class="contenttitle">
						<span>文章来源：北京冠领律师事务所</span>  
						<!-- <span>阅读：{{count}}</span>  -->
						<span>发布时间：{{arcTime}}</span>  
						<span>字体： [<em @click="changefont('b')">大</em><em @click="changefont('m')" class="active">中</em><em @click="changefont('s')">小</em>]</span>  
					</div>
					<div class="videobox" v-if="shwovideo"><video :src="videourl" controls></video></div>
					<div class="contentbox" v-html="arcHtml"></div>
				</div>
				<div class="shangxia">
					<a href="javascript:void(0)" v-if="preshow">上一篇：没有了</a>
					<router-link v-else :to="{path:lmpath+upArc.id+'.html'}" >上一篇：{{upArc.title}}</router-link>
					
					<a href="javascript:void(0)" v-if="nextshow">下一篇：没有了</a>
					<router-link v-else :to="{path:lmpath+downArc.id+'.html'}" >下一篇：{{downArc.title}}</router-link>
				</div>
				<div class="tuijian">
					<strong>相关推荐</strong>
					<ul>
						<li v-for="item,index in tuijianData" :key="item.id">
							<router-link :to="{path:lmpath+item.id+'.html'}">{{item.title}}</router-link>
						</li>
					</ul>
				</div>

			</div>
			<Aside :lmname="lmname"/>

		</div>
	</div>
</template>

<script>
	import $ from 'jquery'
	import Aside from "../components/Aside"
	import {request} from '../network/request.js'
	import GLOBAL from '../global/global.js'
	export default{
		name:'Article',
		components:{
			Aside
		},
		data(){
			return {
				arcData:[],
				arcHtml:'',
				// count:0,
				arcTime:'',
				title:'',
				catid:0,
				prenextarc:'',
				upArc:[],
				downArc:[],
				preshow: false,
				nextshow: false,
				currentUrl:'',
				prenextarc:'',
				lmpath:'',
				lmname:'',
				breadcrumbList:[],
				showmb:false,
				shwovideo:false,
				fontsize:'18px',
				locallink:true,
				tuijianurl:'',
				tuijianData:[]
				
			}
		},
		methods:{
			getArc(){
				let that = this
				let arcid = that.$route.params.id
				
				request({
					url: that.currentUrl+arcid,
					responseType: 'json',
					transformResponse:[function(data){
						let jsondata = JSON.parse(data)
						console.log(jsondata);
						
						if(jsondata['code'] == 200){
							
							that.arcData = []
							let beforeData = jsondata['data']
							// that.count = beforeData['count']
							that.title = beforeData['title']
							that.catid = beforeData['catid']
							// that.arcHtml = beforeData['content']
							that.arcHtml= beforeData['content'].replace(/\s(src=")/g, " $1http://api.guanlingls.com")
							that.arcTime = beforeData['create_time'].split(' ')[0]
							if(beforeData['video_url'] != undefined){
								that.shwovideo = true
								that.videourl = beforeData['video_url']
							}
							that.getPNArc(beforeData['id'],beforeData['catid'])
							that.getlmName(beforeData['catid'])
							that.gettuijian(beforeData['catid'])
							
						}
							
						
					}]
				})
			},
			getPNArc(id,catid){
				let that = this
				let url = that.prenextarc+id+'&catid='+catid
				request({
					url: url,
					responseType: 'json',
					transformResponse:[function(data){
						let jsondata = JSON.parse(data)
						// console.log(jsondata);
						if(jsondata['code'] == 200){
							if(jsondata['data']['down'] == null){
								that.nextshow = true
							}else{
								that.nextshow = false
								that.downArc = jsondata['data']['down']
							}
							if(jsondata['data']['up'] == null){
								that.preshow = true
							}else{
								that.preshow = false
								that.upArc = jsondata['data']['up']
							}
						}
					}]
				})
			},
			getlmName(catid){
				let that = this
				request({
					url: '/Category/read?id='+catid,
					responseType: 'json',
					transformResponse:[function(data){
						let jsondata = JSON.parse(data)
						// console.log(jsondata);
						if(jsondata['code'] == 200){
							that.lmname = jsondata['data']['name']
							// localStorage.setItem('lmname',jsondata['data']['name'])
						}
					}]
				})
			},
			goback(){
				let path = this.lmpath.substr(1,this.lmpath.length-2)
				localStorage.setItem(path+'catid',this.catid)
				this.$router.push({ path:this.lmpath+'list/index.html',query:{'id':this.catid}})
			},
			changefont(name){
				
				if(name == 'b'){
					$('.contenttitle em').eq(0).addClass('active').siblings().removeClass()
					$('.contentbox p span').animate({
						'font-size':'20px',
						'line-height':'28px !important'
					})
					
				}else if(name == 'm'){
					$('.contenttitle em').eq(1).addClass('active').siblings().removeClass()
					$('.contentbox p span').animate({
						'font-size':'16px',
						'line-height':'24px !important'
					})
					
				}else if(name == 's'){
					$('.contenttitle em').eq(2).addClass('active').siblings().removeClass()
					$('.contentbox p span').animate({
						'font-size':'14px',
						'line-height':'22px !important'
					})
				}
			},
			gettuijian(catid){
				let that = this
				request({
					url: this.tuijianurl+'/read?id='+catid+'&pgae=1&page_size=5',
					responseType: 'json',
					transformResponse:[function(data){
						let jsondata = JSON.parse(data)
						// console.log(jsondata['data']);
						if(jsondata['code'] == 200){
							that.tuijianData = []
							that.tuijianData = jsondata['data']['data']
						}
					}]
				})
			}
		},
		mounted() {
			let meta = this.$route.meta;
			if(meta && meta.parent){
				this.breadcrumbList = meta.parent
			}else{
				this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
			}
			
			// alert(this.breadcrumbList[0]['name'])
			if(this.breadcrumbList[0]['name'] == '冠领荣誉'){
				this.lmpath = '/honor/'
				this.currentUrl = '/honor/honorlist?id='
				this.prenextarc = '/honor/honornext?id='
				this.tuijianurl = '/honor/'
			}else if(this.breadcrumbList[0]['name'] == '冠领公告'){
				this.lmpath = '/noticle/'
				this.currentUrl = '/gonggao/gonggaolist?id='
				this.prenextarc = '/gonggao/gonggaonext?id='
				this.tuijianurl = '/gonggao/'
			}else if(this.breadcrumbList[0]['name'] == '冠领新闻'){
				this.lmpath = '/news/'
				this.currentUrl = '/news/newslist?id='
				this.prenextarc = '/news/newsnext?id='
				this.tuijianurl = '/news/'
			}else if(this.breadcrumbList[0]['name'] == '冠领案例'){
				this.lmpath = '/anli/'
				this.currentUrl = '/anli/anlilist?id='
				this.prenextarc = '/anli/anlinext?id='
				this.tuijianurl = '/anli/'
			}else if(this.breadcrumbList[0]['name'] == '冠领视频'){
				this.lmpath = '/tv/'
				this.currentUrl = '/video/videolist?id='
				this.prenextarc = '/video/videonext?id='
				this.tuijianurl = '/video/'
				
			}else if(this.breadcrumbList[0]['name'] == '冠领团队'){
				this.lmpath = '/team/'
				this.currentUrl = '/team/teamlist?id='
				this.prenextarc = '/team/teamnext?id='
				this.tuijianurl = '/team/'
			}else if(this.breadcrumbList[0]['name'] == '轮播图'){
				this.lmpath = '/team/'
				this.currentUrl = '/team/teamlist?id='
				this.prenextarc = '/team/teamnext?id='
				this.tuijianurl = '/team/'
			}else if(this.breadcrumbList[0]['name'] == '拆迁法规'){
				this.lmpath = '/fagui/'
				this.currentUrl = '/dayi/dayilist?id='
				this.prenextarc = '/dayi/dayinext?id='
				this.tuijianurl = '/fagui/'
			}else if(this.breadcrumbList[0]['name'] == '律师答疑'){
				this.lmpath = '/dayi/'
				this.currentUrl = '/dayi/dayilist?id='
				this.prenextarc = '/dayi/dayinext?id='
				this.tuijianurl = '/dayi/'
			}

			this.getArc()
			if(this.$route.name == 'tvhtml'){
				let id = this.$route.params.id
				this.showmb = true
			}else if(this.$route.name == 'teamhtml'){
				this.showmb = true
			}else if(this.$route.name == 'anlihtml'){
				this.showmb = true
			}else if(this.$route.name == 'honorhtml'){
				this.showmb = true
			}else if(this.$route.name == 'noticlehtml'){
				this.showmb = true
			}else if(this.$route.name == 'newshtml'){
				if(this.$route.params.id == 1677 || this.$route.params.id == 1676 || this.$route.params.id == 1675){//关于我们
					this.locallink = false
				}else{
					this.locallink = true
					this.showmb = true
				}
			}else if(this.$route.name == 'faguihtml'){
				this.showmb = true
			}else if(this.$route.name == 'dayihtml'){
				this.showmb = true
			}
	
		},
		watch:{
		  $route(to, from){
			this.getArc()
		  }
		}
	}
</script>

<style lang="scss" scoped>
.tvwrap .tvwrapleft h2.comtitle a{
	margin-right: 0;
}
.comtitle strong{
	width: auto !important;
	padding: 0 50px!important;
	font-size: 16px;
	white-space: nowrap;
	text-overflow: ellipsis;
	overflow: hidden;
	text-shadow: 0 0 1px #fff;
}
.videobox{
	width: 600px;
	background: #333;
	margin: 0 auto;
	video{
		width: 600px;
	}
}
.tvwrap{
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
    .tvwrapleft{
        width: 915px;
        background-color: #fff;
        h2.comtitle{
            justify-content: flex-start;
            strong{
                width: 220px;
                margin-left: 5px;
            }
            strong::after{
                left: 19%;
            }
            span{
                font-size: 14px;
                margin-left: 15px;
                
            }
           
        }
        .content{
            margin-top: 40px;
            padding: 0 35px;
            h3{
                text-align: center;
                font-size: 34px;
                color: #333;
                font-weight: normal;
                
            }
            .contenttitle{
                display: flex;
                justify-content: space-evenly;
                margin: 20px 0;
                border-bottom: 1px solid #eeecec;
                padding-bottom: 15px;
                span{
                    font-size: 14px;
                    color: #666666;
                    em{
                        padding: 0 2px;
                        cursor: pointer;
                        transition: color .1s linear;
                    }
                    em.active{
                        color: #c21a20;
                    }
                    em:hover{
                        color: #c21a20;
                    }
                }
            }

        }
        .shangxia{
            padding: 0 35px;
            margin-top: 60px;
            a{
                display: block;
                color: #545455;
                line-height: 40px;
                position: relative;
                text-indent: 10px;
            }
            a::after{
                content: "";
                width: 4px;
                height: 4px;
                border-radius: 50%;
                position: absolute;
                left: 0;
                top: 50%;
                background: #626263;
            }
        }
        .tuijian{
            padding: 0 35px 30px; 
            margin-top: 60px;
            strong{
                font-size: 18px;
                font-weight: normal;
            }
            ul{
                li{
                    color: #545455;
                    list-style-type: disc;
                    margin-left: 16px;
                    padding-top: 10px;
                    line-height: 30px;
                    font-size: 12px;
                    a{
                        font-size: 16px;
                    }
                }
            }  
        }

        
    }




}
</style>