<template>
  <div class="teamarc">
    <div class="comban">
      <img src="../assets/lawyerban.jpg" >
      <div>
        <strong>律师团队</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="teamarcwrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="teamarcinfo">
        <div class="teamarctop">
          <h2><img :src="topimg" ></h2>
          <strong>{{title}}</strong>
          <div class="biaoshi"><button>{{zhicheng}}</button></div>
          <p class="m20">专业领域：{{description}}</p>
          <div class="btnlink"><a href="">在线咨询</a><span>咨询电话：400-8789-888</span></div>
          <div class="redline m20"></div>
        </div>
        <div class="teamintro m20" v-html="htmlData"></div>
      </div>
    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default{
    name:'Teamarc',
    data(){
      return {
        breadcrumbList:[],
        htmlData:'',
        title:'',
        count:'',
        ctime:'',
        zhicheng:'',
        description:'',
        topimg:'',
        id:0
      }
    },
    methods:{
      getArc(){
        let that = this
        // console.log(that.$route);
        let arcid = that.$route.params.id.split('.')
        that.currentArcId = arcid[0]

        request({
          url: '/team/teamlist?id='+arcid[0],
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              let len = jsondata['data']['thumb'].split(':')[21].length
              let img = jsondata['data']['thumb'].split(':')[21].substr(1,len-4)
              that.htmlData = ''
              that.topimg = 'http://api.guanlingss.com'+img
              that.htmlData= jsondata['data']['content']
              that.title = jsondata['data']['title']
              // that.count = jsondata['data']['count']
              that.zhicheng = jsondata['data']['zhicheng']
              that.id = jsondata['data']['id']
              that.description = jsondata['data']['description']
            }
          }]
        })
      }
    },
    mounted() {
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'lawyerhtml'){
          $(".chonggou a[href$='/lawyer']").attr('class','router-link-active')
        }
      })

      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      //数据处理

      this.getArc()






    }
  }
</script>

<style lang="scss" scoped="scoped">
  .teamarc{
    .comban{
      div{
        color: #333;
      }
    }
    .teamarcwrap{
      .teamarcinfo{
        .teamarctop{
          margin-top: .5rem;
          h2{
            width: 3.06rem;
            margin: 0 auto;
          }
          strong{
            font-size: .3rem;
            font-weight: bold;
            display: block;
            text-align: center;
            line-height: 100%;
            margin-top: .3rem;
            margin-bottom: .25rem;
          }
          div.biaoshi{
            width: 3.2rem;
            margin: 0 auto .18rem;
            display: flex;
            justify-content: center;
            button{
              font-size: .24rem;
              width: 1.5rem;
              height: .4rem;
              background: #faeeef;
              text-align: center;
              line-height: .4rem;
              border-radius: .06rem;
              color: #706f6f;
              white-space: nowrap;
            }
          }
          p{
            font-size: .24rem;
            line-height: .36rem;
          }
          .btnlink{
            display: flex;
            justify-content: center;
            margin-top: .32rem;
            margin-bottom: .42rem;
            a,span{
              display: block;
              background: #b80816;
              height: .6rem;
              line-height: .6rem;
              font-size: .24rem;
              color: #fff;
              background-repeat: no-repeat;
              background-position: .42rem center;
              background-size: .24rem;
            }
            a{
              width: 2.14rem;
              text-indent: .77rem;
              margin-right: .2rem;
              background-image: url(../assets/zixun.png);
            }
            span{
              width: 4rem;
              text-indent: .8rem;
              background-image: url(../assets/baisedianhua.png);
            }
          }
          .redline{
            height: .4rem;
            background: url(../assets/teamlineimg.jpg) no-repeat left center / 7.11rem .4rem;
          }
        }
        .teamintro{
          margin-top: .3rem;
          padding-bottom: .3rem;
          img{
            display: none !important;
          }
          p{
            font-size: .24rem;
            line-height: .45rem;
            text-indent: 2em;

          }
        }
      }
    }
  }
</style>
