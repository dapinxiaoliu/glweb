<template>
<div class="fensuo">
 <div class="tvwrap w12">
            <div class="tvwrapleft comborder">
                <div class="fensuotitle">
                    <strong>冠领分所</strong>
                    <em></em>
                </div>
                <div class="litswiper">
                    <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper2 swiper-no-swiping">
                        <div class="swiper-wrapper">
                          <div class="swiper-slide active">
                            <img src="@/assets/images/beijinglit.jpg" />
                            <p>冠领全球总部</p>
                          </div>
                          <div class="swiper-slide">
                            <img src="@/assets/images/shanghailit.jpg" />
                            <p>冠领上海</p>
                          </div>
                          <div class="swiper-slide">
                            <img src="@/assets/images/xianlit.jpg" />
                            <p>冠领西安</p>
                          </div>
                          <div class="swiper-slide">
                            <img src="@/assets/images/kunminglit.jpg" />
                            <p>冠领昆明</p>
                          </div>
                          <div class="swiper-slide">
                            <img src="@/assets/images/shenzhenlit.jpg" />
                            <p>冠领深圳</p>
                          </div>
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
                <div class="bigswiper">
                    <div class="bigitem">
                        <div class="bigitembox">
                            <h2>冠领全球总部简介</h2>
                            <p>北京冠领律师事务所创办于2014年。总部位于北京西单黄金商业圈，与北京核心区域天安门相邻，毗邻最高人民法院、最高人民检察院，是中国征拆领域专业素质领先的律所品牌，坚持以“胜诉共赢”——法庭上争胜诉 法庭外谋共赢为办案理念。以专业化、品牌化、国际化为初衷，打造全国一流律所，冠领秉承着“以人为本”的发展理念，建所以来汇聚了逾200名专业的法律实务精英，其中大多数律师在清华大学、北京大学、中国人民大学、西南政法大学等知名学府沉淀积累，以专业铸造品质，以品质赢得未来，依靠勤奋耕耘的敬业精神和专业的法律技能，冠领律师团队一路成长，成为了老百姓的智囊团，赢得了社会的赞誉。冠领律师团队擅长根据被拆迁者的特殊情况，为其量身定制诉讼方案，为每个被拆迁者提供全方位、专业化的服务。</p>
                            <div class="morebox"><a href="">了解更多</a></div>
                            
                        </div>
                        <div class="bigitembox">
                            <h2>冠领全球总部环境</h2>
                            <div class="bigitemwrap">
                                <div class="swiper lawyerbox beijing">
                                    <div class="swiper-wrapper">
                                      <div class="swiper-slide"><img src="@/assets/images/bjpic1.jpg" alt=""><img src="@/assets/images/bjpic2.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/bjpic3.jpg" alt=""><img src="@/assets/images/bjpic4.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/bjpic5.jpg" alt=""><img src="@/assets/images/bjpic6.jpg" alt=""></div>
                                    </div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            </div>
                        </div>
                        <div class="bigitembox">
                            <h2>联系我们</h2>
                            <strong>联系地址：北京市西城区宣武门外大街庄胜广场中央办公楼5层、6层、15层、13层1309-1312</strong>
                            <strong>联系电话：<em>400-8787-666(24小时)</em></strong>
                        </div>
                    </div>
                    <div class="bigitem">
                        <div class="bigitembox">
                            <h2>冠领上海简介</h2>
                            <p>北京冠领（上海）律师事务所是经上海市司法局批准成立的专业法律服务机构，冠领上海分所坐落于黄浦江畔，占地近400平的办公地点，不仅交通便捷，而且环境十分优美。 很多人初识“冠领”是通过中央电视台和北京电视台，因为冠领律所是中央电视CCTV12《律师来了》的金牌合作伙伴，律所主任周旭亮、任战敏常年在中央电视台《法律讲堂》《律师来了》以及北京电规台《法治进行时》《第三调解室》《律师门诊室》等经典法制栏目中现身说法。 冠领上海分所依托冠领北京总所强大的师资力量，汇集了一批毕业于法学专业顶尖学府的饱学之士。冠领律所与中国政法大学刑事司法学院达成战略合作，成为中国政法大学实践基地，并聘请了中国政法大学资深法学专家阮齐林教授、王志远教授、何海波教授担任专家顾问。 在司法实践领域，冠领律所更是“沉淀”和“淬炼”出一批长期奋战在法律实务一线，身经百战的“律界老将”，凭借良好的法学素养、丰富的实战经验、负责任的办案作风，赢得众多企事业单位、社会组织、百姓的信任和好评。 以专业铸造品质，以品质赢得未来，冠领律所秉承一流法律服务，全力打造全国一流律师团队，打造全国一流律师事务所，保障当事人合法权益最大化。</p>
                            <div class="morebox"><a href="">了解更多</a></div>
                            
                        </div>
                        <div class="bigitembox">
                            <h2>冠领上海环境</h2>
                            <div class="bigitemwrap">
                                <div class="swiper lawyerbox shanghai">
                                    <div class="swiper-wrapper">
                                      <div class="swiper-slide"><img src="@/assets/images/shpic1.jpg" alt=""><img src="@/assets/images/shpic2.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/shpic3.jpg" alt=""><img src="@/assets/images/shpic4.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/shpic5.jpg" alt=""><img src="@/assets/images/shpic6.jpg" alt=""></div>
                                    </div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            </div>
                        </div>
                        <div class="bigitembox">
                            <h2>联系我们</h2>
                            <strong>联系地址：上海市黄浦区人民路300号外滩SOHO广场D幢</strong>
                            <strong>联系电话：<em>400-8787-666(24小时)</em></strong>
                        </div>
                    </div>
                    <div class="bigitem">
                        <div class="bigitembox">
                            <h2>冠领西安简介</h2>
                            <p>北京冠领（西安）律师事务所位于历史悠久的西安古城。冠领律所汇聚了百余名国内外知名法学院毕业的专业人才，具有坚实的理论功底和丰富的实践经验。 冠领律所专门从事公司债务纠纷、房产纠纷、合同纠纷、婚姻继承、交通事故、民间借贷、涉外诉讼和刑事辩护的专业化、团队化办案的优秀律师团队，能极大满足不同客户的法律需求，秉承“胜诉共赢”的办案理念，真正彰显了“受人之托忠人之事”的立足至本。</p>
                            <div class="morebox"><a href="">了解更多</a></div>
                            
                        </div>
                        <div class="bigitembox">
                            <h2>冠领西安环境</h2>
                            <div class="bigitemwrap">
                                <div class="swiper lawyerbox xian">
                                    <div class="swiper-wrapper">
                                      <div class="swiper-slide"><img src="@/assets/images/xa1.jpg" alt=""><img src="@/assets/images/xa2.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/xa3.jpg" alt=""><img src="@/assets/images/xa4.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/xa5.jpg" alt=""><img src="@/assets/images/xa6.jpg" alt=""></div>
                                    </div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            </div>
                        </div>
                        <div class="bigitembox">
                            <h2>联系我们</h2>
                            <strong>联系地址：陕西省西安市雁塔区雁翔路旺座曲江K座1804室</strong>
                            <strong>联系电话：<em>400-8787-666(24小时)</em></strong>
                        </div>
                    </div>
                    <div class="bigitem">
                        <div class="bigitembox">
                            <h2>冠领昆明简介</h2>
                            <p>昆明被誉为“春城”，更有独特地缘优势，东连黔桂，北经川渝，南下越老，西连印巴，位处“中国-东盟”自由贸易区、澜湄合作区、泛珠三角经济圈的交汇点。 冠领昆明分所依托冠领总所的全方位支持，快速积累法律人才，并从总所及其他分所汲取经验，形成一支听从指挥，能打胜仗，作风优良的冠领铁军。 冠领律师务实、深入地了解当事人所求所需，定期举办业务培训，建立冠领内部法律人才培训基地，让冠领培养了大批不同业务领域的律师精英团队。 昆明分所汇集一批经验丰富的优秀律师，以服务为先遣，发挥开放包容的律所文化、总分所及各地分所的协同赋能效应，打造彩云之南的多彩冠领！</p>
                            <div class="morebox"><a href="">了解更多</a></div>
                            
                        </div>
                        <div class="bigitembox">
                            <h2>冠领昆明环境</h2>
                            <div class="bigitemwrap">
                                <div class="swiper lawyerbox kunming">
                                    <div class="swiper-wrapper">
                                      <div class="swiper-slide"><img src="@/assets/images/km1.jpg" alt=""><img src="@/assets/images/km2.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/km3.jpg" alt=""><img src="@/assets/images/km4.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/km5.jpg" alt=""><img src="@/assets/images/km6.jpg" alt=""></div>
                                    </div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            </div>
                        </div>
                        <div class="bigitembox">
                            <h2>联系我们</h2>
                            <strong>联系地址：云南省昆明市西山区广福路与前卫西路十一家具大厦八楼D座1-7号办公室</strong>
                            <strong>联系电话：<em>400-8787-666(24小时)</em></strong>
                        </div>
                    </div>
                    <div class="bigitem">
                        <div class="bigitembox">
                            <h2>冠领深圳简介</h2>
                            <p>北京冠领（深圳）律师事务所位于深圳第一高楼——深圳平安金融中心，交通便利，环境舒适。 冠领律所以专业化、品牌化、国际化为初衷，致力于打造全国一流律所和全国一流律师团队。建所以来，冠领秉持“以人为本”的发展理念，汇聚众多法律实务精英，为寻求法律帮助的当事人提供高水平、高质量的法律服务。 冠领律所的法律服务涵盖行政诉讼、刑事辩护、公司综合法律事务、民商事务、仲裁、涉外业务等多个领域。一直以来，冠领律师始终坚持“胜诉共赢”的办案理念，坚持“受人之托、忠人之事”的服务态度，凭借坚实的理论功底和丰富的实践经验，竭力维护当事人合法权益，赢得好评无数。 冠领律所深圳分所的设立，既标志着冠领深入开发珠三角地区的法律服务市场，也为冠领放眼世界搭起了阶梯。</p>
                            <div class="morebox"><a href="">了解更多</a></div>
                            
                        </div>
                        <div class="bigitembox">
                            <h2>冠领深圳环境</h2>
                            <div class="bigitemwrap">
                                <div class="swiper lawyerbox shenzhen">
                                    <div class="swiper-wrapper">
                                      <div class="swiper-slide"><img src="@/assets/images/sz1.jpg" alt=""><img src="@/assets/images/sz2.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/sz3.jpg" alt=""><img src="@/assets/images/sz4.jpg" alt=""></div>
                                      <div class="swiper-slide"><img src="@/assets/images/sz2.jpg" alt=""><img src="@/assets/images/sz3.jpg" alt=""></div>
                                    </div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            </div>
                        </div>
                        <div class="bigitembox">
                            <h2>联系我们</h2>
                            <strong>联系地址：广东省深圳市福田区益田路5033号平安金融中心104层10401单元</strong>
                            <strong>联系电话：<em>400-8787-666(24小时)</em></strong>
                        </div>
                    </div>
                    

                </div>
            </div>
			<Aside/>

        </div>
</div>
</template>

<script>
	import Swiper from 'swiper'
	import "swiper/css/swiper.min.css"
	import $ from 'jquery'
	import {request} from '../network/request.js'
	import GLOBAL from '../global/global.js'
	import Aside from '../components/Aside'
	export default{
		name:'Fensuo',
		components:{
			Aside
		},
		data(){
			return {}
		},
		methods:{
			
		},
		mounted() {
			$(function(){
	
				setTimeout(function(){
					var swiper2 = new Swiper(".mySwiper2", {
					//   loop: true,
					  spaceBetween: 10,
					  slidesPerView: 3,
					  slidesPerGroup: 3,
					  navigation: {
					    nextEl: ".swiper-button-next",
					    prevEl: ".swiper-button-prev",
					  }
					});
					new Swiper(".lawyerbox", {
					    slidesPerView: 1,
					    spaceBetween: 10,
					    loop: true,
					    autoplay:{
					      delay:5000,
					      disableOnInteraction: false
					    },
					    pagination: {
					      el: ".swiper-pagination",
					      clickable: true,
					    }
					  });
		
					let litdiv = $('.litswiper .swiper-slide'),
					    bigitem = $('.bigswiper .bigitem')
					litdiv.mouseover(function(){
					    let index = $(this).index()
					    $(this).addClass('active').siblings().removeClass('active')
					    bigitem.eq(index).css({
					      opacity:1,
					      height:'100%'
					    }).siblings().css({
					      opacity:0,
					      height:0
					    })
					})
				},100)
			})
		}
	}
</script>

<style lang="scss">
.tvwrap{
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
    .tvwrapleft{
        width: 915px;
        background-color: #fff;
        .fensuotitle{
            strong{
                display: block;
                color: #b51829;
                text-align: center;
                font-weight: bold;
                font-size: 28px;
                padding: 25px 0;
            }
            em{
                display: block;
               
                height: 2px;
                margin: 0 auto;
                background: url('../assets/images/line.jpg') no-repeat center / 90% 2px;
            }
        }
        .litswiper{
            position: relative;
            overflow: hidden;
            margin-top: 20px;
            margin-bottom: 30px;
            .swiper{
                width: 768px;
                margin: 0 auto;
                overflow: hidden;
                padding: 20px 5px;
                .swiper-wrapper{
                    div.active{
                        img{
                            box-shadow: 0 0 5px 2px #ccc;
                        }
                        p{
                            background: #b41b21;
                            color: #fff;
                            border: 1px solid #b41b21;
                        }
                        p::after{
                            opacity: 1;
                        }
                    }
                }
                .swiper-slide{
                    position: relative;
                    cursor: pointer;
                    img{
                        border-radius: 5px;
                        transition: all .2s linear;
                        width: 245px;
                        height: 184px;
                    }
                    p{
                        position: absolute;
                        bottom: 0;
                        left: 0;
                        width: 245px;
                        height: 38px;
                        line-height: 35px;
                        background: #fff;
                        color: #333;
                        text-align: center;
                        border:1px solid #e2e1e1;
                        box-sizing: border-box;
                        border-bottom-left-radius: 5px;
                        border-bottom-right-radius: 5px;
                        transition: all .2s linear;
                        font-size: 20px;
                    }
                    p::after{
                        content: "";
                        height: 0;
                        width: 0;
                        position: absolute;
                        bottom: 0;
                        left: 50%;
                        bottom: -10px;
                        margin-left: -10px;
                        border-bottom: 20px solid #b41b21;
                        border-right: 20px solid transparent;
                        transform: rotate(-45deg);
                        opacity: 0;
                        transition: all .2s linear;
                    }
                }
               
                .swiper-button-prev, .swiper-button-next{
                    width: 28px;
                    height: 28px;
                    background-color: #b51829;
                    border-radius: 50%;
                }
                .swiper-button-disabled{
                    background-color: #999999;
                    opacity: 1;
                }
                .swiper-button-prev{
                    left: 30px;
                }
                .swiper-button-next{
                    right: 35px;
                }
                .swiper-button-next:after, .swiper-button-prev:after {
                    content: '';
                    width: 28px;
                    height: 28px;
                }
                .swiper-button-next:after{
                    background: url('../assets/images/right.png') no-repeat center / 12px 19px;
                }
                .swiper-button-prev:after{
                    background: url('../assets/images/left.png') no-repeat center 5px / 12px 19px;
                }
            }
        }
        .bigswiper{
            position: relative;
            overflow: hidden;
            padding: 0 40px;
            .bigitem:first-child{
                opacity: 1;
                height: auto;
            }
            .bigitem{
                opacity: 0;
                height: 0;
                transition: all .15s linear;
                .bigitembox:last-child{
                    padding-bottom: 0;
                }
                .bigitembox{
                    border-top: 2px solid #eaeaea;
                    padding-top: 30px;
                    padding-bottom: 30px;
                    h2{
                        font-size: 24px;
                        color: #b41b21;
                        position: relative;
                        text-indent: 20px;
                    }
                    h2::after{
                        content: "";
                        position: absolute;
                        left: 0;
                        top: 50%;
                        margin-top: -12px;
                        height: 25px;
                        width: 3px;
                        border: 1px solid #b41b21;
                        background: #b41b21;
                    }
                    p{
                        margin-top: 15px;
                        font-size: 16px;
                        line-height: 30px;
                        color: #333;
                        font-size: 16px;
                    }
                    div.morebox{
                        display: flex;
                        justify-content: end;
                        height: 40px;
                        margin-top: 10px;
                        a{
                            display: block;
                            width: 120px;
                            height: 40px;
                            line-height: 40px;
                            border: 1px solid #b41b21;
                            border-radius: 5px;
                            margin-right: 10px;
                            text-align: center;
                            color: #b41b21;
                            font-size: 20px;
                        }
                    }
                    .bigitemwrap{
                        position: relative;
                        overflow: hidden;
                        height: 228px;
                        width: 845px;
                        margin-top: 30px;
                        padding-bottom: 24px;
                        border-radius: 6px;
                        .swiper-slide{
                            display: flex;
                            justify-content: space-between;
                            img{
                                width: 416px;
                                height: 228px;
                                border-radius: 6px;
                            }
                        }
                        .swiper-pagination {
                            width: 150px;
                            height: 5px;
                            background: #d3d3d3;
                            position: relative;
                            display: flex;
                            border-radius: 2.5px;
                            margin: 0 auto;
                            bottom: -18px;
                        }
                        .swiper-pagination-clickable .swiper-pagination-bullet{
                            outline: none;
                            border-radius: 0;
                            width: 50px;
                            height: 5px;
                            background: #d3d3d3;
                            opacity: 1;
                            border-radius: 2.5px;
                            margin: 0;
                        }
                        .swiper-pagination-bullet-active {
                            background-color: #cc0033 !important;
                        }
                    }
                    strong{
                        display: block;
                        font-weight: normal;
                        font-size: 16px;
                        color: #333;
                        margin-top: 30px;
                        background-repeat: no-repeat;
                        text-indent: 40px;
                        em{
                            color: #b41b21;
                        }
                    }
                    strong:nth-of-type(1){
                        background-image: url('../assets/images/wztb.jpg');
                    }
                    strong:nth-of-type(2){
                        padding-bottom: 40px;
                        background-image: url('../assets/images/dhxta.jpg');
                    }
                    
                }

            }
        }
    }




}
</style>