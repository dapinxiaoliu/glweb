<template>
  <div class="lawyer">
    <div class="linebanbox">
      <img src="../assets/lvshiban.jpg" class="autoc">
      <div class="linebanhead">
        <!-- <strong>律师团队</strong> -->
        <!-- <small>全球咨询热线：400-8789-888</small> -->
      </div>
    </div>

    <div class="lawyerinner w1200">
       <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;律师团队</div>
       <div class="searchbox">
          <div class="searchwrap">
            <div><input type="text" name="" id="" value="" placeholder="请输入律师姓名" v-model="inputName"/><button @click="searchName">搜索</button></div>
            <div class="biaoqian">
              <strong>按职位搜索</strong>
              <ol>
                <li @click="getZhiwei(13)">律所主任</li>
                <li @click="getZhiwei(31)">专家顾问</li>
                <li @click="getZhiwei(14)">律师团队</li>
                <li @click="getZhiwei(16)">律师助理</li>
                <li @click="getZhiwei('all')" class="bf">全部</li>
              </ol>
            </div>
          </div>
          <div class="showmsg" v-if="isshownum" >共找到结果 <em>{{totalNum}}</em> 条</div>
       </div>
        <div class="lawyerwrap" v-loading="loading" :element-loading-text="loadtext">
          <ul>

          	<li v-for="item,index in lawyerData" :key="index">
              <router-link :to="{path: '/lawyer/'+item.id+'.html'}">
                <div class="lawyerl"><img :src="item.thumb" ></div>
                <div class="lawyerr">
                  <strong>{{item.title}}</strong>
                  <div><em>{{item.zhicheng}}</em></div>
                  <p>个人简介：{{item.description}}</p>
                  <span>全国咨询热线：400-8789-888</span>
                </div>
              </router-link>
            </li>

          </ul>
        </div>
        <div class="page" v-if="isSearch == 's'">
           <el-pagination
             background
             hide-on-single-page
             current-page=1
             @current-change="sfenye"
             layout="prev, pager, next"
             prev-text="上一页"
             next-text="下一页"
             :page-sizes=pageSize
             :pager-count= 5
             :page-count=lastPage
             :key=inputName>
           </el-pagination>
        </div>
        <div class="page" v-else-if="zhiweisearch == 's'">
           <el-pagination
             background
             hide-on-single-page
             @current-change="zhiweipage"
             layout="prev, pager, next"
             prev-text="上一页"
             next-text="下一页"
             :page-sizes=pageSize
             :pager-count= 5
             :page-count=lastPage
             :key=lmid>
           </el-pagination>
        </div>
        <div class="page" v-else>
           <el-pagination
             background
             hide-on-single-page
             @current-change="compage"
             layout="prev, pager, next"
             prev-text="上一页"
             next-text="下一页"
             :page-sizes=pageSize
             :pager-count= 5
             :page-count=lastPage
             :key=morenid>
           </el-pagination>
        </div>
    </div>
    <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'LawyerView',
    data(){
      return {
        lawyerData:[],
        pageSize: 8,
        lastPage:0,
        inputName:'',
        loadtext: '数据加载中...',
        loading: false,
        isSearch:'',
        totalNum:0,
        isshownum:'',
        lmid:0,
        zhiweisearch:'',
        morenid:''
      }
    },
    methods:{
      getLawyer(){

        let that = this
        that.morenid = Math.random()
        request({
          url: 'team/allteam?page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lawyerData = []
              if(jsondata['data']['total'] == 0){

                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[21].length
                    val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                    that.lawyerData.push(val)
                });
                // console.log(that.lawyerData);
                // that.lawyerData = jsondata['data']['data']
              that.pageSize = newData['per_page']
              that.lastPage = newData['last_page']
               that.totalNum = newData['total']
              }
            }
          }]
        })
      },
      //职称搜索
      getZhiwei(lmid){
        let that = this
        if(lmid == 'all'){
          that.getLawyer()
          return false;
        }
        that.lmid = lmid
        that.isshownum = 's'
        that.zhiweisearch = 's'
        that.isSearch = ''
        request({
          url: '/team/read?id='+lmid+'&page=1&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lawyerData = []
              if(jsondata['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[21].length
                    val['thumb'] ='http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                    that.lawyerData.push(val)
                });
                // that.lawyerData = jsondata['data']['data']
                that.pageSize = newData['per_page']
                that.lastPage = newData['last_page']
                that.totalNum = newData['total']
              }
            }
          }]
        })
      },
      //搜索名字
      searchName(){
        let that = this
        that.isshownum = 's'
        that.zhiweisearch = ''
        that.isSearch = ''
        if(that.inputName == ''){
          that.getLawyer()
          return false;
        }
        that.isSearch = 's'
        request({
          url: '/team/sousuo?name='+that.inputName+'&page=1&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lawyerData = []
              if(jsondata['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[21].length
                    val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                    that.lawyerData.push(val)
                });
                // that.lawyerData = jsondata['data']['data']
                that.pageSize = newData['per_page']
                that.lastPage = newData['last_page']
                that.totalNum = newData['total']
              }
            }
          }]
        })
      },
      // 分页
      compage(val){
        let that = this
        that.loading = true
        request({
          url: 'team/allteam?page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              // console.log(jsondata)
              that.lawyerData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){

                  that.loading = false
                  if(val['thumb'].length > 50){
                      let thumb = val['thumb'].split(':')
                      let thumblength = thumb[21].length
                      val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                  }
                  that.lawyerData.push(val)
              });
              that.pageSize = newData['per_page']
              that.lastPage = newData['last_page']
            }
          }]
        })
      },
      // 搜索分页
      sfenye(val){
        let that = this
        that.loading = true
        request({
          url: '/team/sousuo?name='+that.inputName+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              // console.log(jsondata)
              that.lawyerData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[21].length
                  val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                  // console.log(val);
                  that.lawyerData.push(val)
              });
              that.pageSize = newData['per_page']
              that.lastPage = newData['last_page']
            }
          }]
        })
      },
      // 职位搜索分页
      zhiweipage(val){
        let that = this
        that.loading = true
        request({
          url: '/team/read?id='+that.lmid+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              // console.log(jsondata)
              that.lawyerData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[21].length
                  val['thumb'] = 'http://api.guanlingss.com'+thumb[21].substr(1,thumblength-4);
                  // console.log(val);
                  that.lawyerData.push(val)
              });
              that.pageSize = newData['per_page']
              that.lastPage = newData['last_page']
            }
          }]
        })
      }
    },
    watch:{
      lawyerData:{
        handler(news){
          this.lawyerData = news
        }
      },
      totalNum(val){
        this.totalNum = val
      },
      isSearch(val){
      }
    },

    mounted(){
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'lawyer'){
          $(".chonggou a[href$='/lawyer']").attr('class','router-link-active')
        }
      })
      $('.biaoqian li').click(function(){
        $(this).addClass('bf').siblings().removeClass('bf')
        // $('input').attr('placeholder',"请输入律师姓名");
      })
      $('.searchwrap button').click(function(){
        $('.biaoqian li').removeClass('bf')
      })

      let homeid = this.$route['query']['id'];
      if(homeid != undefined){
        this.lmid = homeid
        this.getZhiwei(homeid)
        $('.biaoqian li').removeClass('bf')
        // $('.biaoqian li').eq(4).addClass('bf')
        if(homeid == 13){
            $('.biaoqian li').eq(0).addClass('bf')
        }
        if(homeid == 32){
            $('.biaoqian li').eq(1).addClass('bf')
        }
        if(homeid == 14){
            $('.biaoqian li').eq(2).addClass('bf')
        }
        if(homeid == 16){
            $('.biaoqian li').eq(3).addClass('bf')
        }
      }else{
        this.getLawyer()
      }
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .lawyer{
    .linebanbox{
      strong,small{
        color: #333;
      }
    }
    .lawyerinner{
      .searchbox{
        margin-top: 40px;
        line-height: 100%;
        .showmsg{
          font-size: 16px;
          margin-top: 18px;
          // display: none;
          em{
            color: #b80816;
          }
        }
        .searchwrap{
          display: flex;
          align-items: center;
          padding-bottom: 22px;
          border-bottom: 1px solid #f5f5f5;
        }
        button{
          height: 50px;
          border: none;
          background-color: #b80816;
          width: 100px;
          color: #fff;
          font-size: 18px;
          vertical-align: top;
          cursor: pointer;
          background-image: url(../assets/search.png);
          background-repeat: no-repeat;
          background-position: 21px center;
          padding-left: 35px;
        }
        input{
          height: 50px;
          border: 1px solid #b80816;
          box-sizing: border-box;
          padding-left: 10px;
          width: 208px;
          padding-right: 10px;
          font-size: 18px;
          color: #999999;
        }
        input::placeholder{
          color: #999999;
        }
        .biaoqian{
          display: flex;
          align-items: center;
          margin-left: 40px;
          strong{
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin-right: 20px;
          }
          ol{
            display: flex;
          }
          li{
            font-size: 18px;
            width: 102px;
            height: 30px;
            line-height: 30px;
            text-align: center;
            border-radius: 4px;
            cursor: pointer;
            transition: all .2s linear 0s;
          }
          li.bf{
            background: #f2f2f2;
            color: #b80816;
          }

        }
      }
      .lawyerwrap{
        ul{
          display: flex;
          flex-wrap: wrap;
          justify-content: space-between;
          li:hover{
            a{
              color: #fff !important;
              .lawyerr{
                background: #b80816;
                width: 100%;
                em{
                  background: #fff;
                  color: #b80816;
                }
                span{
                  background-image: url(../assets/dianhua-s.png);
                }
              }
            }

          }
          li{
            width: 590px;
            margin-top: 20px;
            overflow: hidden;
             border: 1px solid #e5e5e5;
             box-sizing: border-box;
             // border-left: transparent;
            .lawyerl{

              width: 211px;
              img{
                width: 211px;
                height: 260px;
              }
            }
            .lawyerr{
              padding-left: 35px;
              padding-right: 30px;
               position: relative;



              strong{
                font-size: 20px;
                font-weight: bold;
                line-height: 100%;
                margin-bottom: 17px;
                margin-top: 27px;
                display: block;
              }
              em{
                font-size: 18px;
                background: #e5e5e5;
                padding: 0 10px;
                height: 28px;
                line-height: 28px;
                margin-right: 10px;
                display: inline-block;
                border-radius: 5px;
                color: #666666;
                transition: all .2s linear 0s;
              }
              p{
                line-height: 26px;
                margin-top: 10px;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 3;
                overflow: hidden;
              }
              span{
                position: absolute;
                bottom: 30px;
                display: block;
                margin-top: 34px;
                background: url(../assets/dianhua.png) no-repeat left center;
                padding-left: 26px;
                width: 280px;
              }
            }
            a{
              display: flex;
              font-size: 18px;
              color: #666666;
            }

          }
        }
      }
    }
  }
</style>
