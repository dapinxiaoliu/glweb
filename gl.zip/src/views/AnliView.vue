<template>
  <div class="anli">
   <div class="linebanbox">
     <img src="../assets/shipininfoimg.jpg" class="autoc">
     <div class="linebanhead">
       <strong>胜诉案例</strong>
       <small>全球咨询热线：400-8789-888</small>
     </div>
   </div>
  <div class="anliinner w1200">
    <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;胜诉案例</div>
    <div class="anlinav">
      <!-- 所属的分所 北京是1 上海2  深圳3  昆明4 -->
      <button class="curr" @click="mouseGetData(1,68)">北京冠领总部</button>
      <button @click="mouseGetData(2,68)">上海冠领</button>
      <button @click="mouseGetData(3,68)">深圳冠领</button>
      <button @click="mouseGetData(4,68)">西安冠领</button>
      <button @click="mouseGetData(5,68)">昆明冠领</button>
    </div>
    <div class="aliwrapcont">
      <!-- 第一个 -->
      <div class="anliwrapbox">
        <div class="anliwrap">
          <div class="yangshiwrapl">
            <h2>- 全  部 -</h2>
            <div class="yangshibox">
              <div class="yangshiitem" v-for="item,index in anliLanmu" :key="item.id" @click="setActuve(index)" :class="{ysactive:isSelect==index}">
                <strong @click="currentData(item.cid)" >{{item.name}}</strong>
                <ul>
                 <li v-for="i,idx in item.child" @click="isred(idx,i.id)" :class="{isred:isredbox==idx}">{{i.name}}</li>
                </ul>
              </div>
            </div>
          </div>
          <div class="yangshiwrapr" v-loading="loading" :element-loading-text="loadtext">
            <div class="yangshiboxwrap">
              <ul>
                <li v-for="item,index in beijingData" :key="index"  @click="setcache(item.catid,isSelect,item.id,isredbox)">
                  <router-link :to="{path: '/case/'+item.id+'.html'}">{{item.title}}</router-link>
                  <!-- <em>{{item.count}}</em> -->
                  <span>{{item.create_time}}</span>
                </li>
              </ul>
            </div>

            <div class="page">
              <el-pagination
                background
                hide-on-single-page
                @current-change="compage"
                :current-page=currentid
                layout="prev, pager, next"
                prev-text="上一页"
                next-text="下一页"
                :page-sizes=pageSize
                :pager-count= 5
                :page-count=lastPage
                :key='lmid'>
              </el-pagination>
            </div>
          </div>
        </div>
      </div>
      <!-- 第二个 -->
    </div>
  </div>
  <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'AnliView',
    data(){
      return{
        beijingData:[],
        anliLanmu:[],
        pageSize:20,
        lastPage:0,
        isSelect: 0,
        isredbox:0,
        loadtext:"数据加载中...",
        lmid:0,
        currentid:1,
        mouseid:1,
        gengxin:''
      }
    },
    methods:{
      setActuve(index){
        this.isSelect = index
      },
      isred(val,itemid,id){
        this.isredbox = val
        this.ysactive(itemid,id)
      },
      currentData(id){
         this.isredbox = 0
         this.ysactive(id)
      },
      setcache(pid,pids, id,ids){
        localStorage.setItem("pid", pid)
        localStorage.setItem("pids", pids)
        localStorage.setItem('id', id)
        localStorage.setItem('ids', ids)
      },
      mouseGetData(id,lmid){
        let that = this
        that.mouseid = id
        that.loading = true
        that.isSelect = 0
        that.isredbox = 0
        that.loadtext = '数据加载中...'
        request({
          url: '/anli/read?catid='+lmid+'&id='+id+'&page='+that.currentid+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.beijingData = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let riqi = val['create_time'].split(' ')
                    val['create_time'] = riqi[0]
                    that.beijingData.push(val)
                })
                that.pageSize = newData['per_page']
                that.lastPage = newData['last_page']
              }
            }
          }]
        })
      },
      ysactive(lmid){
        let that = this
        that.loading = true
        that.lmid = lmid
        request({
          url: '/anli/read?catid='+that.lmid+'&id='+that.mouseid+'&page='+that.currentid+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.beijingData = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
                that.pageSize = newData['per_page']
                that.lastPage = newData['last_page']
              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let riqi = val['create_time'].split(' ')
                    val['create_time'] = riqi[0]
                    that.beijingData.push(val)
                })
                that.pageSize = newData['per_page']
                that.lastPage = newData['last_page']
              }
            }
          }]
        })
      },
      //分页
      compage(val){
        let that = this
        // console.log(that);
        request({
          url: '/anli/read?catid='+that.lmid+'&id='+that.mouseid+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              console.log(jsondata)
              that.beijingData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let riqi = val['create_time'].split(' ')
                  val['create_time'] = riqi[0]
                  that.beijingData.push(val)
              })
              that.pageSize = newData['per_page']
              that.lastPage = newData['last_page']
            }
          }]
        })
      },
      asidelanmu(){
        //获取侧边栏目
        let that = this
        that.anliLanmu = []
        request({
          url: '/Category/getcatelist?id=2',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata['data'])
            if(jsondata['code'] == 200){
             jsondata['data'].forEach(function(val){
                 if(val['name'] != "待审核案例"){
                   if(val['child'][0] == undefined){
                       val['cid'] =  val['id'];
                       that.anliLanmu.push(val)
                   }else{
                     val['cid'] =  val['child'][0]['id'];
                     that.anliLanmu.push(val)
                   }
                   that.loading = false
                 }
              })
            }
          }]
        })
      }
    },
    created(){
        //获取栏目
        this.asidelanmu()
        //默认调取北京数据
    },
    watch:{
      anliLanmu(){
        this.gengxin = localStorage.getItem("pid")
        // alert(this.gengxin)
        if(this.gengxin == 'null' || this.gengxin ==  undefined){
          // alert('a')
          this.isSelect = 0
          this.isredbox = 0
          this.mouseid = 1
          this.ysactive(68)
          $('.anlinav button').eq(0).addClass('curr').siblings().removeClass('curr')
        }else{
          // alert('b')
          let id = localStorage.getItem('id')
          let ids = localStorage.getItem('ids')
          let pids = localStorage.getItem('pids')
          let idx = localStorage.getItem('idx')
          if(idx == 'null'){
            idx = 0
            this.lmid = 1
          }else{
            this.lmid = this.gengxin
          }
          // alert(this.gengxin)
          this.mouseid = parseInt(idx)+1
          this.ysactive(this.gengxin)
          this.isSelect = pids
          this.isredbox = ids
          $('.anlinav button').eq(idx).addClass('curr').siblings().removeClass('curr')
        }
      }
    },
    mounted(){
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'case'){
          $(".chonggou a[href$='/case']").attr('class','router-link-active')
        }
      })

      let anlibtn = $('.anlinav button');
      anlibtn.click(function(){
        let idx = $(this).index()
        localStorage.setItem('idx', idx)
        $(this).addClass('curr').siblings().removeClass('curr')
      })

    this.$nextTick(function(){
      let homeid = this.$route['query']['id']
      if(homeid != undefined){
        this.lmid = homeid
        this.ysactive(homeid)
        switch(homeid){
          case '68':
          this.isredbox = 0
          break;
          case '75':
          this.isSelect = 1
          break;
          case '7':
          this.isSelect = 2
          break;
          case '8':
          this.isSelect = 3
          break;
          case '81':
          this.isSelect = 4
          break;
          case '10':
          this.isSelect = 5
          break;
          case '65':
          this.isSelect = 7
          break;
        }
      }else{
        //进行数据验证判断
        // let pid = localStorage.getItem("pid")
        if(this.gengxin ==  'null'){
          // alert('a')
          this.isSelect = 0
          this.isredbox = 0
          this.ysactive(68)
        }else{
          // alert('b')
          // alert(this.gengxin)

        }
      }
    })
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .anli{
    .anliinner{
      .anliwrap{
        display: flex;
      }
      .anlinav{
        margin-top: 30px;
        margin-bottom: 40px;
        display: flex;
        justify-content: space-between;
        button{
          height: 70px;
          padding: 0 66px;
          font-size: 22px;
          color: #333;
          background: #f3f3f3;
          border: none;
          cursor: pointer;
          border-radius: 4px;
          transition: all .2s linear 0s;
          position: relative;
        }
        button.curr{
           background: #b80816;
           color: #fff;
        }
        button.curr:hover{
          background: #b80816;
          color: #fff;
        }
        button.curr::after{
          content: "";
          width: 0;
          height: 0;
          border: 12px solid #b80816;
          border-bottom:12px solid transparent;
          border-right:12px solid transparent;
          border-left: 12px solid transparent;
          position: absolute;
          bottom: -23px;
          left: 50%;
          margin-left: -6px;
          transition: all .3s linear .5s;
        }

      }

      .aliwrapcont{
        .anliwrapbox{
          display: none;
          .anliwrap{
            .yangshiwrapl{
              width: 270px;
              box-sizing: border-box;

              h2{
                font-size: 22px;
                font-weight: bold;
                height: 68px;
                line-height: 68px;
                border: 1px solid #e5e5e5;
                text-align: center;
                border-radius: 8px 8px 0 0;
                border-bottom: none;
              }
              .yangshibox{
                border: 1px solid #e5e5e5;
                border-radius: 0 0 8px 8px;
                .yangshiitem:last-child{
                  strong,ul{
                    border-bottom: none;
                  }

                }
                .yangshiitem:first-child ul{
                  height: auto;
                }

                .yangshiitem{
                  height: 71px;
                  overflow: hidden;
                  strong{
                    font-weight: bold;
                    font-size: 20px;
                    color: #666666;
                    line-height: 70px;
                    height: 70px;
                    display: block;
                    padding-left: 64px;
                    border-bottom: 1px solid #e5e5e5;
                    cursor: pointer;
                    background: url(../assets/yangshiicon.jpg) no-repeat 230px center;
                    position: relative;
                  }
                  strong::before{
                    content: "";
                    position: absolute;
                    left: 40px;
                    top: 50%;
                    width: 13px;
                    height: 14px;
                    margin-top: -7px;
                    background: url(../assets/wenbenicon.png) no-repeat center;

                  }
                  ul{
                    // padding: 20px 0 20px 32px;
                    height: 0;
                    overflow: hidden;
                    border-bottom: 1px solid #e5e5e5;
                    transition: all .3s linear 0s;
                    li{
                      height: 42px;
                      line-height: 42px;
                      padding-left: 65px;
                      margin-right: 20px;
                      cursor: pointer;
                      font-size: 18px;
                      overflow: hidden;
                      text-overflow: ellipsis;
                      white-space: nowrap;
                    }

                  }
                }
                .isred{
                  color: #b80816;
                }
                .ysactive{
                  ul{
                    height: 100%;
                  }
                  height: 100%;
                  strong{
                    color: #b80816;
                    background-image: url(../assets/yangshiicon-s.jpg);
                  }
                  strong::before{
                     background-image: url(../assets/wenbenicon-s.png);
                  }
                }
              }
            }
            .yangshiwrapr{
              width: 905px;
              margin-left: 25px;
              .yangshiboxwrap{
                ul{
                  overflow: hidden;
                  li{
                    width: 100%;
                    height: 60px;
                    line-height: 60px;
                    border: 1px solid #eeeeee;
                    box-sizing: border-box;
                    border-radius: 4px;
                    margin-bottom: 15px;
                    padding-left: 54px;
                    background: url(../assets/alitemicon.png) no-repeat 29px center;
                    display: flex;
                    align-items: center;
                    cursor: pointer;
                    transition: all .3s linear 0s;
                    a{
                      font-size: 18px;
                      display: block;
                      overflow: hidden;
                      text-overflow: ellipsis;
                      white-space: nowrap;
                      width: 80%;
                    }
                    em,span{
                      font-size: 18px;
                      color: #999999;
                    }
                    em{
                        background: url(../assets/yan.png) no-repeat left center;
                        padding-left: 28px;
                        margin-right: 32px;
                        margin-left: 20px;
                    }
                    span{
                      background: url(../assets/riqi.png) no-repeat left center;
                      padding-left: 24px;
                    }

                  }
                  li:hover{
                    background-image: url(../assets/alitemicon-s.png);
                    border: 1px solid #b80816;
                    em,span,a{
                      color: #b80816;
                    }
                    em{
                      background-image: url(../assets/yan-s.png);
                    }
                    span{
                      background-image: url(../assets/riqi-s.png);
                    }
                  }
                }
              }
            }
          }
        }
        .anliwrapbox:first-child{
          display: block;
        }
      }
    }
  }
</style>
