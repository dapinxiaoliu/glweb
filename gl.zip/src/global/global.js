const httpurl = 'http://api.guanlingms.com'

export default{
  httpurl
}