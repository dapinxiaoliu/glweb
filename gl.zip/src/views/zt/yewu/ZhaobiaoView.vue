<template>
  <div class="yewuinfo">
    <div class="linebanbox">
      <img src="../../../assets/yewuinfoline.jpg" class="autoc">
      <div class="linebanhead">
        <strong>招投标业务</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="yewuwrap w1200">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
          <el-breadcrumb-item>{{nowname}}</el-breadcrumb-item>

        </el-breadcrumb>
      </div>
      <div class="yewuintro">
        <div class="yewuintrol">
          <h2>招投标业务</h2>
          <div class="yewuintrowrap">
            <div class="yewuintrowraph">

            <p>招标投标是基本建设领域促进竞争的全面经济责任制形式。一般由若干施工单位参与工程投标，招标单位择优入选，谁的工期短、造价低、质量高、信誉好，就把工程任务包给谁，由承建单位与发包单位签订合同，一包到底，按交钥匙的方式组织建设。</p>
            <p>北京冠领律师事务所在周旭亮主任、任战敏执行主任的带领下，7年间开设多家分所，总所内员工逾400人，办理近万件案件。招投标业务咨询，北京冠领律师事务所拥有专业律师，能够高效分析，为客户出具方案，解决问题。那么，什么情况下需要涉及招投标业务呢？</p>
            <p>在中华人民共和国境内进行下列工程建设项目包括项目的勘察、设计、施工、监理以及与工程建设有关的重要设备、材料等的采购，必须进行招标，其中包括：大型基础设施、公用事业等关系社会公共利益、公众安全的项目；全部或者部分使用国有资金投资或者国家融资的项目；使用国际组织或者外国政府贷款、援助资金的项目。</p>
            <p>前款所列项目的具体范围和规模标准，由国务院发展计划部门会同国务院有关部门制定，报国务院批准。法律或者国务院对必须进行招标的其他项目的范围有规定的，依照其规定。违反招标投标的规定要承担什么法律责任，这些便是招投标业务涉及的领域。</p>
            <p>一般情况下的招投标业务的流程如下：</p>
            <p>第一，项目招标委员会的组成。招标委员会应由国家主管部门组织，聘请工程、商务、外汇、法律等各有关方面的专家组成，负责解决项目招标中所遇到的各种问题，并具体指导招标工作。在招投标业务中，这部分需要提前关注。</p>
            <p>第二，招标公告。在进行招标前，应在国内外有影响的报刊上发布招标公告。它包括招标通知和招标广告两部分。招标通知是指分别送给项目有关的与所在国建立了外交和商务关系的各国有关部门的书面通知。招标广告是指在国内外有影响力的报刊所刊登的招标广告。
通知和广告的内容包括：项目名称、项目地点、项目内容概况、工程范围、索取招标文件的日期、地址和截止日期、招标条件、价格及有关事项的咨询单位等，注意公告信息也是招投标业务不可或缺的一部分。</p>
            <p>第三，资格预审。资格预审是指对愿意承担招标项目的投标人进行的财务状况、技术能力、资信等方面的预先审查，目的是选择确有承包能力的投标人，招投标业务包含对审核资料的准备。</p>
            <p>第四，制定标底。招标委员会刊登招标广告语，即应准备合同价格，通过项目概算，确定合同价格水平，也称为“标底”，是招标委员会掌握的底牌，是绝对保密的。</p>
            <p>第五，公开招标。公开招标是招投标业务执行的开始，指招标委员会通知取得招标资格的投标人或刊登广告知悉投标人索取或购买招标文件，邀请其前来投标的招标环节。</p>
            <p>第六，开标。开标是指招标委员会在规定的日期、时间和地点，将截止日期前收到的全部投标文件，在所有投标人或其代表在场的情况下，当场拆封投标文件，并公开宣读各投标人的投标条件，以使全体投标人了解各家标价，这种程序称为开标，招投标业务会为投标人提供一条龙服务。</p>
            <p>第七，评标与决标。开标以后转入评标阶段。招标委员会将投标文件的标价，及其他条件一一汇集列表，选取其中报价最低的四、五份投标文件，进行审查、鉴别、比较，直至决定中标单位，这一阶段，是在秘密条件下进行的。决标是根据评标报告及其推荐意见为依据，由招标委员会决定中标人，同时向中标人发出中标通知时的环节，对未中标的人一般不可通知，或只简单通知承包人中标即可，招投标业务会保障投标人在中标流程的权益。</p>
            <p>第八，签订合同。中标人在接到正式的“中标通知书”后，即应在规定的时间内与工程业主签订工程承包合同。合同先由一方起草，并在该草稿基础上进行磋商，达成一致后签订，这部分也是招投标业务的重点之一。</p>
            <p>冠领坚持“以胜诉求共赢——法庭上争胜诉，法庭下谋共赢”的办案理念，以规模化、专业化、品牌化、国际化的优势，为当事人提供优质、高效的法律服务。成功办理了大量行政纠纷、公司法律纠纷、房产纠纷、合同纠纷、侵权纠纷、刑事纠纷等案件，赢得了企事业单位、社会组织、老百姓的广泛好评和持久信任。</p>

            </div>
          </div>

          <router-link to="" class="morelink">查看更多></router-link>
        </div>
        <div class="yewuintror">
          <router-link to="/lawyer/">
            <img src="../../../assets/yewuxgtd.jpg" >
            <strong><router-link to="/lawyer/">相关团队</router-link></strong>
          </router-link>
        </div>
      </div>

    </div>

    <div class="yewurun">
      <strong>招投标业务</strong>
      <div class="yewurunbox w1200">
        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide swiperbtn" v-for="item,index in lmdata['child']" :key="index" >{{item.name}}</div>
          </div>
        </div>
        <div thumbsSlider="" class="swiper mySwiper2">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>招投标合同纠纷</h3>
               <p>{{a['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>招投标保证金纠纷</h3>
                <p>{{b['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>招投标 无效纠纷</h3>
               <p>{{c['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>招投标违约赔偿</h3>
                  <p>
                  {{d['description']}}
                  </p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>政府采购</h3>
                <p>{{e['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>PPP项目法律顾问</h3>
                <p>{{f['description']}}</p>
              </div>
            </div>

          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
    <!-- 经典案例 -->
    <div class="jdal w1200">
      <strong>经典案例</strong>
      <div class="jdalwrap">
        <div class="jdalwrapbox">
          <ul>
          	<li v-for="item,index in anlidata" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
          </ul>
          <router-link to="/case/" class="morelink">查看更多></router-link>
        </div>
        <img src="../../../assets/anliimg.jpg" >
      </div>
    </div>

    <!-- 相关新闻 -->
    <div class="aboutnew">
      <div class="aboutnewwrap w1200">
        <strong>相关新闻</strong>
        <div class="aboutnewbox">
          <div class="aboutnewzw">
            <div class="aboutnewl"><img src="../../../assets/newleft.jpg" ></div>
            <ul>
            	<li v-for="item,index in newsdata" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">{{item.title}}</router-link><span>{{item.create_time}}</span></li>
            </ul>
          </div>
          <router-link to="/newslist/" class="morelink">查看更多></router-link>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../../../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  import {request} from '../../../network/request.js'
  import GLOBAL from '../../../global/global.js'
  export default{
    name: 'ShangshiView',
    data(){
      return{
        breadcrumbList:[],
        lmdata:[],
        lmname:'',
        nowname:'',
        lmid:0,
        isActive: false,
        anlidata:[],
        newsdata:[],
        a:[],
        b:[],
        c:[],
        d:[],
        e:[],
        f:[],
        isSelect:false,
        initnum:0

      }
    },
    methods:{
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
              // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lmdata = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                 that.lmdata = newData[7]
                 that.lmname = newData[7]['name']
                 newData[7]['child'].forEach(function(val){

                    if(val['id'] == that.lmid){
                        that.nowname = val['name']
                    }
                 })
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getanliData(){
        let that = this
        request({
          url: '/lingyu/lyanli?id=66',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.anlidata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.anlidata = jsondata['data'];
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getnewsData(){
        let that = this
        request({
          url: '/lingyu/lynews?id=62',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.newsdata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data']
                newData.forEach(function(val){
                  val['create_time'] = val['create_time'].split(' ')[0]
                  that.newsdata.push(val)
                });
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getlitinfo(id){
        let that = this
        request({
          url: '/lingyu/read?id='+id,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lanmuname = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                switch(id){
                  case 182:
                  that.a = jsondata['data']
                  break;
                  case 183:
                  that.b = jsondata['data']
                  break;
                  case 184:
                  that.c = jsondata['data']
                  break;
                  case 185:
                  that.d = jsondata['data']
                  break;
                  case 186:
                  that.e = jsondata['data']
                  break;
                  case 187:
                  that.f = jsondata['data']
                  break;
                }
              }
            }
          }]
        })
      }
    },
    watch:{
      newsdata(){

      }
    },
    created() {

    },
    mounted(){
      let that = this
      this.getlmData()
      this.getanliData()
      this.getnewsData()
      this.getlitinfo(182)
      this.getlitinfo(183)
      this.getlitinfo(184)
      this.getlitinfo(185)
      this.getlitinfo(186)
      this.getlitinfo(187)
      //获取id
      let lanmuid = this.$route.query['id']
      if(lanmuid != undefined){
          that.lmid = lanmuid
          switch(lanmuid){
            case '182':
            that.initnum = 0
            break;
            case '183':
            that.initnum = 1
            break;
            case '184':
            that.initnum = 2
            break;
            case '185':
            that.initnum = 3
            break;
            case '186':
            that.initnum = 4
            break;
            case '187':
            that.initnum = 5
            break;
          }
          // alert($('.yewuwrap').offset().top)
          $('body,html').animate({
                  scrollTop: $('.yewurun').offset().top
          },500);
      }else{
        that.initnum = 0
      }
      // console.log(this.$route.name);
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'zhaobiao'){
          $(".chonggou a[href$='yewu']").attr('class','router-link-active')
        }
      })


      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      let islock = false;
      let yewuintrowraph = $('.yewuintrowraph')
      let morelink = $('.yewuintrol .morelink')
      morelink.click(function(){
        if(islock == false){
          islock = true
          $('.yewuintrowrap').animate({
            height: yewuintrowraph.height()
          },500,function(){
            morelink.html('收起更多>')
          })

        }else{
          islock = false
          $('.yewuintrowrap').animate({
            height: '268px'
          },500,function(){
            morelink.html('查看更多>')
          })

        }
      })



      setTimeout(function(){
        // alert(that.initialSlide)
        var swiper = new Swiper(".mySwiper", {
          spaceBetween: 10,
          slidesPerView: 9,
          // slidesPerView: "auto",
          freeMode: true,
          watchSlidesProgress: false,
        });
        var swiper2 = new Swiper(".mySwiper2", {
          spaceBetween: 0,
          slidesPerView: 1,
          initialSlide : that.initnum,//默认第三页
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          thumbs: {
            swiper: swiper,
          },
        });
      },800)


    }
  }
</script>

<style scoped="scoped" lang="scss">
  .yewuinfo{

    .yewuwrap{

      .yewuintro{
        display: flex;
        justify-content: space-between;
        .yewuintrol{
          width: 810px;
          h2{
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            position: relative;
            padding-left: 18px;
            line-height: 100%;
            margin-top: 40px;
            margin-bottom: 10px;
          }
          h2::before{
            content: "";
            width: 8px;
            height: 20px;
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: -9px;
            background-color: #b80816;

          }
          .yewuintrowrap{
            height: 268px;
            overflow: hidden;
          }
          p{
            font-size: 18px;
            color: #666666;
            text-indent: 2em;
            line-height: 28px;
            strong{
              font-weight: bold;
              color: #333;
            }
          }
          p:nth-of-type(3){
            margin-top: 12px;
          }
          a{
            margin-right: 0;
          }
        }
        .yewuintror{
          margin-top: 40px;
          position: relative;
          cursor: pointer;
          strong{
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 58px;
            color: #fff;
            width: 114px;
            border-bottom: 3px solid #fff;
            text-align: center;
            left: 50%;
            margin-left: -57px;
            padding-bottom: 5px;
            transition: all .3s linear 0s;
            a,a:hover{
              color: #fff!important;
            }
          }
        }
        .yewuintror:Hover strong{
          transform: scale(1.1);
          top: 55px;
        }
      }
    }
    .yewurun{
      height: 492px;
      margin-top: 60px;
      min-width: 1200px;
      background: url(../../../assets/yewurunbg.jpg) no-repeat center;
      overflow: hidden;
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        color: #fff;
        margin-top: 60px;
        line-height: 100%;
        margin-bottom: 40px;
      }
      .yewurunbox{
        position: relative;
        .swiper{
          width: 1100px;
          margin: 0 auto;
        }
        .mySwiper{
          // overflow: hidden;
          .swiper-wrapper{
            display: flex;
            flex-wrap: wrap;
          }
          .swiper-slide:nth-child(9){
            margin-right: 0 !important;
          }
          .swiper-slide::after{
            content: "";
            width: 20px;
            height: 20px;
            background-color: #fff;
            position: absolute;
            bottom: -35px;
            left: 50%;
            margin-left: -10px;
            transform: rotate(45deg);
            opacity: 0;
            transition: all .2s linear 0s;
          }
          .swiper-slide{
            position: relative;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            padding: 0 15px;
            white-space: nowrap;
            width: auto !important;
            height: 40px;
            background: rgba(255,255,255,.2);
            text-align: center;
            line-height: 40px;
            transition: all .3s linear 0s;
            margin-top: 10px;
          }
          .swiper-slide-thumb-active{
            background: #b80816;
          }
          .swiper-slide-thumb-active::after{
            opacity: 1;
          }
        }
        .mySwiper2{
          margin-top: 25px;
          overflow: hidden;
          .swiper-button-next, .swiper-button-prev{
            top: 62%;
            background-repeat: no-repeat;
            background-position: center;
          }
          .swiper-button-next{
            background-image: url(../../../assets/right.png);
          }
          .swiper-button-prev{
            background-image: url(../../../assets/left.png);
          }
          .swiper-button-next:Hover{
            background-image: url(../../../assets/right-s.png);
          }
          .swiper-button-prev:hover{
            background-image: url(../../../assets/left-s.png);
          }
          .swiper-button-next:after, .swiper-button-prev:after{
           content: "";
          }

          .swiper-slide{
            background: #fff;
            padding-bottom: 30px;
            .swiperbox{
              padding: 0 54px;
              h3{
                font-size: 20px;
                color: #414141;
                line-height: 100%;
                padding: 30px 0 22px 0;
                border-bottom: 1px solid #dfdfdf;
                margin-bottom: 18px;
              }
              p{
                line-height: 28px;
                font-size: 18px;
              }
            }
          }
        }
      }
    }
    .jdal{
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      .jdalwrap{
        position: relative;
        img{
          position: absolute;
          top: 51px;
          left: 615px;
          z-index: -1;
        }
        .jdalwrapbox::before{
          content: "";
          height: 35px;
          width: 16px;
          background-color: #b80816;
          position: absolute;
          top: 0;
          left: 28px;
        }
        .jdalwrapbox{
          // padding-bottom: 42px;
          position: relative;
          width: 762px;
          box-shadow: 0 0 8px #d9d9d9;
          overflow: hidden;
          background: #fff;
          height: 470px;
          ul{
            margin-top: 28px;
            margin-left: 72px;
            width: 618px;

            li:before{
              content: "";
              width: 5px;
              height: 5px;
              background: #666666;
              position: absolute;
              left: 0;
              top: 50%;
              margin-top: -2.5px;

            }
            li:hover::before{
              background-color: #b80816;
            }
            li:hover{
              background-image: url(../../../assets/linebg-s.png);
            }
            li{
              position: relative;
              padding-bottom: 17px;
              padding-top: 17px;
              border-bottom: 1px solid #eaeaea;
              padding-left: 15px;
              line-height: 20px;
              background: url(../../../assets/linebg.png) no-repeat 594px center;
              a{
                font-size: 18px;
                color: #666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                padding-right: 50px;
              }
            }
          }
        }
        .morelink{
          margin-right: 70px;
        }

      }

    }
    .aboutnew{

      margin-top: 89px;
      background: url(../../../assets/yewunewbg.jpg) no-repeat top center;
      .aboutnewwrap{
        position: relative;
        overflow: hidden;
        height: 533px;
        strong{
          font-size: 30px;
          color: #fff;
          display: block;
          line-height: 100%;
          text-align: center;
          margin-top: 45px;
          margin-bottom: 36px;
        }
        .aboutnewbox{
          background: #fff;
          height: 420px;
          width: 100%;
          position: absolute;
          top: 110px;

          .aboutnewzw{
            display: flex;
          }
          ul{
            width: 618px;
            box-shadow: 0 0 8px #b5b5b5;
            padding: 30px 45px;
            li:hover{
              background-image: url(../../../assets/newicon-s.jpg);
            }
            li{
              height: 56px;
              border-bottom: 1px solid #eaeaea;
              line-height: 56px;
              display: flex;
              justify-content: space-between;
              background: url(../../../assets/newicon.jpg) no-repeat 3px center;
              padding-left: 31px;
              a{
                font-size: 18px;
                color: #666666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 75%;
              }
              span{
                font-size: 16px;
                color: #666666;
              }
            }
          }
        }
        .morelink{
          position: absolute;
          bottom: 35px;
          right: 0;
          margin-right: 45px;
        }
      }
    }
    .yewuline{
      margin-top: 50px;
    }
  }
</style>
