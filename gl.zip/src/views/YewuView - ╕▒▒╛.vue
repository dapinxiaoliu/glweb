<template>
  <div class="yewu">
    <div class="ban"><img src="@/assets/yewuban.jpg" class="autoc"></div>
    <div class="yewubox w1200">
      <div class="item minshi">
        <h2>民事诉讼</h2>
        <div class="itemwrap">
          <ul>
          	<li><router-link to="/yewu/info">申请政府信息公开</router-link></li>
          	<li><router-link to="">诉征收决定</router-link></li>
          	<li><router-link to="">诉强拆违法</router-link></li>
          	<li><router-link to="">诉征收补偿决定</router-link></li>
          	<li><router-link to="">行政赔偿</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item xingzheng">
        <h2>行政诉讼</h2>
        <div class="itemwrap">
          <ul>
          	<li><router-link to="">申请政府信息公开</router-link></li>
          	<li><router-link to="">诉征收决定</router-link></li>
          	<li><router-link to="">诉强拆违法</router-link></li>
          	<li><router-link to="">诉征收补偿决定</router-link></li>
          	<li><router-link to="">行政赔偿</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item gongsi xiaoguo">
        <h2>公司业务</h2>
        <span class="iteml"></span>
        <span class="itemr"></span>
        <div class="itemwrap">
          <div class="itemrun">
            <ul>
            	<li><router-link to="">申请政府信息公开</router-link></li>
            	<li><router-link to="">诉征收决定</router-link></li>
            	<li><router-link to="">诉强拆违法</router-link></li>
            	<li><router-link to="">诉征收补偿决定</router-link></li>
            	<li><router-link to="">行政赔偿</router-link></li>
            </ul>
            <ul>
            	<li><router-link to="">申请政府信息公开</router-link></li>
            	<li><router-link to="">诉征收决定</router-link></li>
            	<li><router-link to="">诉强拆违法</router-link></li>
            	<li><router-link to="">诉征收补偿决定</router-link></li>
            	<li><router-link to="">行政赔偿</router-link></li>
            </ul>
            <ul>
            	<li><router-link to="">申请政府信息公开</router-link></li>
            	<li><router-link to="">诉征收决定</router-link></li>
            	<li><router-link to="">诉强拆违法</router-link></li>
            	<li><router-link to="">诉征收补偿决定</router-link></li>
            	<li><router-link to="">行政赔偿</router-link></li>
            </ul>
            <ul>
            	<li><router-link to="">申请政府信息公开</router-link></li>
            	<li><router-link to="">诉征收决定</router-link></li>
            	<li><router-link to="">诉强拆违法</router-link></li>
            	<li><router-link to="">诉征收补偿决定</router-link></li>
            	<li><router-link to="">行政赔偿</router-link></li>
            </ul>
            <ul>
            	<li><router-link to="">申请政府信息公开</router-link></li>
            	<li><router-link to="">诉征收决定</router-link></li>
            	<li><router-link to="">诉强拆违法</router-link></li>
            	<li><router-link to="">诉征收补偿决定</router-link></li>
            	<li><router-link to="">行政赔偿</router-link></li>
            </ul>
            <ul>
            	<li><router-link to="">申请政府信息公开</router-link></li>
            	<li><router-link to="">诉征收决定</router-link></li>
            	<li><router-link to="">诉强拆违法</router-link></li>
            	<li><router-link to="">诉征收补偿决定</router-link></li>
            	<li><router-link to="">行政赔偿</router-link></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="item xingshi">
        <h2>刑事诉讼</h2>
        <div class="itemwrap">
          <ul>
          	<li><router-link to="">申请政府信息公开</router-link></li>
          	<li><router-link to="">诉征收决定</router-link></li>
          	<li><router-link to="">诉强拆违法</router-link></li>
          	<li><router-link to="">诉征收补偿决定</router-link></li>
          	<li><router-link to="">行政赔偿</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item zhishi">
        <h2>知识产权诉讼</h2>
        <div class="itemwrap">
          <ul>
          	<li><router-link to="">申请政府信息公开</router-link></li>
          	<li><router-link to="">诉征收决定</router-link></li>
          	<li><router-link to="">诉强拆违法</router-link></li>
          	<li><router-link to="">诉征收补偿决定</router-link></li>
          	<li><router-link to="">行政赔偿</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item jiaotong">
        <h2>交通事故诉讼</h2>
        <div class="itemwrap">
          <ul>
          	<li><router-link to="">申请政府信息公开</router-link></li>
          	<li><router-link to="">诉征收决定</router-link></li>
          	<li><router-link to="">诉强拆违法</router-link></li>
          	<li><router-link to="">诉征收补偿决定</router-link></li>
          	<li><router-link to="">行政赔偿</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item shewai">
        <h2>涉外业务</h2>
        <div class="itemwrap">
          <ul>
          	<li><router-link to="">申请政府信息公开</router-link></li>
          	<li><router-link to="">诉征收决定</router-link></li>
          	<li><router-link to="">诉强拆违法</router-link></li>
          	<li><router-link to="">诉征收补偿决定</router-link></li>
          	<li><router-link to="">行政赔偿</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item zhaobiao">
        <h2>招投标业务</h2>
        <div class="itemwrap">
          <ul>
          	<li><router-link to="">申请政府信息公开</router-link></li>
          	<li><router-link to="">诉征收决定</router-link></li>
          	<li><router-link to="">诉强拆违法</router-link></li>
          	<li><router-link to="">诉征收补偿决定</router-link></li>
          	<li><router-link to="">行政赔偿</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item shangshi">
        <h2>商事业务</h2>
        <div class="itemwrap">
          <ul>
          	<li><router-link to="">申请政府信息公开</router-link></li>
          	<li><router-link to="">诉征收决定</router-link></li>
          	<li><router-link to="">诉强拆违法</router-link></li>
          	<li><router-link to="">诉征收补偿决定</router-link></li>
          	<li><router-link to="">行政赔偿</router-link></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
import $ from 'jquery'
$(function(){
  let itemul = $('.xiaoguo ul')
  let itemrun = $('.xiaoguo .itemrun')
  let iteml = $('.xiaoguo .iteml')
  let itemr = $('.xiaoguo .itemr')
  let uw = itemul.width()
  let usize = itemul.length
  let totalw = uw * usize
  let timeid = null
  let rw = uw * (usize-1);
  let locks = false;

  if(usize >= 2){
    itemrun.width(totalw)
    iteml.click(function(){
      clearTimeout(timeid)
      timeid = setTimeout(function() {
        let itemleft = parseInt($('.xiaoguo .itemrun').css('left'))
        if(itemleft >= 0){
          itemrun.css('left',0)
        }else{
          itemrun.animate({
            'left': "+="+uw + 'px'
          },200)
        }
      }, 180);


    })
    itemr.click(function(){
      clearTimeout(timeid)
      let itemleft = parseInt($('.xiaoguo .itemrun').css('left'))
      timeid = setTimeout(function() {
        if(itemleft <= -rw){
          $('.xiaoguo .itemrun').css('left',-rw)
        }else{
          itemrun.animate({
            'left': "-="+uw + 'px'
          },200)
        }
      }, 180);


    })
  }
})
  export default{
    name: 'YewuView',
    components: {
    },
    data(){
      return {}
    }
  }

</script>
<style lang="scss" scoped="scoped">
.container{
  background: #fff !important;
}

.xiaoguo{
  position: relative;
}
.xiaoguo span{
  content: "";
  position: absolute;
  bottom: 16px;
  width: 13px;
  height: 23px;
  cursor: pointer;
  z-index: 100;
  background-position: center;
  background-repeat: no-repeat;
}
.xiaoguo .iteml{
  left: 162px;
  background-image: url(../assets/ywleft.png);
}
.xiaoguo .itemr{
  left: 205px;
  background-image: url(../assets/ywright.png);
}
.xiaoguo .itemwrap{
  position: relative;
  overflow: hidden;
  height: 222px;
}
.xiaoguo .itemwrap .itemrun{
  position: absolute;
  height: 200px;
  left: 0;
}
.xiaoguo .itemwrap .itemrun ul{
  width: 380px;
  float: left;
}
.yewu{
  .yewubox{
    margin-top: 70px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    .item{
      width: 380px;
      margin-bottom: 33px;
      h2{
        height: 101px;
        width: 380px;
        background-repeat: no-repeat;
        background-position: center;
        font-size: 20px;
        text-align: center;
        line-height: 101px;
        color: #fff;
        font-weight: bold;
      }
      .itemwrap{
        border: 1px solid #dcdcdc;
        border-radius: 0 0 6px 6px;
        padding-top: 10px;
        padding-bottom: 50px;
        box-sizing: border-box;
        ul{

        }
        li:hover{
           background: url(../assets/yewuicon-s.png) no-repeat left center;
        }
        li{
          line-height: 100%;
          margin-top: 16px;
          background: url(../assets/yewuicon.png) no-repeat left center;
          padding-left: 16px;
          margin-left: 30px;
          a{
            font-size: 18px;
            color: #666666;
          }
        }
      }
    }
    .minshi h2{
      background-image: url(../assets/minshi.jpg);
    }
    .xingzheng h2{
      background-image: url(../assets/xingzheng.jpg);
    }
    .gongsi h2{
      background-image: url(../assets/gongsi.jpg);
    }
    .xingshi h2{
      background-image: url(../assets/xingshi.jpg);
    }
    .zhishi h2{
      background-image: url(../assets/zhishi.jpg);
    }
    .jiaotong h2{
      background-image: url(../assets/jiaotong.jpg);
    }
    .shewai h2{
      background-image: url(../assets/shewai.jpg);
    }
    .zhaobiao h2{
      background-image: url(../assets/zhaobiao.jpg);
    }
    .shangshi h2{
      background-image: url(../assets/shangshi.jpg);
    }
  }
}
</style>
