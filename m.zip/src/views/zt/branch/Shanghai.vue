<template>
  <div class="branchinfo">
    <div class="comban">
      <img src="../../../assets/branch.jpg" >
      <div>
        <strong>上海冠领</strong><p>全球咨询热线：400-8787-888</p>
      </div>
    </div>
    <div class="branchwrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="yewuinfo">
         <div class="m20">
           <strong>上海冠领</strong>
           <div class="yewuslide">
             <div class="yewuheight">
               <p>北京冠领（上海）律师事务所是经上海市司法局批准成立的专业法律服务机构，冠领上海分所坐落于黄浦江畔，占地近400平的办公地点，不仅交通便捷，而且环境十分优美。 很多人初识“冠领”是通过中央电视台和北京电视台，因为冠领律所是中央电视CCTV12《律师来了》的金牌合作伙伴，律所主任周旭亮、任战敏常年在中央电视台《法律讲堂》《律师来了》以及北京电规台《法治进行时》《第三调解室》《律师门诊室》...</p>
               <p>北京冠领（上海）律师事务所是经上海市司法局批准成立的专业法律服务机构，冠领上海分所坐落于黄浦江畔，占地近400平的办公地点，不仅交通便捷，而且环境十分优美。 很多人初识“冠领”是通过中央电视台和北京电视台，因为冠领律所是中央电视CCTV12《律师来了》的金牌合作伙伴，律所主任周旭亮、任战敏常年在中央电视台《法律讲堂》《律师来了》以及北京电规台《法治进行时》《第三调解室》《律师门诊室》等经典法制栏目中现身说法。 冠领上海分所依托冠领北京总所强大的师资力量，汇集了一批毕业于法学专业顶尖学府的饱学之士。冠领律所与中国政法大学刑事司法学院达成战略合作，成为中国政法大学实践基地，并聘请了中国政法大学资深法学专家阮齐林教授、王志远教授、何海波教授担任专家顾问。 在司法实践领域，冠领律所更是“沉淀”和“淬炼”出一批长期奋战在法律实务一线，身经百战的“律界老将”，凭借良好的法学素养、丰富的实战经验、负责任的办案作风，赢得众多企事业单位、社会组织、百姓的信任和好评。 以专业铸造品质，以品质赢得未来，冠领律所秉承一流法律服务，全力打造全国一流律师团队，打造全国一流律师事务所，保障当事人合法权益最大化。</p>
             </div>
           </div>
           <button class="clickmore">点击查看更多</button>
         </div>
       </div>
       <!-- 业务领域 -->
       <div class="yewulingyu">
         <div>
           <h2 class="comh2"><strong>业务领域</strong></h2>
           <ul class="m20">
           	<li><router-link to="/yewu/minshi.html">民事诉讼</router-link></li>
           	<li><router-link to="/yewu/gongsi.html">公司业务</router-link></li>
           	<li><router-link to="/yewu/xingshi.html">刑事诉讼</router-link></li>
           	<li><router-link to="/yewu/zhishi.html">知识产权</router-link></li>
           	<li><router-link to="/yewu/jiaotong.html">交通事故</router-link></li>
            <li><router-link to="/yewu/shangshi.html">商事业务</router-link></li>
           </ul>
         </div>
       </div>
       <!-- 经典案例 -->
       <div class="anli">
         <h2 class="comh2"><strong>经典案例</strong></h2>
         <ul class="m20">
         		<li v-for="item,index in anliData" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
         </ul>
         <router-link to="/case/" class="comlink">查看更多</router-link>
       </div>

       <!-- 相关新闻 -->
       <div class="aboutnews anli">
         <h2 class="comh2"><strong>相关新闻</strong></h2>
         <ul class="m20">
         	<li v-for="item,index in newsData" :key="index"><router-link :to="{path:'/news/'+item.id+'.html'}">{{item.title}}<span>{{item.create_time}} </span> </router-link></li>
         </ul>
         <router-link to="/newslist/" class="comlink">查看更多</router-link>
       </div>
       <!-- 联系方式 -->
       <div class="linaxi">
         <h2 class="comh2"><strong>联系方式</strong></h2>
         <div class="lianxiwrap m20">
           <p>上海市黄浦区人民路300号外滩SOHO广场D幢8层801室</p>           <p>400-8789-888(24小时)</p>
           <div class="linaxiimg">
              <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                  <div class="swiper-slide"><img src="../../../assets/s1.jpg" ></div>
                  <div class="swiper-slide"><img src="../../../assets/s2.jpg" ></div>
                  <div class="swiper-slide"><img src="../../../assets/s3.jpg" ></div>
                  <div class="swiper-slide"><img src="../../../assets/s4.jpg" ></div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
              </div>
           </div>
         </div>
       </div>
       <!-- 到所方式 -->
       <div class="fangshi">
         <h2 class="comh2"><strong>到所方式</strong></h2>
         <div class="m20">
           <div><span>自驾</span><p>导航至外滩SOHO广场D幢</p></div>
           <div><span>地铁</span><p>10号线到豫园地铁站下车1号出站口出站</p></div>
           <div><span>公交</span><p>公交307路、805路、33路、317路、866路等中山东二路新开河路站下、公交932到城隍庙站下、公交911路到新开河路中山东二路站下</p></div>
         </div>
       </div>
       <div class="mapbox" id="admap"></div>
    </div>
  </div>
</template>

<script>
  import {request} from '../../../network/request.js'
  import GLOBAL from '../../../global/global.js'
  import { BMPGL }  from '../../../map/map.js'
  import $ from 'jquery'
  import Swiper from 'swiper'
  import 'swiper/css/swiper.css'
  export default {
    name:'Shanghai',
    data(){
      return{
        breadcrumbList:[],
        newsData:[],
        anliData:[],
        ak:'w1ZAZ1thAXkNOCNO5K0WCBo6dXkfMAbC'
      }
    },
    methods:{
      getAnli(){
        let that = this
        request({
          url: '/Jigou/jganli?id=2',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
              that.anliData = []
              if(jsondata['msg'] == '无数据'){
              }else{
                let newData = jsondata['data'];
                that.anliData = newData
              }
          }]
        })
      },
      getnews(){
        let that = this
        request({
          url: '/Jigou/jgnews?id=50',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
              that.newsData = []
              if(jsondata['msg'] == '无数据'){
              }else{
                let newData = jsondata['data'];
                newData.forEach(function(val){
                    val['create_time'] = val['create_time'].split(' ')[0]
                    that.newsData.push(val)
                });
              }
          }]
        })
      },
      initMap() {
        // 传入密钥获取地图回调。
        BMPGL(this.ak).then((BMapGL) => {
          // 创建地图实例
          let map = new BMapGL.Map("admap");
          // 创建点坐标 axios => res 获取的初始化定位坐标
          let point = new BMapGL.Point(121.500239,31.235464)
          // 初始化地图，设置中心点坐标和地图级别
          map.centerAndZoom(point, 16)
          //开启鼠标滚轮缩放
          map.enableScrollWheelZoom(true)

          // 创建点标记
          let marker = new BMapGL.Marker(point);
          map.addOverlay(marker);
          // 创建信息窗口
          let opts = {
              width: 200,
              height: 100,
              title: '北京冠领（上海）律师事务所'
          };
          let infoWindow = new BMapGL.InfoWindow('地址：上海市黄浦区人民路300号外滩SOHO广场D幢8层801室', opts);
          // 点标记添加点击事件
          marker.addEventListener('click', function () {
              map.openInfoWindow(infoWindow, point); // 开启信息窗口
          });

        })
        .catch((err)=>{
          console.log(err)
        })
      }
    },
    mounted() {
      this.getnews()
      this.getAnli()
      this.initMap()
      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'shanghai'){
          $(".chonggou a[href$='/branch']").attr('class','router-link-active')
        }
      })

      let clickmore = $('.clickmore')
      let yewuslide = $('.yewuslide')
      let h = $('.yewuheight').outerHeight()/1.35
      let is = 0
      clickmore.click(function(){
        if(is == 0){
          yewuslide.find('p').eq(0).hide()
          yewuslide.find('p').eq(1).show()
          $(this).html('点击收起更多')
          yewuslide.animate({
            height: h
          })
          is = 1
        }else{
          yewuslide.find('p').eq(1).hide()
          yewuslide.find('p').eq(0).show()
          $(this).html('点击查看更多')
          yewuslide.animate({
            height: '3.4rem'
          })
          is = 0
        }
      })



      var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 35,
        loop: true,
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .branchinfo{
    .branchwrap{
      .yewuinfo{
         border-bottom: .2rem solid #f3f3f3;
         padding-bottom: .3rem;
        strong{
          font-size: .3rem;
          font-weight: bold;
          display: block;
          border-bottom: 1px solid #dedede;
          width: 3.8rem;
          margin: .35rem auto .2rem;
          text-align: center;
          padding-bottom: .18rem;
        }
        .yewuslide{
          height: 3.4rem;
          overflow: hidden;
          .yewuheight{
            padding-bottom: .2rem;
          }
          p{
            font-size: .28rem;
            line-height: .4rem;
            margin-top: .22rem;
            text-indent: .5rem;
          }
        }
        button.clickmore{
          cursor: pointer;
          font-size: .28rem;
          color: #b80816;
          display: inline-block;
          float: right;
          margin-top: -.36rem;
          position: relative;
          z-index: 99;
          line-height: 100%;
          background: #fff;
          // right: 0;
          width: 2rem;
          white-space: nowrap;
        }
      }
      .yewulingyu{
        border-bottom: .2rem solid #f3f3f3;
        padding-bottom: .1rem;
        ul{
          display: flex;
          flex-wrap: wrap;
          justify-content: flex-start;
          margin-top: .3rem;
          li:nth-child(4){
            margin-right: 0;
          }
          li{
            height: .5rem;
            width: 1.62rem;
            background: #eeeeee;
            text-align: center;
            line-height: .5rem;
            margin-right: .2rem;
            margin-bottom: .2rem;
            font-size: .24rem;
            cursor: pointer;
            a{
               color: #666666;
            }
          }
          li.curr{
            background: #b80816;

            a{
              color: #fff
            }
          }

        }
      }
      .anli{
        border-bottom: .2rem solid #f3f3f3;
        ul{
          li{
            line-height: .36rem;
            padding: .2rem 0;
            border-bottom: 1px solid #e5e5e5;

            a{
              color:#333;
              font-size: .28rem;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
          }
        }
      }
      .aboutnews{
        ul{
          li::after{
            content:'';
            width: .06rem;
            height: .06rem;
            background: #b80816;
            border-radius: 50%;
            position: absolute;
            left: 0;
            top: .4rem;
          }
          li{
            padding: 0;
            overflow: hidden;
            height: 1.38rem;
            border-bottom: 1px dashed #e5e5e5;
            position: relative;
            text-indent: .2rem;
            position: relative;
            span{
              position: absolute;
              bottom: .08rem;
              right: .06rem;
              color: #999999;
            }
            a{
              margin-top: .22rem;
            }
          }
        }
      }
      .linaxi{
          border-bottom: .2rem solid #f3f3f3;
        .lianxiwrap{
          overflow: hidden;
          p{
            font-size: .28rem;
            background-repeat: no-repeat;
            background-position: .02rem center;
            background-size: .25rem;
            text-indent: .35rem;
            white-space: nowrap;
            letter-spacing: -.01rem;
            line-height: .36rem;
          }
          p:nth-of-type(1){
            margin-top: .2rem;
            margin-bottom: .2rem;
            background-image: url(../../../assets/mapicon.png);
          }
          p:nth-of-type(2){
            margin-bottom: .2rem;
            background-image: url(../../../assets/telicon.png);
          }
          .linaxiimg{
            position: relative;
            width: 6.47rem;
            height: 2.44rem;
            margin: 0 auto .3rem;


            .swiper-button-prev{
              left: -.52rem;
            }
            .swiper-button-next{
              right: -.52rem;
            }
            .swiper-button-prev,.swiper-button-next{
               background: #fff;
               height: 2.65rem;
               top: 53%;
               width: 0.51rem;
               margin-top: -1.3rem;
            }
            .swiper-button-prev:after, .swiper-button-next:after{
              content:"";
              background-repeat: no-repeat;
              background-size: .16rem .28rem;
              background-position: center;
              width: .16rem;
              height: .28rem;
              background-color: transparent !important;
            }
            .swiper-button-prev:after{
              margin-right: -.06rem;
              background-image: url(../../../assets/ourleft.jpg);
            }
            .swiper-button-prev:hover:after{
              background-image: url(../../../assets/ourleft-s.jpg);
            }
            .swiper-button-next:after{
              margin-left: -.06rem;
              background-image: url(../../../assets/ourright.jpg);
            }
            .swiper-button-next:hover:after{
              background-image: url(../../../assets/ourright-s.jpg);
            }
          }
        }
      }
      .fangshi{
        margin-bottom: .3rem;
        .m20{
          div:nth-of-type(1){
            background-image: url(../../../assets/qiche.png);
            background-size: .25rem .19rem;
          }
          div:nth-of-type(2){
            background-image: url(../../../assets/ditie.png);
            background-size: .23rem;
          }
          div:nth-of-type(3){
            background-position: left .05rem;
            background-image: url(../../../assets/gongjiao.png);
            background-size: .19rem .24rem;
          }
          div{
            display: flex;
            font-size: .24rem;
            color: #666;
            line-height: .36rem;
            margin-top: .2rem;
            background-repeat: no-repeat;
            background-position: left center;
            span{
              width: .7rem;
              white-space: nowrap;
              margin-left: .3rem;
            }
            p{
              width: 100%;
            }
            // background-size: ;
          }
          div:nth-of-type(1){
            margin-top: .25rem;
          }
        }
      }
      .mapbox{
        width: 7.1rem;
        height: 3.1rem;
        margin: 0 auto .4rem;
      }
    }
  }
</style>
