<template>
<div class="yewu">
 <div class="linebanbox">
   <img src="../assets/yewulinebg.jpg" class="autoc" >
   <div class="linebanhead">
     <strong>全球业务</strong>
     <small>全球咨询热线：400-8789-888</small>
   </div>
 </div>
    <router-view></router-view>
    <div class="yewubox w1200">
      <div class="item minshi">
        <h2><img src="../assets/minshi.jpg" ><router-link :to="{path: '/yewu/minshi.html'}">民事诉讼</router-link></h2>
        <div class="itemwrap" v-loading="loading" :element-loading-text="loadtext">
          <ul>
          	<li v-for="item,index in lmData[0]['child']" :key="index"><router-link :to="{path: '/yewu/minshi.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>
          </ul>
          <div class="itembtn">
            <button class="lbtn"></button>
            <button class="rbtn"></button>
          </div>
        </div>
      </div>
      <div class="item xingzheng">
        <h2><img src="../assets/xingzheng.jpg" ><router-link :to="{path: '/yewu/xingzheng.html'}">行政诉讼</router-link></h2>
        <div class="itemwrap" >
          <ul>
          	<li v-for="item,index in lmData[1]['child']" :key="index"><router-link :to="{path: '/yewu/xingzheng.html', query:{'id':item.id}}">{{item.name}}</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item gongsi">
        <h2><img src="../assets/gongsi.jpg" ><router-link :to="{path: '/yewu/gongsi.html'}">公司业务</router-link></h2>
        <div class="itemwrap">
            <ul>
            	<li v-for="item,index in lmData[2]['child']" :key="index"><router-link :to="{path: '/yewu/gongsi.html.html',query: {id: item.id}}">{{item.name}}</router-link></li>
            </ul>
            <div class="itembtn">
              <button class="lbtn"></button>
              <button class="rbtn"></button>
            </div>
        </div>
      </div>
      <div class="item xingshi moreli" >
        <h2><img src="../assets/xingshi.jpg" ><router-link :to="{path: '/yewu/xingshi.html'}">刑事诉讼</router-link></h2>

        <div class="itemwrap">

          <ul>
          	<li v-for="item,index in lmData[3]['child']" :key="index"><router-link :to="{path: '/yewu/xingshi.html',query:{id:item.id}}">{{item.name}}</router-link></li>
          </ul>
          <div class="itembtn">
            <button class="lbtn"></button>
            <button class="rbtn"></button>
          </div>
        </div>


      </div>
      <div class="item zhishi">
        <h2><img src="../assets/zhishi.jpg" ><router-link :to="{path: '/yewu/zhishi.html'}">知识产权诉讼</router-link></h2>
        <div class="itemwrap">
          <ul>
          	<li v-for="item,index in lmData[4]['child']" :key="index"><router-link :to="{path: '/yewu/zhishi.html',query:{id:item.id}}">{{item.name}}</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item jiaotong">
        <h2><img src="../assets/jiaotong.jpg" ><router-link :to="{path: '/yewu/jiaotong.html'}">交通事故诉讼</router-link></h2>
        <div class="itemwrap">
          <ul>
          	<li v-for="item,index in lmData[5]['child']" :key="index"><router-link :to="{path: '/yewu/jiaotong.html',query:{id:item.id}}">{{item.name}}</router-link></li>
          </ul>
        </div>
      </div>
      <div class="item shewai moreli">
        <h2><img src="../assets/shewai.jpg" ><router-link :to="{path: '/yewu/shewai.html'}">涉外业务</router-link></h2>
        <div class="itemwrap">
          <ul>
          	<li v-for="item,index in lmData[6]['child']" :key="index"><router-link :to="{path: '/yewu/shewai.html',query:{id:item.id}}">{{item.name}}</router-link></li>
          </ul>
          <div class="itembtn">
            <button class="lbtn"></button>
            <button class="rbtn"></button>
          </div>
        </div>
      </div>
      <div class="item zhaobiao">
        <h2><img src="../assets/zhaobiao.jpg" ><router-link :to="{path: '/yewu/zhaobiao.html'}">招投标业务</router-link></h2>
        <div class="itemwrap">
          <ul>
          	<li v-for="item,index in lmData[7]['child']" :key="index"><router-link :to="{path: '/yewu/zhaobiao.html',query:{id:item.id}}">{{item.name}}</router-link></li>
          </ul>
          <div class="itembtn">
            <button class="lbtn"></button>
            <button class="rbtn"></button>
          </div>
        </div>
      </div>
      <div class="item shangshi">
        <h2><img src="../assets/shangshi.jpg" ><router-link :to="{path: '/yewu/shangshi.html'}">商事业务</router-link></h2>
        <div class="itemwrap">
          <ul>
          	<li v-for="item,index in lmData[8]['child']" :key="index"><router-link :to="{path: '/yewu/shangshi.html',query:{id:item.id}}">{{item.name}}</router-link></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
</div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
 export default{
   name: 'YewuhomeView',
   components: {

   },
   data(){
     return{
       lmData:[],
       loadtext:'',
       loading:false
     }
   },
   methods:{
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lmData = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                // newData.forEach(function(val){
                //   val['id']
                //   val['child'].forEach(function(item){
                //     item['']
                //   })
                // })
                 that.lmData = newData
                 // console.log(newData);
                 // console.log(newData);

              }
            }
          }]
        })
      }
   },
   mounted(){
    this.$nextTick(function(){
      $(".chonggou a").attr('class','')
      if(this.$route.name == 'yewu'){
        $(".chonggou a[href$='/yewu']").attr('class','router-link-active')
      }
    })
    this.getlmData()

  setClick('.zhaobiao')
  setClick('.xingshi')
  setClick('.shewai')
  setClick('.minshi')
  setClick('.gongsi')
  function setClick(domul){
    setTimeout(function(){
      let itemli = $(domul+' li')
      let mul = $(domul+' ul')
      let liw = itemli.eq(0).innerWidth()
      let lih = itemli.eq(0).innerHeight()
      let uw = mul.width()
      mul.width(liw*2)
      let mtop = 0
      // alert(itemli.length)
      if(itemli.length > 5){
        $(domul+ ' li:gt(4)').css({
          'position':'absolute',
          'left':'55%',
          'top':'0',
          'margin-top':'0'
        })
        $(domul+ ' li:gt(4)').each(function(){
          let index = $(this).index()
          if(index != 5){
            mtop++
           $(this).css('top',(20+lih)*mtop)
          }
        })
      }
      //追加左右按钮
      $(domul+' .lbtn').click(function(){
        mul.animate({'left': 0})
      })
      $(domul+' .rbtn').click(function(){
        mul.animate({'left': -uw})
      })

    },500)
  }




   }

 }
</script>

<style lang="scss" scoped>
.container{
  background: #fff !important;
}
.item .itembtn{
  display: flex;
  justify-content: center;
  margin-top: 10px;
}
.item button{
  background: transparent;
  border: none;
  width: 13px;
  height: 23px;
  background-repeat: no-repeat;
  background-position: center;
  cursor: pointer;
  margin: 0 10px;
}
.item button.lbtn{
  background-image: url(../assets/ywleft.png);
}
.item button.lbtn:hover{
  background-image: url(../assets/ywleft-s.png);
}
.item button.rbtn{
  background-image: url(../assets/ywright.png);
}
.item button.rbtn:hover{
  background-image: url(../assets/ywright-s.png);
}
.yewu{
  .yewubox{
    margin-top: 70px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    item:nth-child(n+4){
      margin-top: 33px;
    }

    .item{
      width: 380px;
      overflow: hidden;
      position: relative;
      margin-bottom: 50px;
      h2:hover img{
        transform: scale(1.1);
      }
      h2{
        height: 101px;
        width: 380px;
        font-size: 20px;
        text-align: center;
        line-height: 101px;
        color: #fff;
        font-weight: bold;
        transition: all .3s linear 0s;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        img{
          transition: all .3s linear 0s;
        }
        a{
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          text-align: center;
          color: #fff;
        }
        a:hover{
          color: #fff !important;
        }
      }
      .itemwrap{
        border: 1px solid #dcdcdc;
        border-radius: 0 0 6px 6px;
        padding-top: 10px;
        padding-bottom: 50px;
        box-sizing: border-box;
        height: 220px;
        // overflow: hidden;
        position: relative;
        ul{
          position: relative;
          left: 0;
        }
        li:hover{
           background: url(../assets/yewuicon-s.png) no-repeat left center;
        }
        li{
          width: 332px;
          line-height: 100%;
          margin-top: 16px;
          background: url(../assets/yewuicon.png) no-repeat left center;
          padding-left: 16px;
          margin-left: 30px;
          a{
            font-size: 18px;
            color: #666666;
          }
        }
      }
    }
    .item:nth-child(n+7){
      margin-bottom: 0;
    }
    h2:hover{
      background-size: 120%;
    }


  }


}
</style>
