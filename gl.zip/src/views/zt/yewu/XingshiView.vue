<template>
  <div class="yewuinfo">
    <div class="linebanbox">
      <img src="../../../assets/yewuinfoline.jpg" class="autoc">
      <div class="linebanhead">
        <strong>刑事诉讼</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="yewuwrap w1200">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
          <el-breadcrumb-item>{{nowname}}</el-breadcrumb-item>

        </el-breadcrumb>
      </div>
      <div class="yewuintro">
        <div class="yewuintrol">
          <h2>刑事诉讼</h2>
          <div class="yewuintrowrap">
            <div class="yewuintrowraph">

            <p>刑事诉讼，是指人民法院、人民检察院和公安机关在当事人及其他诉讼参与人的参加下，依照法律规定的程序，解决被追诉者刑事责任问题的活动。</p>
            <p>北京冠领律师事务所办理全国各类刑事案件经验丰富，在经济犯罪、职务犯罪、毒品犯罪、人身暴力犯罪以及其他常见刑事案件中具有丰富的辩护经验。</p>
            <p>冠领律师成功代理多起重大刑事案件，具备严谨的逻辑推理能力和敏捷的开庭应变能力，辩护意见针对性强，大多被法庭采纳。</p>
            <p>刑事案件分为自诉案件和公诉案件。</p>
            <p>自诉案件，是指刑事诉讼法规定被害人直接向人民法院提起刑事诉的案件。自诉案件的具体流程：被害人向人民法院起诉，由人民法院进行审理，作出有罪或无罪的判决，最后交执行机关执行。</p>
            <p>公诉案件，是指由人民检察院代表国家向人民法院提起公诉，追究犯罪嫌疑人刑事责任的案件。公诉案件的具体流程为：</p>
            <p>1、侦查</p>
            <p>公安机关对于现行犯或者重大嫌疑分子可以刑事拘留。对于被拘留的人，应当在拘留后的24小时以内进行讯问。</p>
            <p>犯罪嫌疑人在被侦查机关第一次讯问后或者采取强制措施之日起，可以聘请律师为其提供法律咨询、代理申诉、控告。</p>
            <p>受委托的律师有权向侦查机关了解犯罪嫌疑人涉嫌的罪名，可以会见在押的犯罪嫌疑人，向犯罪嫌疑人了解有关的案件情况。</p>
            <p>公安机关对被拘留的人，认为需要逮捕的，应当在拘留后的三日以内，提请人民检察院审查批准。在特殊情况下，提请审查批准的时间可以延长一日至四日。对于流窜作案、多次作案、结伙作案的重大嫌疑分子，提请审查批准的时间可以延长至三十日。</p>
            <p>人民检察院应当自接到公安机关提请批准逮捕书后的七日以内，作出批准逮捕或者不批准逮捕的决定。人民检察院不批准逮捕的，公安机关应当在接到通知后立即释放，并且将执行情况及时通知人民检察院。对于需要继续侦查，并且符合取保候审、监视居住条件的，依法取保候审或者监视居住。</p>
            <p>犯罪嫌疑人被逮捕的，聘请的律师可以为其申请取保候审。</p>
            <p>公安机关对犯罪嫌疑人逮捕后的侦查羁押期限不得超过二个月。案情复杂、期限届满不能终结的案件，可以经上一级人民检察院批准延长一个月。</p>
            <p>公安机关侦查终结的案件，应当做到犯罪事实清楚，证据确实、充分，并且写出起诉意见书，连同案卷材料、证据一并移送同级人民检察院审查决定。</p>
            <p>2、审查起诉</p>
            <p>人民检察院审查案件，应当讯问犯罪嫌疑人，听取被害人和犯罪嫌疑人、被害人委托的人的意见。</p>
            <p>公诉案件自案件移送审查起诉之日起，犯罪嫌疑人有权委托辩护人。自诉案件的被告人有权随时委托辩护人。</p>
            <p>人民检察院自收到移送审查起诉的案件材料之日起三日以内，应当告知犯罪嫌疑人有权委托辩护人。人民法院自受理自诉案件之日起三日以内，应当告知被告人有权委托辩护人。</p>
            <p>辩护律师自人民检察院对案件审查起诉之日起，可以查阅、摘抄、复制本案的诉讼文书、技术性鉴定材料，可以同在押的犯罪嫌疑人会见和通信。</p>
            <p>人民检察院对于公安机关移送起诉的案件，应当在一个月以内作出决定，重大、复杂的案件，可以延长半个月。</p>
            <p>人民检察院认为犯罪嫌疑人的犯罪事实已经查清，证据确实、充分，依法应当追究刑事责任的，应当作出起诉决定，按照审判管辖的规定，向人民法院提起公诉。</p>
            <p>3、审判</p>
            <p>人民法院对提起公诉的案件进行审查后，对于起诉书中有明确的指控犯罪事实并且附有证据目录、证人名单和主要证据复印件或者照片的，应当决定开庭审判。除涉及国家秘密或者个人隐私的案件，人民法院审判第一审案件应当公开进行。</p>
            <p>辩护律师自人民法院受理案件之日起，可以查阅、摘抄、复制本案所指控的犯罪事实的材料，可以同在押的被告人会见和通信。开庭审理时，辩护律师为被告人辩护。</p>
            <p>法庭审理后，人民法院根据已经查明的事实、证据和有关的法律规定，分别作出以下判决：</p>
            <p>（1）案件事实清楚，证据确实、充分，依据法律认定被告人有罪的，应当作出有罪判决；</p>
            <p>（2）依据法律认定被告人无罪的，应当作出无罪判决。</p>
            <p>4、执行</p>
            <p>对有罪的刑事判决，在判决生效后交执行机关执行。执行机关有监狱、看守所、社区、司法所等。</p>
            <p>那么，为什么说刑事案件要尽快委托律师呢？</p>
            <p>首先，当事人面对审讯时，因慌乱容易做出很多不利于自身的陈述，易造成后期的减刑困难和增加罪名的风险。</p>
            <p>其次，因自身受控，当事人容易因各种压力导致失去辩护的信心。此时，律师有权会见当事人，为家属传达信息，并为其提供专业法律指导。</p>
            <p>再次，当事人面对公权力时如果不予配合调查，容易造成不利影响。律师尽早介入，可对其进行专业指导，增强信心，减少后期辩护困难。</p>
            <p>在刑事诉讼中聘请律师，可以提供哪些帮助呢？</p>
            <p>1、调查</p>
            <p>调查取证，了解案件真实情况。律师有权了解公安机关掌握的相关证据，确定可能判处的罪名，调取案卷，提出意见书。</p>
            <p>2、会见</p>
            <p>会见当事人，提供专业法律指导。律师有权会见当事人，可以替家属传达信息，提供专业法律指导。</p>
            <p>3、取保候审</p>
            <p>为当事人申请取保候审。律师可以为犯罪嫌疑人申请取保候审，让当事人离开看守所，获得较大程度的人身自由。</p>
            <p>4、辩护</p>
            <p>制定胜诉方案，代理当事人答辩。北京冠领律师事务所依据案件特点，提供一对一专业服务，为当事人制定辩护防范，进行专业辩护。</p>
            <p>北京冠领律师事务所多为知名院校毕业的法学硕士、博士，执业能力突出，尤其办理重大刑事案件经验非常丰富。多年的执业之路，使冠领律所收获了大量的荣誉和嘉奖。在这光荣背后，是冠领人用汗水一点一滴凝结而成。为当事人谋求利益最大化，是冠领执业能力的最好体现。</p>

            </div>
          </div>

          <router-link to="" class="morelink">查看更多></router-link>
        </div>
        <div class="yewuintror">
          <router-link to="/lawyer/">
            <img src="../../../assets/yewuxgtd.jpg" >
            <strong><router-link to="/lawyer/">相关团队</router-link></strong>
          </router-link>
        </div>
      </div>

    </div>

    <div class="yewurun">
      <strong>行政诉讼</strong>
      <div class="yewurunbox w1200">
        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide swiperbtn" v-for="item,index in lmdata['child']" :key="index" >{{item.name}}</div>
          </div>
        </div>
        <div thumbsSlider="" class="swiper mySwiper2">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>取保候审</h3>
               <p>{{a['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>减刑、免刑、无罪辩护</h3>
                <p>{{b['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>人身损害类犯罪</h3>
               <p>{{c['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>财产损害类犯罪</h3>
                  <p>
                  {{d['description']}}
                  </p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>经济犯罪</h3>
                <p>{{e['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>贪污贿赂犯罪</h3>
                <p>{{f['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>公共安全犯罪</h3>
                <p>{{g['description']}}</p>
              </div>
            </div>


          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
    <!-- 经典案例 -->
    <div class="jdal w1200">
      <strong>经典案例</strong>
      <div class="jdalwrap">
        <div class="jdalwrapbox">
          <ul>
          	<li v-for="item,index in anlidata" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
          </ul>
          <router-link to="/case/" class="morelink">查看更多></router-link>
        </div>
        <img src="../../../assets/anliimg.jpg" >
      </div>
    </div>

    <!-- 相关新闻 -->
    <div class="aboutnew">
      <div class="aboutnewwrap w1200">
        <strong>相关新闻</strong>
        <div class="aboutnewbox">
          <div class="aboutnewzw">
            <div class="aboutnewl"><img src="../../../assets/newleft.jpg" ></div>
            <ul>
            	<li v-for="item,index in newsdata" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">{{item.title}}</router-link><span>{{item.create_time}}</span></li>
            </ul>
          </div>
          <router-link to="/newslist/" class="morelink">查看更多></router-link>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../../../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  import {request} from '../../../network/request.js'
  import GLOBAL from '../../../global/global.js'
  export default{
    name: 'XingshiView',
    data(){
      return{
        breadcrumbList:[],
        lmdata:[],
        lmname:'',
        nowname:'',
        lmid:0,
        isActive: false,
        anlidata:[],
        newsdata:[],
        a:[],
        b:[],
        c:[],
        d:[],
        e:[],
        f:[],
        g:[],
        isSelect:false,
        initnum:0

      }
    },
    methods:{
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)

            if(jsondata['code'] == 200){
              that.lmdata = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                 that.lmdata = newData[3]
                 that.lmname = newData[3]['name']
                // console.log(newData[0]);
                 newData[3]['child'].forEach(function(val){

                    if(val['id'] == that.lmid){
                        that.nowname = val['name']
                    }
                 })
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getanliData(){
        let that = this
        request({
          url: '/lingyu/lyanli?id=8',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.anlidata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.anlidata = jsondata['data'];
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getnewsData(){
        let that = this
        request({
          url: '/lingyu/lynews?id=58',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.newsdata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data']
                newData.forEach(function(val){
                  val['create_time'] = val['create_time'].split(' ')[0]
                  that.newsdata.push(val)
                });
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getlitinfo(id){
        let that = this
        request({
          url: '/lingyu/read?id='+id,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lanmuname = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                switch(id){
                  case 155:
                  that.a = jsondata['data']
                  break;
                  case 156:
                  that.b = jsondata['data']
                  break;
                  case 157:
                  that.c = jsondata['data']
                  break;
                  case 117:
                  that.d = jsondata['data']
                  break;
                  case 158:
                  that.e = jsondata['data']
                  break;
                  case 163:
                  that.f = jsondata['data']
                  break;
                  case 160:
                  that.g = jsondata['data']
                  break;

                }
              }
            }
          }]
        })
      }
    },
    watch:{
      newsdata(){

      }
    },
    created() {

    },
    mounted(){
      let that = this
      this.getlmData()
      this.getanliData()
      this.getnewsData()
      this.getlitinfo(155)
      this.getlitinfo(156)
      this.getlitinfo(157)
      this.getlitinfo(117)
      this.getlitinfo(158)
      this.getlitinfo(163)
      this.getlitinfo(160)
      //获取id
      let lanmuid = this.$route.query['id']
      if(lanmuid != undefined){
          that.lmid = lanmuid
          switch(lanmuid){
            case '155':
            that.initnum = 0
            break;
            case '156':
            that.initnum = 1
            break;
            case '157':
            that.initnum = 2
            break;
            case '117':
            that.initnum = 3
            break;
            case '158':
            that.initnum = 4
            break;
            case '163':
            that.initnum = 5
            break;
            case '160':
            that.initnum = 6
            break;
          }
          // alert($('.yewuwrap').offset().top)
          $('body,html').animate({
                  scrollTop: $('.yewurun').offset().top
          },500);
      }else{
        that.initnum = 0
      }
      // console.log(this.$route.name);
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'xingshi'){
          $(".chonggou a[href$='yewu']").attr('class','router-link-active')
        }
      })


      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      let islock = false;
      let yewuintrowraph = $('.yewuintrowraph')
      let morelink = $('.yewuintrol .morelink')
      morelink.click(function(){
        if(islock == false){
          islock = true
          $('.yewuintrowrap').animate({
            height: yewuintrowraph.height()
          },500,function(){
            morelink.html('收起更多>')
          })

        }else{
          islock = false
          $('.yewuintrowrap').animate({
            height: '268px'
          },500,function(){
            morelink.html('查看更多>')
          })

        }
      })



      setTimeout(function(){
        // alert(that.initialSlide)
        var swiper = new Swiper(".mySwiper", {
          spaceBetween: 10,
          slidesPerView: 9,
          // slidesPerView: "auto",
          freeMode: true,
          watchSlidesProgress: false,
        });
        var swiper2 = new Swiper(".mySwiper2", {
          spaceBetween: 0,
          slidesPerView: 1,
          initialSlide : that.initnum,//默认第三页
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          thumbs: {
            swiper: swiper,
          },
        });
      },800)


    }
  }
</script>

<style scoped="scoped" lang="scss">
  .yewuinfo{

    .yewuwrap{

      .yewuintro{
        display: flex;
        justify-content: space-between;
        .yewuintrol{
          width: 810px;
          h2{
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            position: relative;
            padding-left: 18px;
            line-height: 100%;
            margin-top: 40px;
            margin-bottom: 10px;
          }
          h2::before{
            content: "";
            width: 8px;
            height: 20px;
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: -9px;
            background-color: #b80816;

          }
          .yewuintrowrap{
            height: 268px;
            overflow: hidden;
          }
          p{
            font-size: 18px;
            color: #666666;
            text-indent: 2em;
            line-height: 28px;
            strong{
              font-weight: bold;
              color: #333;
            }
          }
          p:nth-of-type(3){
            margin-top: 12px;
          }
          a{
            margin-right: 0;
          }
        }
        .yewuintror{
          margin-top: 40px;
          position: relative;
          cursor: pointer;
          strong{
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 58px;
            color: #fff;
            width: 114px;
            border-bottom: 3px solid #fff;
            text-align: center;
            left: 50%;
            margin-left: -57px;
            padding-bottom: 5px;
            transition: all .3s linear 0s;
            a,a:hover{
              color: #fff!important;
            }
          }
        }
        .yewuintror:Hover strong{
          transform: scale(1.1);
          top: 55px;
        }
      }
    }
    .yewurun{
      height: 492px;
      margin-top: 60px;
      min-width: 1200px;
      background: url(../../../assets/yewurunbg.jpg) no-repeat center;
      overflow: hidden;
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        color: #fff;
        margin-top: 60px;
        line-height: 100%;
        margin-bottom: 40px;
      }
      .yewurunbox{
        position: relative;
        .swiper{
          width: 1100px;
          margin: 0 auto;
        }
        .mySwiper{
          // overflow: hidden;
          .swiper-wrapper{
            display: flex;
            flex-wrap: wrap;
          }
          .swiper-slide:nth-child(9){
            margin-right: 0 !important;
          }
          .swiper-slide::after{
            content: "";
            width: 20px;
            height: 20px;
            background-color: #fff;
            position: absolute;
            bottom: -35px;
            left: 50%;
            margin-left: -10px;
            transform: rotate(45deg);
            opacity: 0;
            transition: all .2s linear 0s;
          }
          .swiper-slide{
            position: relative;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            padding: 0 15px;
            white-space: nowrap;
            width: auto !important;
            height: 40px;
            background: rgba(255,255,255,.2);
            text-align: center;
            line-height: 40px;
            transition: all .3s linear 0s;
            margin-top: 10px;
          }
          .swiper-slide-thumb-active{
            background: #b80816;
          }
          .swiper-slide-thumb-active::after{
            opacity: 1;
          }
        }
        .mySwiper2{
          margin-top: 25px;
          overflow: hidden;
          .swiper-button-next, .swiper-button-prev{
            top: 62%;
            background-repeat: no-repeat;
            background-position: center;
          }
          .swiper-button-next{
            background-image: url(../../../assets/right.png);
          }
          .swiper-button-prev{
            background-image: url(../../../assets/left.png);
          }
          .swiper-button-next:Hover{
            background-image: url(../../../assets/right-s.png);
          }
          .swiper-button-prev:hover{
            background-image: url(../../../assets/left-s.png);
          }
          .swiper-button-next:after, .swiper-button-prev:after{
           content: "";
          }

          .swiper-slide{
            background: #fff;
            padding-bottom: 30px;
            .swiperbox{
              padding: 0 54px;
              h3{
                font-size: 20px;
                color: #414141;
                line-height: 100%;
                padding: 30px 0 22px 0;
                border-bottom: 1px solid #dfdfdf;
                margin-bottom: 18px;
              }
              p{
                line-height: 28px;
                font-size: 18px;
              }
            }
          }
        }
      }
    }
    .jdal{
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      .jdalwrap{
        position: relative;
        img{
          position: absolute;
          top: 51px;
          left: 615px;
          z-index: -1;
        }
        .jdalwrapbox::before{
          content: "";
          height: 35px;
          width: 16px;
          background-color: #b80816;
          position: absolute;
          top: 0;
          left: 28px;
        }
        .jdalwrapbox{
          // padding-bottom: 42px;
          position: relative;
          width: 762px;
          box-shadow: 0 0 8px #d9d9d9;
          overflow: hidden;
          background: #fff;
          height: 470px;
          ul{
            margin-top: 28px;
            margin-left: 72px;
            width: 618px;

            li:before{
              content: "";
              width: 5px;
              height: 5px;
              background: #666666;
              position: absolute;
              left: 0;
              top: 50%;
              margin-top: -2.5px;

            }
            li:hover::before{
              background-color: #b80816;
            }
            li:hover{
              background-image: url(../../../assets/linebg-s.png);
            }
            li{
              position: relative;
              padding-bottom: 17px;
              padding-top: 17px;
              border-bottom: 1px solid #eaeaea;
              padding-left: 15px;
              line-height: 20px;
              background: url(../../../assets/linebg.png) no-repeat 594px center;
              a{
                font-size: 18px;
                color: #666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                padding-right: 50px;
              }
            }
          }
        }
        .morelink{
          margin-right: 70px;
        }

      }

    }
    .aboutnew{

      margin-top: 89px;
      background: url(../../../assets/yewunewbg.jpg) no-repeat top center;
      .aboutnewwrap{
        position: relative;
        overflow: hidden;
        height: 533px;
        strong{
          font-size: 30px;
          color: #fff;
          display: block;
          line-height: 100%;
          text-align: center;
          margin-top: 45px;
          margin-bottom: 36px;
        }
        .aboutnewbox{
          background: #fff;
          height: 420px;
          width: 100%;
          position: absolute;
          top: 110px;

          .aboutnewzw{
            display: flex;
          }
          ul{
            width: 618px;
            box-shadow: 0 0 8px #b5b5b5;
            padding: 30px 45px;
            li:hover{
              background-image: url(../../../assets/newicon-s.jpg);
            }
            li{
              height: 56px;
              border-bottom: 1px solid #eaeaea;
              line-height: 56px;
              display: flex;
              justify-content: space-between;
              background: url(../../../assets/newicon.jpg) no-repeat 3px center;
              padding-left: 31px;
              a{
                font-size: 18px;
                color: #666666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 75%;
              }
              span{
                font-size: 16px;
                color: #666666;
              }
            }
          }
        }
        .morelink{
          position: absolute;
          bottom: 35px;
          right: 0;
          margin-right: 45px;
        }
      }
    }
    .yewuline{
      margin-top: 50px;
    }
  }
</style>
