import Vue from 'vue'
import Router from 'vue-router'
import HomeView from './views/HomeView.vue'
import JigouView from './views/JigouView.vue'
import BeijingView from "./views/zt/BeijingView.vue"
import ShanghaiView from "./views/zt/ShanghaiView.vue"
import ShenzhenView from "./views/zt/ShenzhenView.vue"
import XianView from "./views/zt/XianView.vue"
import KunmingView from "./views/zt/KunmingView.vue"
import AnliView from './views/AnliView.vue'
import GonggaoView from './views/GonggaoView.vue'
import LawyerView from './views/LawyerView.vue'
import LawyerinfoView from './views/LawyerinfoView.vue'
import NewsView from './views/NewsView.vue'
import YangshiView from './views/YangshiView.vue'
import YangshichildView from './views/YangshichildView.vue'
import YangshiinfoView from './views/YangshiinfoView.vue'
import AboutView from './views/AboutView.vue'
import YewuView from './views/YewuView.vue'
import YewuhomeView from './views/YewuhomeView.vue'
// import YewuinfoView from './views/YewuinfoView.vue'
import MinshiView from './views/zt/yewu/MinshiView.vue'
import XingzhengView from './views/zt/yewu/XingzhengView.vue'
import GongsiView from './views/zt/yewu/GongsiView.vue'
import XingshiView from './views/zt/yewu/XingshiView.vue'
import ZhishiView from './views/zt/yewu/ZhishiView.vue'
import JiaotongView from './views/zt/yewu/JiaotongView.vue'
import ShewaiView from './views/zt/yewu/ShewaiView.vue'
import ZhaobiaoView from './views/zt/yewu/ZhaobiaoView.vue'
import ShangshiView from './views/zt/yewu/ShangshiView.vue'
import HonorView from './views/HonorView.vue'

import ArticalView from './views/ArticlaView.vue'
import AnliarcView from './views/AnliarcView.vue'
import VideoView from './views/VideoView.vue'
import LawyerarcView from './views/LawyerarcView.vue'
import NewsarcView from './views/NewsarcView.vue'
import GonggaoarcView from './views/GonggaoarcView.vue'
import HonorarcView from './views/HonorarcView.vue'

Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/yewu',
      name: 'yewu',
      component: YewuView,
    },
    {
      path: '/yewu/minshi(.*)',
      name: 'minshi',
      component: MinshiView,
      meta:{ parent: [ {path: 'yewu', name: '民事诉讼'}]}
    },
    {
      path: '/yewu/xingzheng(.*)',
      name: 'xingzheng',
      component: XingzhengView,
      meta:{ parent: [ {path: 'yewu', name: '行政诉讼'}]}
    },
    {
      path: '/yewu/gongsi(.*)',
      name: 'gongsi',
      component: GongsiView,
      meta:{ parent: [ {path: 'yewu', name: '公司业务'}]}
    },
    {
      path: '/yewu/xingshi(.*)',
      name: 'xingshi',
      component: XingshiView,
      meta:{ parent: [ {path: 'yewu', name: '刑事诉讼'}]}
    },
    {
      path: '/yewu/zhishi(.*)',
      name: 'zhishi',
      component: ZhishiView,
      meta:{ parent: [ {path: 'yewu', name: '知识产权诉讼'}]}
    },
    {
      path: '/yewu/jiaotong(.*)',
      name: 'jiaotong',
      component: JiaotongView,
      meta:{ parent: [ {path: 'yewu', name: '交通事故诉讼'}]}
    },
    {
      path: '/yewu/shewai(.*)',
      name: 'shewai',
      component: ShewaiView,
      meta:{ parent: [ {path: 'yewu', name: '涉外业务'}]}
    },
    {
      path: '/yewu/zhaobiao(.*)',
      name: 'zhaobiao',
      component: ZhaobiaoView,
      meta:{ parent: [ {path: 'yewu', name: '招投标业务'}]}
    },
    {
      path: '/yewu/shangshi(.*)',
      name: 'shangshi',
      component: ShangshiView,
      meta:{ parent: [ {path: 'yewu', name: '商事业务'}]}
    },
    {
      path: '/branch',
      name: 'branch',
      component: JigouView
    },
    {
      path: '/branch/beijing(.*)',
      name: 'beijing',
      component: BeijingView
    },
    {
      path: '/branch/shanghai(.*)',
      name: 'shanghai',
      component: ShanghaiView
    },
    {
      path: '/branch/shenzhen(.*)',
      name: 'shenzhen',
      component: ShenzhenView
    },
    {
      path: '/branch/xian(.*)',
      name: 'xian',
      component: XianView
    },
    {
      path: '/branch/kunming(.*)',
      name: 'kunming',
      component: KunmingView
    },
    {
      path: '/case',
      name: 'case',
      component: AnliView
    },
    {
      path: '/case/:id(.*)',
      name: 'casehtml',
      component: AnliarcView,
      meta:{ parent: [ {path: 'case', name: '胜诉案例'}]}
    },
    {
      path: '/notice',
      name: 'notice',
      component: GonggaoView
    },
    {
      path: '/notice/:id(.*)',
      name: 'noticehtml',
      component: GonggaoarcView,
      meta:{ parent: [ {path: 'notice', name: '冠领公告'}]}
    },
    {
      path: '/lawyer',
      name: 'lawyer',
      component: LawyerView
    },
    {
      path: '/lawyer/:id(.*)',
      name: 'lawyerhtml',
      component: LawyerarcView,
      meta:{ parent: [ {path: 'lawyer', name: '律师团队'}]}
    },
    {
      path: '/lawyer/lawinfo',
      name: 'lawinfo',
      component: LawyerinfoView
    },
    {
      path: '/newslist',
      name: 'newslist',
      component: NewsView
    },
    {
      path: '/newslist/:id(.*)',
      name: 'newslisthtml',
      component: NewsarcView,
      meta:{ parent: [ {path: 'newslist', name: '冠领新闻'}]}
    },
    {
      path: '/tv',
      name: 'tv',
      component: YangshiView
    },
    {
      path: '/tv/:id(.*)',
      name: 'tvhtml',
      component: VideoView,
      meta:{ parent: [ {path: 'tv', name: '冠领在央视'}]}
    },
    {
      path: '/honor',
      name: 'honor',
      component: HonorView
    },
    {
      path: '/honor/:id(.*)',
      name: 'honorhtml',
      component: HonorarcView,
      meta:{ parent: [ {path: 'honor', name: '冠领荣誉'}]}
    },
    {
      path: '/about/:id(.*)',
      name: 'abouthtml',
      component: ArticalView,
      meta:{ parent: [ {path: '/', name: '北京冠领律师事务所'}]}
    },
  ]
})
