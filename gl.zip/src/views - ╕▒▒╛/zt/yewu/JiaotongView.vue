<template>
  <div class="yewuinfo">
    <div class="linebanbox">
      <img src="../../../assets/yewuinfoline.jpg" class="autoc">
      <div class="linebanhead">
        <strong>交通事故诉讼</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="yewuwrap w1200">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
          <el-breadcrumb-item>{{nowname}}</el-breadcrumb-item>

        </el-breadcrumb>
      </div>
      <div class="yewuintro">
        <div class="yewuintrol">
          <h2>交通事故诉讼</h2>
          <div class="yewuintrowrap">
            <div class="yewuintrowraph">

            <p>发生交通事故后，常常会因为赔偿问题引发交通事故诉讼。那么，发生交通事故怎么起诉？交通事故诉讼程序有哪些？</p>
            <p>针对交通事故诉讼，北京冠领律师事务所，以专业知识、专业技能、实战经验形成了冠领专业化、独具特色的律师团队。成员多数毕业于国内外知名大学法学院，拥有丰富的执业经验，以及为国内外客户提供优质和高效的、法律服务为终止目标，向客户提供不同领域及多层次的法律服务保障。</p>
            <p>交通事故受害人如果与加害人无法达成和解、调解的，受害人可以向法院进行起诉，以达到解决纠纷和维护自己权益的目的。具体流程如下：</p>
            <p>第一步：起诉</p>
            <p>1、选择管辖法院</p>
            <p>道路交通事故赔偿纠纷属于侵权纠纷，由事故发生地或者被告的住所地人民法院管辖。</p>
            <p>虽然起诉法院既可以选择事故发生地又可以选择被告的住所地法院，但是受害人尽量选择交通事故发生地人民法院进行起诉。选择事故发生地法院起诉，更利于事故事实和证据的查明与收集，因此受害人维权成本相对较低。</p>
            <p>2、被告的确定</p>
            <p>在交通事故诉讼中，一般被告就是机动车驾驶人。同时，基于保险合同关系，根据《交强险条例》，车辆投保的保险公司同样是赔偿责任人，可以将保险公司与机动车驾驶人列为共同被告。所以，在交通事故诉讼中，通常情形下，被告至少有两名，即机动车驾驶人和车辆投保的交强险的保险公司。</p>
            <p>在特殊情况下，被告的范围不仅有机动车驾驶人和保险公司，还有其他的主体需要承担责任的。比如雇员在从事雇员活动中遭受交通事故的，应以雇主作为被告。②如果是第三人造成人身损害的，可以选择雇主或第三人作为诉讼的被告。</p>
            <p>3、起诉状</p>
            <p>交通事故诉讼起诉状书写内容</p>
            <p>①原被告的基本信息：姓名，住所，联系方式等。</p>
            <p>②原告的诉讼请求。在交通事故诉讼中，原告可要求被告赔偿在事故中的财产损失、赔偿相关的医疗费、误工费、护理费、营养费等，以及诉讼费的承担。</p>
            <p>③事实与理由。事实与理由这部分，需要写明事故发生的原因、经过和结果。分析事故当事人之间的责任的划分。</p>
            <p>第二步：法院立案</p>
            <p>交通事故诉讼在原告起诉后，法院会在7日内进行审查，符合起诉条件的，法院将予以立案，并会通知原告。不符合条件的，法院退回原告的起诉状和其他相关材料、证据，并告知理由。</p>
            <p>第三步：提交证据</p>
            <p>原告对自己主张的赔偿项目和费用，应提交下列证据：</p>
            <p>①交通事故造成伤残的，应提交《伤残鉴定报告》。在交通事故诉讼前未做伤残鉴定的，在向法院提起诉讼式，可以提交书面申请，要求法院做伤残鉴定。伤残鉴定的结果决定了受害人能获得多少的赔偿；</p>
            <p>②交通事故造成残疾的，需要配制补偿功能的器具的，需要提交医院的证明，法院会根据医院的相关证明来计算残疾器具费；</p>
            <p>③误工费、护理费和营养费的诉求的，需要提交相关的鉴定文件，起诉前未做鉴定的，在向人民法院提起民事诉讼时，提交书面申请，要求做相关的鉴定。鉴定报告决定了误工费、护理费和营养费的赔偿；</p>
            <p>④医疗费的诉求，需要提交相关的治疗凭证；</p>
            <p>第四步：法院调解</p>
            <p>法院在审理交通事故案件前，一般会先进行调解。在调解的过程中会先听取当事人各方的请求，根据道路交通事故认定书认定事实以及《中华人民共和国道路交通安全法》确定当事人承担的损害赔偿责任。</p>
            <p>第五步：法院审理</p>
            <p>开庭：法院会送达传票原被告，通知开庭的时间、地点；</p>
            <p>可委托律师或者其他专业人士代理诉讼；</p>
            <p>审理期限：交通事故民事诉讼的审理期限通常为6个月。有特殊情况需要延长的，可以延长6个月。如还需要延长的，还可以再延长3个月。</p>
            <p>第六步：法院判决</p>
            <p>法院将会根据原被告所提供的证据材料，确定原被告各自承担的责任比例，计算损害赔偿的数额，以及确定赔偿履行方式和期限。</p>
            <p>北京冠领律师事务所深知“法律乃知识与经验之结合”的深刻道理，律所成员既有来自北京大学、清华大学、中国人民大学、中国政法大学等顶尖高校的饱学之士，更有长期奋战在法律实务一线，功底深厚、身经百战的“ 律界老将”。北京冠领律师事务所坚持“以胜诉求共赢——法庭上争胜诉，法庭下谋共赢”的办案理念，以规模化、专业化、品牌化、国际化的优势，为当事人提供优质、高效的法律服务。</p>

            </div>
          </div>

          <router-link to="" class="morelink">查看更多></router-link>
        </div>
        <div class="yewuintror">
          <router-link to="/lawyer/">
            <img src="../../../assets/yewuxgtd.jpg" >
            <strong><router-link to="/lawyer/">相关团队</router-link></strong>
          </router-link>
        </div>
      </div>

    </div>

    <div class="yewurun">
      <strong>交通事故诉讼</strong>
      <div class="yewurunbox w1200">
        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide swiperbtn" v-for="item,index in lmdata['child']" :key="index" >{{item.name}}</div>
          </div>
        </div>
        <div thumbsSlider="" class="swiper mySwiper2">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>人身损害赔偿</h3>
               <p>{{a['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>财产损害赔偿</h3>
                <p>{{b['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>保险索赔</h3>
               <p>{{c['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>事故调解</h3>
                  <p>
                  {{d['description']}}
                  </p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>伤残等级</h3>
                <p>{{e['description']}}</p>
              </div>
            </div>


          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
    <!-- 经典案例 -->
    <div class="jdal w1200">
      <strong>经典案例</strong>
      <div class="jdalwrap">
        <div class="jdalwrapbox">
          <ul>
          	<li v-for="item,index in anlidata" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
          </ul>
          <router-link to="/case/" class="morelink">查看更多></router-link>
        </div>
        <img src="../../../assets/anliimg.jpg" >
      </div>
    </div>

    <!-- 相关新闻 -->
    <div class="aboutnew">
      <div class="aboutnewwrap w1200">
        <strong>相关新闻</strong>
        <div class="aboutnewbox">
          <div class="aboutnewzw">
            <div class="aboutnewl"><img src="../../../assets/newleft.jpg" ></div>
            <ul>
            	<li v-for="item,index in newsdata" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">{{item.title}}</router-link><span>{{item.create_time}}</span></li>
            </ul>
          </div>
          <router-link to="/newslist/" class="morelink">查看更多></router-link>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../../../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  import {request} from '../../../network/request.js'
  import GLOBAL from '../../../global/global.js'
  export default{
    name: 'JiaotongView',
    data(){
      return{
        breadcrumbList:[],
        lmdata:[],
        lmname:'',
        nowname:'',
        lmid:0,
        isActive: false,
        anlidata:[],
        newsdata:[],
        a:[],
        b:[],
        c:[],
        d:[],
        e:[],
        isSelect:false,
        initnum:0

      }
    },
    methods:{
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
              // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lmdata = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                 that.lmdata = newData[5]
                 that.lmname = newData[5]['name']
                 newData[5]['child'].forEach(function(val){

                    if(val['id'] == that.lmid){
                        that.nowname = val['name']
                    }
                 })
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getanliData(){
        let that = this
        request({
          url: '/lingyu/lyanli?id=10',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.anlidata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.anlidata = jsondata['data'];
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getnewsData(){
        let that = this
        request({
          url: '/lingyu/lynews?id=60',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.newsdata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data']
                newData.forEach(function(val){
                  val['create_time'] = val['create_time'].split(' ')[0]
                  that.newsdata.push(val)
                });
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getlitinfo(id){
        let that = this
        request({
          url: '/lingyu/read?id='+id,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lanmuname = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                switch(id){
                  case 177:
                  that.a = jsondata['data']
                  break;
                  case 178:
                  that.b = jsondata['data']
                  break;
                  case 179:
                  that.c = jsondata['data']
                  break;
                  case 180:
                  that.d = jsondata['data']
                  break;
                  case 181:
                  that.e = jsondata['data']
                  break;
                }
              }
            }
          }]
        })
      }
    },
    watch:{
      newsdata(){

      }
    },
    created() {

    },
    mounted(){
      let that = this
      this.getlmData()
      this.getanliData()
      this.getnewsData()
      this.getlitinfo(177)
      this.getlitinfo(178)
      this.getlitinfo(179)
      this.getlitinfo(180)
      this.getlitinfo(181)
      //获取id
      let lanmuid = this.$route.query['id']
      if(lanmuid != undefined){
          that.lmid = lanmuid
          switch(lanmuid){
            case '177':
            that.initnum = 0
            break;
            case '178':
            that.initnum = 1
            break;
            case '179':
            that.initnum = 2
            break;
            case '180':
            that.initnum = 3
            break;
            case '181':
            that.initnum = 4
            break;
          }
          // alert($('.yewuwrap').offset().top)
          $('body,html').animate({
                  scrollTop: $('.yewurun').offset().top
          },500);
      }else{
        that.initnum = 0
      }
      // console.log(this.$route.name);
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'jiaotong'){
          $(".chonggou a[href$='yewu']").attr('class','router-link-active')
        }
      })


      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      let islock = false;
      let yewuintrowraph = $('.yewuintrowraph')
      let morelink = $('.yewuintrol .morelink')
      morelink.click(function(){
        if(islock == false){
          islock = true
          $('.yewuintrowrap').animate({
            height: yewuintrowraph.height()
          },500,function(){
            morelink.html('收起更多>')
          })

        }else{
          islock = false
          $('.yewuintrowrap').animate({
            height: '268px'
          },500,function(){
            morelink.html('查看更多>')
          })

        }
      })



      setTimeout(function(){
        // alert(that.initialSlide)
        var swiper = new Swiper(".mySwiper", {
          spaceBetween: 10,
          slidesPerView: 9,
          // slidesPerView: "auto",
          freeMode: true,
          watchSlidesProgress: false,
        });
        var swiper2 = new Swiper(".mySwiper2", {
          spaceBetween: 0,
          slidesPerView: 1,
          initialSlide : that.initnum,//默认第三页
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          thumbs: {
            swiper: swiper,
          },
        });
      },800)


    }
  }
</script>

<style scoped="scoped" lang="scss">
  .yewuinfo{

    .yewuwrap{

      .yewuintro{
        display: flex;
        justify-content: space-between;
        .yewuintrol{
          width: 810px;
          h2{
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            position: relative;
            padding-left: 18px;
            line-height: 100%;
            margin-top: 40px;
            margin-bottom: 10px;
          }
          h2::before{
            content: "";
            width: 8px;
            height: 20px;
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: -9px;
            background-color: #b80816;

          }
          .yewuintrowrap{
            height: 268px;
            overflow: hidden;
          }
          p{
            font-size: 18px;
            color: #666666;
            text-indent: 2em;
            line-height: 28px;
            strong{
              font-weight: bold;
              color: #333;
            }
          }
          p:nth-of-type(3){
            margin-top: 12px;
          }
          a{
            margin-right: 0;
          }
        }
        .yewuintror{
          margin-top: 40px;
          position: relative;
          cursor: pointer;
          strong{
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 58px;
            color: #fff;
            width: 114px;
            border-bottom: 3px solid #fff;
            text-align: center;
            left: 50%;
            margin-left: -57px;
            padding-bottom: 5px;
            transition: all .3s linear 0s;
            a,a:hover{
              color: #fff!important;
            }
          }
        }
        .yewuintror:Hover strong{
          transform: scale(1.1);
          top: 55px;
        }
      }
    }
    .yewurun{
      height: 492px;
      margin-top: 60px;
      min-width: 1200px;
      background: url(../../../assets/yewurunbg.jpg) no-repeat center;
      overflow: hidden;
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        color: #fff;
        margin-top: 60px;
        line-height: 100%;
        margin-bottom: 40px;
      }
      .yewurunbox{
        position: relative;
        .swiper{
          width: 1100px;
          margin: 0 auto;
        }
        .mySwiper{
          // overflow: hidden;
          .swiper-wrapper{
            display: flex;
            flex-wrap: wrap;
          }
          .swiper-slide:nth-child(9){
            margin-right: 0 !important;
          }
          .swiper-slide::after{
            content: "";
            width: 20px;
            height: 20px;
            background-color: #fff;
            position: absolute;
            bottom: -35px;
            left: 50%;
            margin-left: -10px;
            transform: rotate(45deg);
            opacity: 0;
            transition: all .2s linear 0s;
          }
          .swiper-slide{
            position: relative;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            padding: 0 15px;
            white-space: nowrap;
            width: auto !important;
            height: 40px;
            background: rgba(255,255,255,.2);
            text-align: center;
            line-height: 40px;
            transition: all .3s linear 0s;
            margin-top: 10px;
          }
          .swiper-slide-thumb-active{
            background: #b80816;
          }
          .swiper-slide-thumb-active::after{
            opacity: 1;
          }
        }
        .mySwiper2{
          margin-top: 25px;
          overflow: hidden;
          .swiper-button-next, .swiper-button-prev{
            top: 62%;
            background-repeat: no-repeat;
            background-position: center;
          }
          .swiper-button-next{
            background-image: url(../../../assets/right.png);
          }
          .swiper-button-prev{
            background-image: url(../../../assets/left.png);
          }
          .swiper-button-next:Hover{
            background-image: url(../../../assets/right-s.png);
          }
          .swiper-button-prev:hover{
            background-image: url(../../../assets/left-s.png);
          }
          .swiper-button-next:after, .swiper-button-prev:after{
           content: "";
          }

          .swiper-slide{
            background: #fff;
            padding-bottom: 30px;
            .swiperbox{
              padding: 0 54px;
              h3{
                font-size: 20px;
                color: #414141;
                line-height: 100%;
                padding: 30px 0 22px 0;
                border-bottom: 1px solid #dfdfdf;
                margin-bottom: 18px;
              }
              p{
                line-height: 28px;
                font-size: 18px;
              }
            }
          }
        }
      }
    }
    .jdal{
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      .jdalwrap{
        position: relative;
        img{
          position: absolute;
          top: 51px;
          left: 615px;
          z-index: -1;
        }
        .jdalwrapbox::before{
          content: "";
          height: 35px;
          width: 16px;
          background-color: #b80816;
          position: absolute;
          top: 0;
          left: 28px;
        }
        .jdalwrapbox{
          padding-bottom: 42px;
          position: relative;
          width: 762px;
          box-shadow: 0 0 8px #d9d9d9;
          overflow: hidden;
          background: #fff;
          height: 470px;
          ul{
            margin-top: 28px;
            margin-left: 72px;
            width: 618px;

            li:before{
              content: "";
              width: 5px;
              height: 5px;
              background: #666666;
              position: absolute;
              left: 0;
              top: 50%;
              margin-top: -2.5px;

            }
            li:hover::before{
              background-color: #b80816;
            }
            li:hover{
              background-image: url(../../../assets/linebg-s.png);
            }
            li{
              position: relative;
              padding-bottom: 17px;
              padding-top: 17px;
              border-bottom: 1px solid #eaeaea;
              padding-left: 15px;
              line-height: 20px;
              background: url(../../../assets/linebg.png) no-repeat 594px center;
              a{
                font-size: 18px;
                color: #666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                padding-right: 50px;
              }
            }
          }
        }
        .morelink{
          margin-right: 70px;
        }

      }

    }
    .aboutnew{

      margin-top: 89px;
      background: url(../../../assets/yewunewbg.jpg) no-repeat top center;
      .aboutnewwrap{
        position: relative;
        overflow: hidden;
        height: 533px;
        strong{
          font-size: 30px;
          color: #fff;
          display: block;
          line-height: 100%;
          text-align: center;
          margin-top: 45px;
          margin-bottom: 36px;
        }
        .aboutnewbox{
          background: #fff;
          height: 420px;
          width: 100%;
          position: absolute;
          top: 110px;

          .aboutnewzw{
            display: flex;
          }
          ul{
            width: 618px;
            box-shadow: 0 0 8px #b5b5b5;
            padding: 30px 45px;
            li:hover{
              background-image: url(../../../assets/newicon-s.jpg);
            }
            li{
              height: 56px;
              border-bottom: 1px solid #eaeaea;
              line-height: 56px;
              display: flex;
              justify-content: space-between;
              background: url(../../../assets/newicon.jpg) no-repeat 3px center;
              padding-left: 31px;
              a{
                font-size: 18px;
                color: #666666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 75%;
              }
              span{
                font-size: 16px;
                color: #666666;
              }
            }
          }
        }
        .morelink{
          position: absolute;
          bottom: 35px;
          right: 0;
          margin-right: 45px;
        }
      }
    }
    .yewuline{
      margin-top: 50px;
    }
  }
</style>
