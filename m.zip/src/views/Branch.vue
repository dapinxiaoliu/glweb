<template>
  <div class="branch">
    <div class="comban">
      <img src="../assets/branch.jpg" >
      <div>
        <strong>冠领机构</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="branchwrap">
      <div class="map"><img src="../assets/map.jpg" ></div>
      <div class="branchlist">
        <ul class="m20">
        	<li><router-link to="/branch/beijing.html">
            <img src="../assets/branch-img.jpg" >
            <div class="branchinfo">
              <strong>北京冠领</strong>
              <p>北京市西城区宣武门外大街庄胜广场中央办公楼5层、6层、15层、13层1309-1312</p>
              <p>400-8789-888(24小时)</p>
            </div>
          </router-link></li>
          <li><router-link to="/branch/shanghai.html">
            <img src="../assets/shanghai.jpg" >
            <div class="branchinfo">
              <strong>上海冠领</strong>
              <p>上海市黄浦区人民路300号外滩SOHO广场D幢</p>
              <p>400-8789-888(24小时)</p>
            </div>
          </router-link></li>
          <li><router-link to="/branch/shenzhen.html">
            <img src="../assets/shenzhen.jpg" >
            <div class="branchinfo">
              <strong>深圳冠领</strong>
              <p>广东省深圳市福田区益田路5033号平安金融中心104层10401单元</p>
              <p>400-8789-888(24小时)</p>
            </div>
          </router-link></li>
          <li><router-link to="/branch/xian.html">
            <img src="../assets/xian.jpg" >
            <div class="branchinfo">
              <strong>西安冠领</strong>
              <p>陕西省西安市雁塔区雁翔路旺座曲江K座1804室</p>
              <p>400-8789-888(24小时)</p>
            </div>
          </router-link></li>
          <li><router-link to="/branch/kunming.html">
            <img src="../assets/kunming.jpg" >
            <div class="branchinfo">
              <strong>昆明冠领</strong>
              <p>云南省昆明市西山区广福路与前卫西路十一家具大厦八楼D座1-7号办公室</p>
              <p>400-8789-888(24小时)</p>
            </div>
          </router-link></li>

        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import $ from 'jquery'
  export default {
    name: 'Branch',
    mounted() {
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'branch'){
          $(".chonggou a[href$='/branch']").attr('class','router-link-active')
        }
      })
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .branch{
    .branchwrap{
      .branchlist{
        margin-bottom: .2rem;
        ul{
          display: flex;
          flex-wrap: wrap;
          justify-content: space-between;
          li{
            width: 3.45rem;
            box-sizing: border-box;
            border: 1px solid #dcdcdc;
            padding-bottom: .15rem;
            margin-bottom: .2rem;
            .branchinfo{
              margin: 0 .15rem;
            }
            strong{
              display: block;
              text-align: center;
              font-size: .3rem;
              font-weight: bold;
              color: #333;
              line-height: 100%;
              margin-top: .25rem;
              margin-bottom: .1rem;
            }
            p{
              font-size: .25rem;
              line-height: .36rem;
              background-repeat: no-repeat;
              background-position: left .06rem;
              background-size: .22rem;
              text-indent: .3rem;
              color: #666666;
              margin-bottom: .02rem;

            }
            p:nth-of-type(1){
              background-image: url(../assets/mapicon.png);
            }
            p:nth-of-type(2){
              white-space: nowrap;
              background-image: url(../assets/telicon.png);
            }
          }
        }
      }
    }
  }
</style>
