<template>
  <div class="news">
    <div class="linebanbox">
      <img src="../assets/newslineimg.jpg" class="autoc" >
      <div class="linebanhead">
        <strong>冠领新闻</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>

    <div class="newsinner w1200">
      <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;冠领新闻</div>
      <div class="anlinav">
        <button class="curr" @click="getdatamsg(29,'zb')">冠领总部新闻</button>
        <button @click="getdatamsg(50,'jigou')">冠领机构新闻</button>
        <button @click="getdatamsg(55,'yewu')">业务相关新闻</button>
        <button  @click="getdatamsg(64,'pufa')">普法资讯</button>
      </div>
      <div class="newswrap">
        <!-- 总部开始-->
        <div class="zongbunews newsitemlist">
          <div class="newsitembox">
            <ul
              v-loading="loading"
            >

            	<li v-for="item in zongbuData" :key="item.id" class="zongbuli">
                <router-link :to="{path: '/newslist/'+item.id+'.html'}">
                  <div class="itemboxl"><img :src="item.thumb" ></div>
                  <div class="itemboxr">
                    <strong>{{item.title}}{{pageCount}}</strong>
                    <p>{{item.miaoshu}}</p>
                    <div class="newsnum">
                      <!-- <span>{{item.count}}</span> -->
                      <span>{{item.create_time}}</span></div>
                  </div>
                </router-link>
              </li>
            </ul>
          </div>

          <div class="page">
             <el-pagination
               background
               hide-on-single-page
               :current-page.sync=otherpage
               @current-change="zongbu"
               layout="prev, pager, next"
               prev-text="上一页"
               next-text="下一页"
               :page-count=othertotal>
             </el-pagination>
          </div>
        </div>
        <!-- 总部结束 -->
        <div class="newsjigou newsitemlist">
          <div class="newsitembox">
              <div class="newsjigoul">
                <div class="yangshiwrapl">
                  <h2>- 全  部 -</h2>
                  <div class="yangshibox">

                    <div class="yangshiitem" v-for="item,index in jigoulanmu" :key="item.id" @click="getJigou(50,'jigou',item.id,index)" :class="{ysactive:index==jgindexid}">
                      <strong>{{item.name}}</strong>
                    </div>

                  </div>
                </div>
              </div>
              <div class="newsjigour"  v-loading="loading" :element-loading-text="loadtext">
                <ul>

                  <li v-for="item in otherData"><router-link :to="{path: '/newslist/'+item.id+'.html'}">{{item.title}}</router-link>
                  <!-- <em>{{item.count}}</em> -->
                  <span>{{item.create_time}}</span></li>

                </ul>
              </div>
          </div>
          <div class="page">
             <el-pagination
               background
               hide-on-single-page
               :current-page.sync=otherpage
               @current-change="jigou"
               layout="prev, pager, next"
               prev-text="上一页"
               next-text="下一页"
               :page-count= othertotal>
             </el-pagination>
          </div>
        </div>
        <!-- 业务相关 -->
        <div class="newsyewu newsjigou newsitemlist">
          <div class="newsitembox">
              <div class="newsjigoul">
                <div class="yangshiwrapl">
                  <h2>- 全  部 -</h2>
                  <div class="yangshibox">

                    <div class="yangshiitem" v-for="item,index in yewulanmu" :key="item.id" @click="getYewu(50,'yewu',item.id,index)" :class="{ysactive:index==ywindexid}">
                      <strong>{{item.name}}</strong>
                    </div>

                  </div>
                </div>
              </div>
              <div class="newsjigour" v-loading="loading" :element-loading-text="loadtext">
                <ul>
                  <li v-for="item in otherData"><router-link :to="{path: '/newslist/'+item.id+'.html'}">{{item.title}}</router-link>
                  <!-- <em>{{item.count}}</em> -->
                  <span>{{item.create_time}}</span></li>
                </ul>
              </div>
          </div>

          <div class="page">
              <el-pagination
                background
                hide-on-single-page
                :current-page.sync=otherpage
                @current-change="yewu"
                layout="prev, pager, next"
                prev-text="上一页"
                next-text="下一页"
                :page-count=othertotal>
              </el-pagination>
          </div>
        </div>
        <!-- 业务相关 -->
        <!-- 普法资讯 -->
        <div class="newspufa newsitemlist">
          <div class="yangshiboxwrap">
            <ul>
              <li v-for="item in otherData"><router-link :to="{path: '/newslist/'+item.id+'.html'}">{{item.title}}</router-link>
              <!-- <em>{{item.count}}</em> -->
              <span>{{item.create_time}}</span></li>
            </ul>
          </div>
          <div class="page">
             <el-pagination
               background
               hide-on-single-page
               :current-page.sync=otherpage
               @current-change="pufa"
               layout="prev, pager, next"
               prev-text="上一页"
               next-text="下一页"
               :page-count=othertotal>
             </el-pagination>
          </div>
        </div>
        <!-- 普法资讯 -->
      </div>

    </div>
  <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'NewsView',
    data(){
      return {
        zongbuData:[],
        zongbuPage:[
          {pageCount:1,pageSize:10}
        ],
        jigouData:[],
        jigouPage:[
           {pageCount:1,pageSize:20}
        ],
        yewuData:[],
        yewuPage:[
           {pageCount:1,pageSize:20}
        ],
        pufaData:[],
        pufaPage:[
           {pageCount:1,pageSize:20}
        ],
        otherData:[],
        pageSize:15,
        loading: true,
        jigoulanmu:[],
        yewulanmu:[],
        lanmuclick:[{jigouclick: 0, yewuclick:0}],
        loadtext:'拼命加载中...',
        pagerCount:5,
        zbpage:1,
        otherpage:0,
        othertotal:0,
        jgitemid:50,
        jgindexid:0,
        ywitemid:55,
        ywindexid:0,
        pagec:1
      }
    },
    methods:{
      getdatamsg(id,name){
         this.pagec = 1
        if(name == 'zb'){
          this.othertotal = 1
          this.zongbuGetData()
        }else{
           this.ysactive(id,name)
        }
      },
      //总部数据
      getJigou(id,name,itemid,indexid){
        this.pagec = 1
        this.jgitemid = itemid
        this.jgindexid = indexid
        this.ysactive(itemid,name)
        localStorage.setItem('jgindexid',indexid)
        localStorage.setItem('jgitemid',itemid)
      },
      //总部数据
      getYewu(id,name,itemid,indexid){
        this.pagec = 1
        this.ywitemid = itemid
        this.ywindexid = indexid
        this.ysactive(itemid,name)
        localStorage.setItem('ywindexid',indexid)
        localStorage.setItem('ywitemid',itemid)
      },
      zongbuGetData(){
        let that = this
        that.othertotal = 0
        request({
          url: '/news/read?id=29&page='+that.pagec+'&page_size='+ that.zongbuPage[0]['pageSize'],
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata)
            if(jsondata['code'] == 200){
              // return jsondata;
               that.zongbuData = []
              let newdata = jsondata['data']['data']

              newdata.forEach(function(val){
                  // console.log(val['thumb']);
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[17].length
                  val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                  that.zongbuData.push(val);
              });
              // console.log(formateData)
              that.loading = false
              that.othertotal = jsondata['data']['last_page']
            }
          }]
        })
      },
      // 总部分页
       zongbu(val){
         let that = this
          that.loading = true
          that.jgval = val
          localStorage.setItem('jigoupage',val)
         request({
          url: '/news/read?id=29&page='+val+'&page_size='+ that.zongbuPage[0]['pageSize'],
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata)
            if(jsondata['code'] == 200){
              that.zongbuData = []
              let newdata = jsondata['data']['data']
              // let formateData = []
              newdata.forEach(function(val){
                  // console.log(val['thumb']);
                  if(val['thumb'].length > 50){
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[17].length
                    val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                  }
                  that.zongbuData.push(val);
              });
              that.loading = false
              that.zongbuPage[0]['pageCount'] = jsondata['data']['last_page']
            }
          }]
        })
       },
       //普法分页
       pufa(val){
        let that = this
        that.loading = true
        that.jgval = val
        localStorage.setItem('jigoupage',val)
         request({
          url: '/news/othercate?id=64&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.otherData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let riqi = val['create_time'].split(' ')
                  val['create_time'] = riqi[0]
                  that.otherData.push(val)
              });
              that.loading = false
            }
          }]
        })
       },
       //业务分页
       yewu(val){
        let that = this
        that.loading = true
        that.jgval = val
        localStorage.setItem('jigoupage',val)
         request({
          url: '/news/othercate?id='+that.ywitemid+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.otherData = []
              let newData = jsondata['data'];
              //格式化时间
              newData['data'].forEach(function(val){
                  that.loading = false
                  let riqi = val['create_time'].split(' ')
                  val['create_time'] = riqi[0]
                  that.otherData.push(val)
              });
              that.loading = false
            }
          }]
        })
       },
       //机构分页
       jigou(val){
         let that = this
        that.loading = true
        that.jgval = val
        localStorage.setItem('jigoupage',val)
         request({
          url: '/news/othercate?id='+that.jgitemid+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.otherData = []
              let newData = jsondata['data'];
              //格式化时间
              newData['data'].forEach(function(val){
                  that.loading = false
                  let riqi = val['create_time'].split(' ')
                  val['create_time'] = riqi[0]
                  that.otherData.push(val)
              });
              that.loading = false
            }
          }]
        })
       },

       //获取数据
       ysactive(temid,name){
         let that = this
         that.loading = true
         that.loadtext = '数据加载中...'
         that.otherData = []
         // that.othertotal = 0
         request({
           url: '/news/othercate?id='+temid+'&page='+that.pagec+'&page_size='+that.pageSize,
           responseType: 'json',
           transformResponse:[function(data){
             let jsondata = JSON.parse(data)
             if(jsondata['code'] == 200){
               // return jsondata;
                  let newData = jsondata['data'];
                  if(newData['total'] == 0){
                    that.loadtext = '没有数据'
                  }else{
                    newData['data'].forEach(function(val){
                        that.loading = false
                        let riqi = val['create_time'].split(' ')
                        val['create_time'] = riqi[0]
                        that.otherData.push(val)
                    });
                    that.othertotal = newData['last_page']
                    that.otherpage = parseInt(newData['current_page'])
                    // that.otherpage = newData['last_page']
                    // console.log(jsondata);
                  }
             }
           }]
         })
       }
    },
    mounted(){
      //初始化
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'newslist'){
          $(".chonggou a[href$='/newslist']").attr('class','router-link-active')
        }
      })
      let anbtn = $('.anlinav button')
      let newsitemlist  = $('.newsitemlist')
      let homeid = this.$route['query']['id'];
      if(homeid != undefined){
        this.lmid = homeid
        this.ysactive('jigou',0,homeid,6)
        anbtn.removeClass('curr')
        newsitemlist.hide()
        switch(homeid){
          case '50':
          anbtn.eq(1).addClass('curr')
          newsitemlist.eq(1).show()
          break;

        }
      }else{
        this.zongbuGetData()
      }

      let that = this


      let anid = null

      anbtn.click(function(){
        // alert('aaa')
         that.jgindexid = 0
         that.ywindexid = 0
        let idx = $(this).index()
        localStorage.setItem("otherpage",1)
        localStorage.setItem('jigoupage',1)


        if(idx == 0){
          localStorage.setItem("tabname", "冠领总部新闻")
        }else if(idx == 1){
          localStorage.setItem("tabname", "冠领机构新闻")
        }else if(idx == 2){
          localStorage.setItem("tabname", "业务相关新闻")
        }else{
          localStorage.setItem("tabname", "普法资讯")
        }
          anbtn.css({
            'background': '#f3f3f3',
            'color': '#333'
          })
          anbtn.eq(idx).addClass('curr').siblings().removeClass('curr')
          anbtn.eq(idx).css({
            'background': '#b80816',
            'color': '#fff'
          })
           newsitemlist.eq(idx).stop().fadeIn().siblings().hide()

      })

      //初始化页面对数据进行验证
      let jigouk = localStorage.getItem("jigouk")
      let yewuk = localStorage.getItem("yewuk")

      if(jigouk == 'null'){
        localStorage.setItem("jigouk",0)
      }else{
        that.lanmuclick[0]['jigouclick'] = jigouk
      }
      if(yewuk == 'null'){
        localStorage.setItem("yewuk",0)
      }
    },
    watch:{
      jigoulanmu(){
        let anbtn = $('.anlinav button')
        let newsitemlist  = $('.newsitemlist')
        let tsname = localStorage.getItem("tabname")
        
        if(tsname == 'null' || tsname == undefined){
          console.log('null')
        }else{
          if(tsname == '冠领总部新闻'){
            let jigoupage = localStorage.getItem('jigoupage')
            this.pagec = otherpage
            this.otherpage = jigoupage
            this.othertotal = jigoupage
            this.zongbuGetData()
            newsitemlist.eq(0).stop().fadeIn().siblings().hide()
            anbtn.eq(0).addClass('curr').siblings().removeClass('curr')
          }else if(tsname == '冠领机构新闻'){
            let jigoupage = localStorage.getItem('jigoupage')
            let jgid = localStorage.getItem('jgitemid')
            let indexid = localStorage.getItem('jgindexid') ==  null ? 0 : localStorage.getItem('jgindexid')
            this.pagec = jigoupage
            this.otherpage = jigoupage
            this.othertotal = jigoupage

            if(jgid == null){
              this.ysactive(50,'jigou')
            }else{
              this.ysactive(jgid,'jigou')
            }
            // alert(this.jgindexid)
            this.jgindexid = indexid
            newsitemlist.eq(1).stop().fadeIn().siblings().hide()
            anbtn.eq(1).addClass('curr').siblings().removeClass('curr')
          }else if(tsname == '业务相关新闻'){
            let jigoupage = localStorage.getItem('jigoupage')
            let ywid = localStorage.getItem('ywitemid')
            let ywind = localStorage.getItem('ywindexid') == null ? 0 : localStorage.getItem('ywindexid')
            this.pagec = jigoupage
            this.otherpage = jigoupage
            this.othertotal = jigoupage
            if(ywid == null){
              this.ysactive(55,'yewu')
            }else{
              this.ysactive(ywid,'yewu')
            }
            this.ywindexid = ywind
            newsitemlist.eq(2).stop().fadeIn().siblings().hide()
            anbtn.eq(2).addClass('curr').siblings().removeClass('curr')
          }else if(tsname == '普法资讯'){
            let jigoupage = localStorage.getItem('jigoupage')
            this.pagec = jigoupage
            this.otherpage = jigoupage
            this.othertotal = jigoupage
            this.ysactive(64,'pufa')
            newsitemlist.eq(3).stop().fadeIn().siblings().hide()
            anbtn.eq(3).addClass('curr').siblings().removeClass('curr')
          }
        }
      }
    },
      created(){
        //总部新闻数据
        let that = this
        //机构新闻栏目以及业务相关栏目
        request({
          url: '/Category/getcatelist?id=8',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              // console.log(jsondata)
              that.jigoulanmu = jsondata['data'][3]['child']
              that.yewulanmu = jsondata['data'][4]['child']
            }
          }]
        })
        //机构栏目默认请求第一个数据
    }
  }
</script>

<style lang="scss" scoped="scoped">
.news{
  .linebanbox{
    strong,small{
      color: #333;
    }
  }
  .newsinner{
    .anlinav{
      margin-top: 30px;
      padding-bottom: 30px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #f5f5f5;
      button{
        height: 70px;
        width: 285px;
        font-size: 22px;
        color: #333;
        background: #f3f3f3;
        border: none;
        cursor: pointer;
        border-radius: 4px;
        transition: all .2s linear 0s;
        position: relative;
      }
      button.curr{
        background: #b80816;
        color: #fff;
      }
      button.curr::after{
        content: "";
        width: 0;
        height: 0;
        border: 12px solid #b80816;
        border-bottom:12px solid transparent;
        border-right:12px solid transparent;
        border-left: 12px solid transparent;
        position: absolute;
        bottom: -23px;
        left: 50%;
        margin-left: -6px;
        transition: all .3s linear .5s;

      }

    }
    .newswrap{
      .zongbunews{
        .page{
          justify-content: center !important;
        }
      }
      margin-top: 20px;
      .newsitemlist:first-child{
        display: block;
      }
      .newsitemlist{

        display: none;
        .newsitembox{
          ul{
            li:Hover{
              strong{
                color: #b80816 !important;
              }
              img{
                transform: scale(1.1);
              }
            }
            li{
              height: 150px;
              padding-bottom: 20px;
              padding-top: 20px;
              border-bottom: 1px solid #eeeeee;
              a{
                display: flex;
                .itemboxl{
                  width: 180px;
                  margin-right: 20px;
                  overflow: hidden;
                  margin-left: 20px;
                  img{
                    transition: all .2s linear 0s;
                  }
                }
                .itemboxr{
                  width: 915px;
                  font-size: 18px;
                  color: #999999;
                  position: relative;
                  height: 150px;
                  strong{
                    font-size: 20px;
                    color: #333;
                    line-height: 100%;
                    margin-bottom: 14px;
                    display: block;
                    transition: all .2s linear 0s;
                  }
                  p{
                    line-height: 22px;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                    -webkit-line-clamp: 2;
                    overflow: hidden;
                  }
                  .newsnum{
                    position: absolute;
                    bottom: 0;
                    span{
                      display: inline-block;
                      background-repeat: no-repeat;
                      background-position: left center;
                      padding-left: 28px;
                      margin-right: 32px;
                    }
                    span:first-child{
                      background-image: url(../assets/yan.png);
                    }
                    span:last-child{
                      background-image: url(../assets/riqi.png);
                    }
                  }

                }
              }
            }
          }
        }
      }
      .newsjigou{
        .page{
          justify-content: flex-end;
          margin-right: 80px;
        }
        .newsitembox{
          display: flex;
          .newsjigoul{
            .yangshiwrapl{
              margin-right: 25px;
              width: 270px;
              box-sizing: border-box;

              h2{
                font-size: 22px;
                font-weight: bold;
                height: 68px;
                line-height: 68px;
                border: 1px solid #e5e5e5;
                text-align: center;
                border-radius: 8px 8px 0 0;
                border-bottom: none;
              }
              .yangshibox{
                border: 1px solid #e5e5e5;
                border-radius: 0 0 8px 8px;
                .yangshiitem:last-child{
                  strong,ul{
                    border-bottom: none;
                  }

                }
                .yangshiitem:first-child ul{
                  height: auto;
                }
                .yangshiitem:first-child ul li:first-child{
                  color: #b80816;
                }
                .yangshiitem{
                  strong{
                    font-weight: bold;
                    font-size: 20px;
                    color: #666666;
                    line-height: 70px;
                    height: 70px;
                    display: block;
                    padding-left: 85px;
                    border-bottom: 1px solid #e5e5e5;
                    cursor: pointer;
                    background: url(../assets/yangshiicon.jpg) no-repeat 188px center;
                    position: relative;
                  }

                }
                .ysactive{
                  strong{
                    color: #b80816;
                    background-image: url(../assets/yangshiicon-c.jpg);
                  }
                }
              }
            }
          }
          .newsjigour{
            width: 905px;
            ul{
              overflow: hidden;
              li{
                width: 100%;
                height: 60px;
                line-height: 60px;
                border: 1px solid #eeeeee;
                box-sizing: border-box;
                border-radius: 4px;
                margin-bottom: 15px;
                padding-left: 54px;
                background: url(../assets/alitemicon.png) no-repeat 29px center;
                display: flex;
                align-items: center;
                cursor: pointer;
                transition: all .3s linear 0s;
                b{
                  color: #999797;
                }
                a{
                  font-size: 18px;
                  display: block;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                  width: 75%;
                }
                em,span{
                  font-size: 18px;
                  color: #999999;
                }
                em{
                    background: url(../assets/yan.png) no-repeat left center;
                    padding-left: 28px;
                    margin-right: 32px;
                    margin-left: 70px;
                }
                span{
                  background: url(../assets/riqi.png) no-repeat left center;
                  padding-left: 24px;
                }

              }
              li:hover{
                background-image: url(../assets/alitemicon-s.png);
                border: 1px solid #b80816;
                em,span,a,b{
                  color: #b80816;
                }
                em{
                  background-image: url(../assets/yan-s.png);
                }
                span{
                  background-image: url(../assets/riqi-s.png);
                }
              }
            }
          }
        }
      }
      .newsyewu{
        .yangshiwrapl{
          strong{
            padding-left: 52px !important;
            background-position: 210px center !important;
          }
        }
      }
      .newspufa{
        .page{
          justify-content: center !important;
        }
        .yangshiboxwrap{
          ul{
            overflow: hidden;
            li{
              width: 100%;
              height: 60px;
              line-height: 60px;
              border: 1px solid #eeeeee;
              box-sizing: border-box;
              border-radius: 4px;
              margin-bottom: 15px;
              padding-left: 54px;
              background: url(../assets/alitemicon.png) no-repeat 29px center;
              display: flex;
              align-items: center;
              cursor: pointer;
              transition: all .3s linear 0s;
              b{
                color: #999797;
              }
              a{
                font-size: 18px;
                display: block;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: 80%;
              }
              em,span{
                font-size: 18px;
                color: #999999;
              }
              em{
                  background: url(../assets/yan.png) no-repeat left center;
                  padding-left: 28px;
                  margin-right: 32px;
                  margin-left: 70px;
              }
              span{
                background: url(../assets/riqi.png) no-repeat left center;
                padding-left: 24px;
              }

            }
            li:hover{
              background-image: url(../assets/alitemicon-s.png);
              border: 1px solid #b80816;
              em,span,a,b{
                color: #b80816;
              }
              em{
                background-image: url(../assets/yan-s.png);
              }
              span{
                background-image: url(../assets/riqi-s.png);
              }
            }
          }
        }
      }
    }
  }
}
</style>
