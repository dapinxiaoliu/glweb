<template>
    <div class="guwen">
      <div class="guwenban"><img src="@/assets/guwenban.jpg" alt=""></div>
      <div class="guwenintro">
        <div class="w1200">
          <h2><img src="@/assets/guwen01.jpg" alt=""></h2>
          <div class="guwenintrowrap">
            <div class="guwenintroitem guwenintroitemcom">
              <div class="guwenintroiteminner">
                <strong><img src="@/assets/guwenicon01.jpg" alt="">日常运营的法律风险防控</strong>
                <ul>
                  <li><a href="javascript:void(0)">1. 对企业日常运营提供法律咨询</a></li>
                  <li><a href="javascript:void(0)">2. 对企业突发性法律纠纷提供法律意见	</a></li>
                  <li><a href="javascript:void(0)">3. 对企业已有或可能发生的法律纠纷出具律师函	</a></li>
                  <li><a href="javascript:void(0)">4. 对企业法律状况进行调查并提供法律解决意见</a></li>
                  <li><a href="javascript:void(0)">5. 企业日常业务新出台的法律、法规和行政规章提供解释	</a></li>
                  <li><a href="javascript:void(0)">6. 对企业有关事项、重大商务活动等出具法律建议或意见书	</a></li>
                </ul>
              </div>
              <div class="guwenintroiteminner">
                <strong><img src="@/assets/guwenicon02.jpg" alt="">公司治理的法律风险防控</strong>
                <ul>
                  <li><a href="javascript:void(0)">1. 企业治理专项法律咨询；提供企业治理结构、董、监事会及管理层设置相关的法律咨询意见及方案设计</a></li>
                  <li><a href="javascript:void(0)">2. 对公司的设立、变更、注销提供专项法律咨询</a></li>
                  <li><a href="javascript:void(0)">3. 起草、审核公司章程	</a></li>
                  <li><a href="javascript:void(0)">4. 审核股东会决议、董事会决议</a></li>
                  <li><a href="javascript:void(0)">5. 对企业重大战略决策提供法律风险防控建议	</a></li>
                  <li><a href="javascript:void(0)">6. 对企业的分企业、子企业、分支机构设立、变更、注销提供专项法律咨询	</a></li>
                  <li><a href="javascript:void(0)">7. 对企业股权纠纷的处理提供专项法律咨询	</a></li>
                  <li><a href="javascript:void(0)">8. 起草、审核、修改出资协议、合作协议		</a></li>
                  <li><a href="javascript:void(0)">9. 起草、审核、修改股权转让协议	</a></li>
                  <li><a href="javascript:void(0)">10. 对股东股权转让提供专项法律咨询</a></li>
                  <li><a href="javascript:void(0)">11. 起草、审核、修改增资扩股协议</a></li>
                  <li><a href="javascript:void(0)">12. 对企业增资扩股提供专项法律咨询	</a></li>
                  <li><a href="javascript:void(0)">13. 股权、期权激励方案的设计	</a></li>
                  <li><a href="javascript:void(0)">14. 根据企业要求参加各类股改等谈判并提供法律意见	</a></li>
                </ul>
              </div>
            </div>
            <div class="guwenintroitem guwenintroitemcom">
              <div class="guwenintroiteminner">
                <strong><img src="@/assets/guwenicon03.jpg" alt="">业务合同的法律风险防控</strong>
                <ul>
                  <li><a href="javascript:void(0)">1. 为企业各类合同协议提供意见或建议	</a></li>
                  <li><a href="javascript:void(0)">2. 起草企业业务往来中的各类合同	</a></li>
                  <li><a href="javascript:void(0)">3. 审核、修改公司业务往来中的各类合同</a></li>
                  <li><a href="javascript:void(0)">4. 应企业要求参与企业与他方的商务谈判	</a></li>
                  <li><a href="javascript:void(0)">5. 为企业建立和完善长期使用的合同范本	</a></li>
                  <li><a href="javascript:void(0)">6. 对企业合同的流程、归档管理提供专项法律咨询	</a></li>
                  <li><a href="javascript:void(0)">7. 对企业业务合同纠纷案件处理提供专项法律咨询	</a></li>
                  <li><a href="javascript:void(0)">8. 以非诉讼形式协助企业对外交涉、谈判发生的合同纠纷	</a></li>
                  <li><a href="javascript:void(0)">9. 根据公司现有应收账款情况提供补救与预防的法律意见	</a></li>
                  <li><a href="javascript:void(0)">10. 对企业担保业务提供专项法律建议</a></li>
                </ul>
              </div>
              <div class="guwenintroiteminner">
                <strong><img src="@/assets/guwenicon04.jpg" alt="">投融资业务专项法律防控</strong>
                <ul>
                  <li><a href="javascript:void(0)">1. 对企业重大投资行为提供专项法律咨询	</a></li>
                  <li><a href="javascript:void(0)">2. 对企业兼并收购行为提供专项法律咨询	</a></li>
                  <li><a href="javascript:void(0)">3. 对企业重大融资提供专项法律咨询意见		</a></li>
                  <li><a href="javascript:void(0)">4. 为企业知识产权融资提供专项咨询建议	</a></li>
                  <li><a href="javascript:void(0)">5. 对企业改制行为提供专项法律咨询	</a></li>
                  <li><a href="javascript:void(0)">6. 为企业提供对商业伙伴或客户的审慎及资信调查服务</a></li>
                  <li><a href="javascript:void(0)">7. 私募基金、风险投资及首次公开募股		</a></li>
                  <li><a href="javascript:void(0)">8. 新三板挂牌（资料准备、企业改制、协议签署、资料初审、复核、挂牌）		</a></li>
                  <li><a href="javascript:void(0)">9. 上海、北京股权交易中心挂牌	</a></li>
                  <li><a href="javascript:void(0)">10. 为企业申请挂牌政府补贴提供专项法律咨询服务</a></li>
                </ul>
              </div>
            </div>
            <div class="guwenintroitem guwenintroitemcom">
                <div class="guwenintroiteminner">
                  <strong><img src="@/assets/guwenicon05.jpg" alt="">劳动人事的法律风险防控</strong>
                  <ul>
                    <li><a href="javascript:void(0)">1. 修改、完善企业劳动人事管理制度		</a></li>
                    <li><a href="javascript:void(0)">2. 起草、审核、修改员工劳动合同	</a></li>
                    <li><a href="javascript:void(0)">3. 起草、审核、修改高级管理人员聘用合同、竞业禁止合同		</a></li>
                    <li><a href="javascript:void(0)">4. 起草、审核、修改员工保密协议		</a></li>
                    <li><a href="javascript:void(0)">5. 对企业劳动纠纷的处理及法律风险防控提供专项法律咨询		</a></li>
                    <li><a href="javascript:void(0)">6. 代理劳动纠纷案件</a></li>
                  </ul>
                </div>
                <div class="guwenintroiteminner">
                  <strong><img src="@/assets/guwenicon06.jpg" alt="">知识产权的法律风险防控</strong>
                  <ul>
                    <li><a href="javascript:void(0)">1. 为企业知识产权权利申请或登记提供咨询建议</a></li>
                    <li><a href="javascript:void(0)">2. 为企业知识产权诉讼提供专项咨询建议	</a></li>
                    <li><a href="javascript:void(0)">3. 为企业知识产权治理提供专项咨询建议	</a></li>
                    <li><a href="javascript:void(0)">4. 为企业知识产权产业化运作提供咨询建议</a></li>
                    <li><a href="javascript:void(0)">5. 为企业知识产权转让、许可使用提供法律咨询</a></li>
                    <li><a href="javascript:void(0)">6. 为企业商业秘密保护提供专项法律建议		</a></li>
                  </ul>
                </div>
                <div class="guwenintroiteminner">
                  <strong><img src="@/assets/guwenicon07.jpg" alt="">其他专项法律服务</strong>
                  <ul>
                    <li><a href="javascript:void(0)">1. 为企业提供专项法律培训	</a></li>
                    <li><a href="javascript:void(0)">2. 为企业破产、清算提供专项法律咨询	</a></li>
                    <li><a href="javascript:void(0)">3. 为企业办理对外重大文件签署等事件的律师见证事项		</a></li>
                    <li><a href="javascript:void(0)">4. 经企业授权发表律师声明	</a></li>
                    <li><a href="javascript:void(0)">5. 代理企业进行各类诉讼、仲裁、行政复议案件</a></li>
                    <li><a href="javascript:void(0)">6. 代理企业进行破产、清算专项法律服务</a></li>
                  </ul>
                </div>
            </div>
          </div>
        </div>

      </div>

      <!-- 管家 -->
      <div class="guanjia">
        <div class="w1200">
          <h2><img src="@/assets/guwen02.jpg" alt=""></h2>
          <ul>
            <li>
              <h3><img src="@/assets/guanjia01.jpg" alt=""></h3>
              <div>
                <strong>主动式服务</strong>
                <p>区别于传统法律顾问被动等待式的咨询服务，将企业的运营管理与风险防控主动结合，提高企业决策的准确性和有效性。</p>
              </div>
            </li>
            <li>
              <h3><img src="@/assets/guanjia02.jpg" alt=""></h3>
              <div>
                <strong>系统式服务</strong>
                <p>完善服务体系，从整体着手提供法律服务。为企业提供“量身定做”式的服务内容，以“您身边的法律管家”为出发点，为企业做到事前防范、事中处理以及事后补救。</p>
              </div>
            </li>
            <li>
              <h3><img src="@/assets/guanjia03.jpg" alt=""></h3>
              <div>
                <strong>团队式服务</strong>
                <p>一切从客户的角度出发，确保服务领域全面化，迅速及时。</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <!-- 案例 -->
      <div class="anli">
        <div class="w1200">
          <h2><img src="@/assets/guwen03.png" alt=""></h2>
          <div class="anlibox">
            <div class="anlitop">
              <div class="anlitopleft"><img src="@/assets/gwanli.jpg" alt=""><p>北京冠领律师事务所无条件为奥运冠军孙一文维权！</p></div>
              <div class="anlitopright">
                <p>2021年东京奥运会前夕，北京冠领律师事务所周旭亮、任战敏两位主任代理孙一文肖像侵权案，无条件支持国家健将！</p>
                <p>2021年，奥运冠军孙一文在战奥运期间，通过微博粉丝知道了某企业擅自使用其肖像进行宣传，随后通过咨询，决定通过起诉维权。来到北京冠领律师事务所，两位主任立即决定亲自代理本案，并无条件支持国家健将。</p>
                <p>战出辉煌，战出荣光！剑影寒光里，御轻灵于质朴，化柔为刚，予坚韧于洒脱，飒沓如流星，在进退攻防间，是与自我的较量与博弈，剑光照空是铮铮傲骨亦有柔情绵绵。2021年7月24日，东京奥运会击剑项目女子个人重剑决赛中，孙一文仗剑封喉，取得中国女子重剑队奥运会历史上首枚个人金牌。</p>
                <p>奥运冠军孙一文，一剑寒光定九州，豪气背后温情更甚！碧海驰银练，战鹰凌云霄！冠领和冠军英雄相惜，孙一文用重剑为国争光，冠领用正义长剑为孙一文保驾护航！</p>
                <p>和奥运冠军相同的是，孙一文在为国发光的同时，冠领也在为维权的当事人点燃法治之光。孙一文一步步走来是汗水、使命和压力，冠领一步步走来也同样带着自己的使命。冠领律师用专业的法律知识去打赢每一场官司，用最诚挚的服务收获每一个客户的好评。冠领律师有着丰富的办案经验和过硬的专业水平，冠领律师事务所正在为建设法治社会添砖加瓦，孙一文可以一剑封喉，冠领律师同样可以仗法律之剑，暖弱者之心。战出辉煌，战出荣光！</p>
              </div>
            </div>
            <div class="anlibottom">
              <p>11月3日，北京冠领律师事务所收到奥运冠军孙一文礼赠刻有“孙一文”名字及击剑图像的苹果。苹果的寓意是“平平安安、硕果累累”，奥运冠军孙一文用真情实意祝福北京冠领律师事务所在全球化的征途上硕果累累，平稳向前发展。冠领也衷心感谢孙一文的礼赠，冠领带着这份来自奥运冠军的祝福将迈向更远的征程！</p>
            </div>
          </div>
          <router-link to="/case" class="seemore">查看更多</router-link>
        </div>
      </div>

    <!-- 合作伙伴 -->
    <div class="huoban">
      <div class="w1200">
        <h2><img src="@/assets/guwen04.jpg" alt=""></h2>
        <ul>
          <li><img src="@/assets/hbimg01.jpg" ></li>
          <li><img src="@/assets/hbimg02.jpg" ></li>
          <li><img src="@/assets/hbimg03.jpg" ></li>
          <li><img src="@/assets/hbimg04.jpg" ></li>
          <li><img src="@/assets/hbimg05.jpg" ></li>
          <li><img src="@/assets/hbimg06.jpg" ></li>
          <li><img src="@/assets/hbimg07.jpg" ></li>
          <li><img src="@/assets/hbimg08.jpg" ></li>
          <li><img src="@/assets/hbimg09.jpg" ></li>
          <li><img src="@/assets/hbimg10.jpg" ></li>
          <li><img src="@/assets/hbimg11.jpg" ></li>
          <li><img src="@/assets/hbimg12.jpg" ></li>
          <li><img src="@/assets/hbimg19.jpg" ></li>
          <li><img src="@/assets/hbimg20.jpg" ></li>
          <li><img src="@/assets/hbimg21.jpg" ></li>
          <li><img src="@/assets/hbimg22.jpg" ></li>
          <li><img src="@/assets/hbimg23.jpg" ></li>
          <li><img src="@/assets/hbimg24.jpg" ></li>
        </ul>
      </div>
    </div>
    <!-- 服务流程 -->
    <div class="fuwu">
      <div class="w1200">
        <h2><img src="@/assets/guwen05.png" alt=""></h2>
        <ul>
          <li>
            <div><img src="@/assets/liucheng01.png" alt=""></div>
            <strong>先期考察</strong>
          </li>
          <li>
            <div><img src="@/assets/liucheng02.png" alt=""></div>
            <strong>双向沟通</strong>
          </li>
          <li>
            <div><img src="@/assets/liucheng03.png" alt=""></div>
            <strong>缔约阶段</strong>
          </li>
          <li>
            <div><img src="@/assets/liucheng04.png" alt=""></div>
            <strong>履约阶段</strong>
          </li>
          <li>
            <div><img src="@/assets/liucheng05.png" alt=""></div>
            <strong>周期回顾</strong>
          </li>
        </ul>
      </div>
    </div>
    </div>
</template>
<script>

</script>
<style scoped lang="scss">
  img{
    width: 100%;
  }
  .seemore{
    width: 180px;
    height: 50px;
    color: #fff;
    text-align: center;
    line-height: 50px;
    background: #b80816;
    margin: 30px auto 0;
    display: block;
    font-size: 20px;
    transition: all .3s linear;
  }
  a.seemore:hover{
    color: #fff !important;
    font-size: 22px;
    border-radius: 6px;
  }

    .guwen{
        background: #f3f3f3;
        .guwenintro{
          background: url('../../../assets/neirongbg.jpg') no-repeat center bottom / 1920px 437px;
          h2{
            width: 393px;
            margin: 50px auto;
          }
          .guwenintrowrap{
            display: flex;
            justify-content: space-between;
            padding-bottom: 36px;
            .guwenintroitem{
              width: 390px;
              .guwenintroiteminner{
                padding-bottom: 12px;
                margin-bottom: 20px;
                background: #fff;
                border: 1px solid #dedede;
                box-sizing: border-box;
                strong{
                  display: flex;
                  align-items: center;
                  height: 54px;
                  background-color: #b80816;
                  line-height: 54px;
                  color: #fff;
                  font-weight: bold;
                  text-indent: 15px;
                  font-size: 20px;
                  img{
                    width: 50px;
                    margin-left: 50px;
                  }
                }
                ul{
                  padding: 10px 0;
                  li{
                    line-height: 100%;
                    padding: 0 10px;
                    white-space: nowrap;
                    text-overflow:ellipsis;
                    overflow: hidden;
                    font-size: 14px;
                    line-height: 32px;
                  }
                }
              }
            }
            .guwenintroitemcom:nth-child(1){
                .guwenintroiteminner:nth-child(2){
                  ul{
                    li{

                    }
                  }
                }
            }
            .guwenintroitemcom:nth-child(2){
                .guwenintroiteminner:nth-child(2){
                  padding-bottom: 43px;
                  ul{
                    li{

                    }
                  }
                }
            }
            .guwenintroitemcom:nth-child(3){
              .guwenintroiteminner:last-child{
                padding-bottom: 30px;
                ul{
                  li{

                  }
                }
                strong{
                    text-indent: 15px;
                    img{
                      margin-left: 90px;
                    }
                }
              }
            }
            .guwenintroitemcom{
              .guwenintroiteminner:last-child{
                ul{
                  li{
                      white-space: inherit;
                      text-overflow: ellipsis;
                      display: -webkit-box;
                      -webkit-box-orient: vertical;
                      -webkit-line-clamp: 2;
                      overflow: hidden;
                  }
                }
              }

            }
          }
        }
        .guanjia{
          padding-bottom: 50px;
            h2{
              width: 393px;
              margin: 50px auto;
            }
            ul{
              display: flex;
              justify-content: space-between;
              li:hover{
                box-shadow: 0px 5px 5px #e5e4e4;
                transform: translateY(-5px);
                img{
                  transform: scale(1.1);
                }
              }
              li{
                width: 386px;
                overflow: hidden;
                background-color: #fff;
                padding-bottom: 20px;
                border-radius: 10px;
                transition: all .3s linear;
                h3{
                  width: 386px;
                  height: 190px;
                  overflow: hidden;
                  img{
                    transition: all .3s linear;
                  }
                }
                div{
                  padding: 0 20px;
                  strong{
                    font-size: 24px;
                    color: #c62727;
                    line-height: 100%;
                    margin: 20px 0;
                    display: block;
                    font-weight: bold;
                  }
                  p{
                    font-size: 14px;
                    line-height: 22px;
                  }
                }
              }
            }
        }

        .anli{
          height: 818px;
          background: url('../../../assets/anlibg.jpg') no-repeat center top / 1920px 818px;
          h2{
            overflow: hidden;
            img{
              width: 153px;
              margin: 50px auto;
            }
          }
          .anlibox:hover{
            border-bottom: 4px solid #b80816;
          }
          .anlibox{
            height: 518px;
            width: 100%;
            background: rgba(255, 255, 255, .8);
            overflow: hidden;
            border-bottom: 8px solid #b80816;
            transition: all .3s linear;
            .anlitop{
              display: flex;
              justify-content: space-between;
              margin-top: 37px;
              .anlitopleft{
                width: 500px;
                position: relative;
                overflow: hidden;
                margin-left: 27px;
                img{
                  width: 500px;
                }
                p{
                  position: absolute;
                  bottom: 0;
                  left: 0;
                  right: 0;
                  width: 100%;
                  height: 50px;
                  line-height: 50px;
                  color: #fff;
                  background-color: rgba(184, 8, 22, .8);
                  font-weight: bold;
                  text-align: center;
                  font-size: 20px;
                }
              }
              .anlitopright{
                width: 616px;
                margin-right: 30px;
                p{
                  font-size: 14px;
                  line-height: 24px;
                  text-indent: 2em;
                }
              }
            }
            .anlibottom{
              margin: 15px 30px 0;
              p{
                font-size: 14px;
                line-height: 24px;
                text-indent: 2em;
              }
            }
          }
        }
        .huoban{
          padding-bottom: 34px;
          h2{
            img{
              width: 153px;
              margin: 50px auto;
            }
          }
          ul{
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            li{
              width: 186px;
              height: 57px;
              margin-bottom: 16px;
              overflow: hidden;
              cursor: pointer;
              img{
                transition: all .3s linear;
              }
            }
            li:hover{
              img{
                transform: scale(1.1);
              }
            }
          }
        }

        .fuwu{
          height: 468px;
          overflow: hidden;
          background: url('../../../assets/gwfuwubg.jpg') no-repeat center top / 1920px 468px;
          h2{
            img{
              width: 153px;
              margin: 50px auto;
            }
          }
          ul{
            width: 100%;
            height: 250px;
            background: rgba(255,255,255,.8);
            border-radius: 8px;
            box-shadow: 3px 3px 3px #ededed,-3px 0px 3px #ededed;
            display: flex;
            justify-content: space-around;
            align-items: center;
            li:hover{
              strong{
                margin-top: 10px;
              }
            }
            li{
              text-align: center;
              cursor: pointer;
              div{
                width: 120px;
                height: 120px;
                background: #b80816;
                border-radius: 50%;
                display: flex;
                align-items: center;
                border: 7px solid #edced2;
                img{
                  margin: 0 auto;
                }
              }
              strong{
                font-size: 24px;
                display: block;
                line-height: 100%;
                margin-top: 18px;
                transition: all .3s linear;
              }
            }
            li:nth-child(1){
              img{
                width: 76px;
              }
            }
            li:nth-child(2){
              img{
                width: 85px;
              }
            }
            li:nth-child(3){
              img{
                width: 53px;
              }
            }
            li:nth-child(4){
              img{
                width: 56px;
              }
            }
            li:nth-child(5){
              img{
                width: 79px;
              }
            }
          }
        }
    }
</style>
