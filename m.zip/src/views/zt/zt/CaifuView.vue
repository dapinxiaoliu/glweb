<template>
  <div class="caifu">
    <div class="ban"><img src="@/assets/caifuban.jpg" alt=""></div>
    <!-- 私人财富规划传承 -->
    <div class="guihua m20">
      <img src="@/assets/guihuaimg.jpg" alt="">
      <strong><em>私人财富规划传承</em></strong>
      <div class="intro">
        <p>冠领坚持为每一位客户提供优质的私人财富规划与传承服务，拥有该领域专业知识和丰富经验的高端人才。为客户的财产管理、继承纠纷、资产及投资等提供专业的法律服务。同时，专注于家族企业、高净值人士等私人财富法律风险管理诉讼及非诉服务，以实现家庭的和谐与传承。</p><p>强烈的市场需求催生了私人财富管理业务的飞速发展，也为私人财富管理专业人士提供了前所未有的机遇和挑战。冠领整合优化律师资源，建立私人财富管理专家库，可提供专业的私人财富管理服务和专家支持。</p>
      </div>
    </div>

    <div class="lingyu">
      <strong>业务领域</strong>
      <div class="lingyuwrap">
        
      </div>
    </div>
    <!-- end -->
  </div>
</template>

<script>
  import Swiper from 'swiper'
  import 'swiper/css/swiper.css'
  export default{
    name:'CaifuView',
    data(){
      return{
      }
    },
  }
</script>

<style lang="scss" scoped>
  .caifu{
    .guihua{
      margin-top: .63rem;
      overflow: hidden;
      img{
        width: 6.77rem;
        border: .06rem solid #fff;
        position: absolute;
        z-index: 66;
        left: 50%;
        margin-left: -3.45rem;
      }
      strong{
        display: block;
        height: 1.76rem;
        background: #b51829;
        margin-top: 1.29rem;
        overflow: hidden;
        em{
          color: #fff;
          display: block;
          text-align: center;
          line-height: 100%;
          margin-top: 1.1rem;
          font-size: .38rem;
          font-weight: bold;
        }
      }
      .intro{
        border: .1rem solid #b51829;
        background-color: #fff;
        p{
          font-size: .26rem;
          text-indent: 2em;
          line-height: .4rem;
          padding: .16rem .32rem;

        }
      }
    }
    .lingyu{
      margin-top: .6rem;
      width: 100%;
      height: 5.11rem;
      background: url('../../../assets/lingyubg.jpg') no-repeat center top / 100% 5.11rem;
      overflow: hidden;
      strong{
        display: block;
        text-align: center;
        font-size: .38rem;
        color: #fff;
        line-height: 100%;
        font-weight: bold;
        margin-top: .55rem;
      }
    }
  }
</style>
