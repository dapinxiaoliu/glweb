<template>

    <router-view></router-view>

</template>

<script>
  export default{
    name: 'YewuhomeView',
    components: {
    },
    data(){
      return{}
    }
  }
</script>

<style lang="scss" scoped="scoped">

</style>
