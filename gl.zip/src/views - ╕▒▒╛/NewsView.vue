<template>
  <div class="news">
    <div class="linebanbox">
      <img src="../assets/newslineimg.jpg" class="autoc" >
      <div class="linebanhead">
        <strong>冠领新闻</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>

    <div class="newsinner w1200">
      <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;冠领新闻</div>
      <div class="anlinav">
        <button class="curr" @click="zongbuGetData()">冠领总部新闻</button>
        <button @click="ysactive('jigou',0,50,20)">冠领机构新闻</button>
        <button @click="ysactive('yewu',0,55,20)">业务相关新闻</button>
        <button  @click="ysactive('pufa',0,64,20)">普法资讯</button>
      </div>
      <div class="newswrap">
        <!-- 总部开始-->
        <div class="zongbunews newsitemlist">
          <div class="newsitembox">
            <ul
              v-loading="loading"
            >

            	<li v-for="item in zongbuData" :key="item.id" class="zongbuli">
                <router-link :to="{path: '/newslist/'+item.id+'.html'}">
                  <div class="itemboxl"><img :src="item.thumb" ></div>
                  <div class="itemboxr">
                    <strong>{{item.title}}{{pageCount}}</strong>
                    <p>{{item.miaoshu}}</p>
                    <div class="newsnum"><span>{{item.count}}</span><span>{{item.create_time}}</span></div>
                  </div>
                </router-link>
              </li>


            </ul>
          </div>

          <div class="page">
             <el-pagination
               background
               hide-on-single-page
               :current-page.sync=zbpage
               @current-change="zongbu"
               layout="prev, pager, next"
               prev-text="上一页"
               next-text="下一页"
               :page-sizes="zongbuPage[0]['pageSize']"
               :pager-count= pagerCount
               :page-count="zongbuPage[0]['pageCount']"
               :key='zongbuData'>
             </el-pagination>
          </div>
        </div>
        <!-- 总部结束 -->
        <div class="newsjigou newsitemlist">
          <div class="newsitembox">
              <div class="newsjigoul">
                <div class="yangshiwrapl">
                  <h2>- 全  部 -</h2>
                  <div class="yangshibox">

                    <div class="yangshiitem" v-for="item,index in jigoulanmu" :key="item.id" @click="ysactive('jigou',index,item.id,jigouPage[0]['pageSize'])" :class="{ysactive:index==lanmuclick[0]['jigouclick']}">
                      <strong>{{item.name}}</strong>
                    </div>

                  </div>
                </div>
              </div>
              <div class="newsjigour"  v-loading="loading" :element-loading-text="loadtext">
                <ul>

                  <li v-for="item in jigouData"><router-link :to="{path: '/newslist/'+item.id+'.html'}">{{item.title}}</router-link> <em>{{item.count}}</em> <span>{{item.create_time}}</span></li>

                </ul>
              </div>
          </div>
          <div class="page">
             <el-pagination
               background
               :current-page.sync=otherpage
               @current-change="jigou"
               hide-on-single-page
               layout="prev, pager, next"
               prev-text="上一页"
               next-text="下一页"
               :page-sizes="jigouPage[0]['pageSize']"
               :pager-count= pagerCount
               :page-count="jigouPage[0]['pageCount']"
               :key='jigouData'>
             </el-pagination>
          </div>
        </div>
        <!-- 业务相关 -->
        <div class="newsyewu newsjigou newsitemlist">
          <div class="newsitembox">
              <div class="newsjigoul">
                <div class="yangshiwrapl">
                  <h2>- 全  部 -</h2>
                  <div class="yangshibox">

                    <div class="yangshiitem" v-for="item,index in yewulanmu" :key="item.id" @click="ysactive('yewu',index,item.id,yewuPage[0]['pageSize'])" :class="{ysactive:index==lanmuclick[0]['yewuclick']}">
                      <strong>{{item.name}}</strong>
                    </div>

                  </div>
                </div>
              </div>
              <div class="newsjigour" v-loading="loading" :element-loading-text="loadtext">
                <ul>
                  <li v-for="item in yewuData"><router-link :to="{path: '/newslist/'+item.id+'.html'}">{{item.title}}</router-link> <em>{{item.count}}</em> <span>{{item.create_time}}</span></li>
                </ul>
              </div>
          </div>
          
          <div class="page">
              <el-pagination
                background
                hide-on-single-page
                :current-page.sync=otherpage
                @current-change="yewu"
                layout="prev, pager, next"
                prev-text="上一页"
                next-text="下一页"
                :page-sizes="yewuPage[0]['pageSize']"
                :pager-count= pagerCount
                :page-count="yewuPage[0]['pageCount']"
                :key='yewuData'>
              </el-pagination>
          </div>
        </div>
        <!-- 业务相关 -->
        <!-- 普法资讯 -->
        <div class="newspufa newsitemlist">
          <div class="yangshiboxwrap">
            <ul>

              <li v-for="item in pufaData"><router-link :to="{path: '/newslist/'+item.id+'.html'}">{{item.title}}</router-link> <em>{{item.count}}</em> <span>{{item.create_time}}</span></li>

            </ul>
          </div>

          <div class="page">
             <el-pagination
               background
               hide-on-single-page
               :current-page.sync=otherpage
               @current-change="pufa"
               layout="prev, pager, next"
               prev-text="上一页"
               next-text="下一页"
               :page-sizes="pufaPage[0]['pageSize']"
               :pager-count= pagerCount
               :page-count="pufaPage[0]['pageCount']"
               :key='pufaData'>
             </el-pagination>
          </div>
        </div>
        <!-- 普法资讯 -->
      </div>

    </div>
  <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'NewsView',
    data(){
      return {
        zongbuData:[],
        zongbuPage:[
          {pageCount:1,pageSize:10}
        ],
        jigouData:[],
        jigouPage:[
           {pageCount:1,pageSize:20}
        ],
        yewuData:[],
        yewuPage:[
           {pageCount:1,pageSize:20}
        ],
        pufaData:[],
        pufaPage:[
           {pageCount:1,pageSize:20}
        ],
        loading: true,
        jigoulanmu:[],
        yewulanmu:[],
        lanmuclick:[{jigouclick: 0, yewuclick:0}],
        loadtext:'拼命加载中...',
        pagerCount:5,
        zbpage:1,
        otherpage:1
      }
    },
    methods:{

      //总部数据

      zongbuGetData(){
        let that = this

        request({
          url: '/news/read?id=29&page='+that.zbpage+'&page_size='+ that.zongbuPage[0]['pageSize'],
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata)
            if(jsondata['code'] == 200){
              // return jsondata;
               that.zongbuData = []
              let newdata = jsondata['data']['data']
              // console.log(newdata)
              newdata.forEach(function(val){
                  // console.log(val['thumb']);
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[17].length
                  val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                  that.zongbuData.push(val);
              });
              // console.log(formateData)
              that.loading = false
              that.zongbuPage[0]['pageCount'] = jsondata['data']['last_page']
            }
          }]
        })
      },
      // 总部分页
       zongbu(val){
         let that = this
          that.loading = true
          localStorage.setItem('zbpage',val)
         request({
          url: '/news/read?id=29&page='+that.zbpage+'&page_size='+ that.zongbuPage[0]['pageSize'],
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata)
            if(jsondata['code'] == 200){
              that.zongbuData = []
              let newdata = jsondata['data']['data']
              // let formateData = []
              newdata.forEach(function(val){
                  // console.log(val['thumb']);
                  if(val['thumb'].length > 50){
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[17].length
                    val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                  }
                that.zongbuData.push(val);
              });
              that.loading = false
              that.zongbuPage[0]['pageCount'] = jsondata['data']['last_page']
            }
          }]
        })
       },
       //普法分页
       pufa(val){
        let that = this
        that.loading = true
          localStorage.setItem('otherpage',val)
         request({
          url: '/news/othercate?id=64&page='+that.otherpage+'&page_size='+that.pufaPage[0]['pageSize'],
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.pufaData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let riqi = val['create_time'].split(' ')
                  val['create_time'] = riqi[0]
                  that.pufaData.push(val)
              });
              that.loading = false
              that.pufaPage[0]['pageCount'] = jsondata['data']['last_page']
            }
          }]
        })
       },
       //业务分页
       yewu(val){
         let that = this
        that.loading = true
        localStorage.setItem('otherpage',val)

         request({
          url: '/news/othercate?id=55&page='+this.otherpage+'&page_size='+that.yewuPage[0]['pageSize'],
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.yewuData = []
              let newData = jsondata['data'];
              //格式化时间
              newData['data'].forEach(function(val){
                  that.loading = false
                  let riqi = val['create_time'].split(' ')
                  val['create_time'] = riqi[0]
                  that.yewuData.push(val)
              });

              that.loading = false
              that.yewuPage[0]['pageCount'] = jsondata['data']['last_page']
            }
          }]
        })
       },
       //机构分页
       jigou(val){
         let that = this
        that.loading = true
        localStorage.setItem('jigoupage',val)

         request({
          url: '/news/othercate?id=50&page='+val+'&page_size='+that.jigouPage[0]['pageSize'],
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.jigouData = []
              let newData = jsondata['data'];
              //格式化时间
              newData['data'].forEach(function(val){
                  that.loading = false
                  let riqi = val['create_time'].split(' ')
                  val['create_time'] = riqi[0]
                  that.jigouData.push(val)
              });

              that.loading = false
              that.jigouPage[0]['pageCount'] = jsondata['data']['last_page']
            }
          }]
        })
       },

       //获取数据
       ysactive(name,k=0,itemid,pagesize){
// alert(itemid)
         let that = this
         let dataName = ''
         let zongyeshu = ''
         // alert(k)
  that.jigouData = []
        that.yewuData = []
        that.pufaData = []
         if(name=='jigou'){
            dataName = that.jigouData
            that.jigouPage[0]['pageSize'] = pagesize
            zongyeshu = that.jigouPage
           that.lanmuclick[0]['jigouclick'] = k
           localStorage.setItem("jigouk", k)

         }else if(name == 'yewu'){
           dataName = that.yewuData
           that.yewuPage[0]['pageSize'] = pagesize
          zongyeshu = that.yewuPage
           that.lanmuclick[0]['yewuclick'] = k
           localStorage.setItem("yewuk", k)
         }else if(name='pufa'){
           dataName = that.pufaData
           that.pufaPage[0]['pageSize'] = pagesize
           zongyeshu = that.pufaPage
         }


           // console.log(that.zongbuPage)
         that.loading = true
         that.loadtext = '数据加载中...'

         request({
           url: '/news/othercate?id='+itemid+'&page='+that.otherpage+'&page_size='+pagesize,
           responseType: 'json',
           transformResponse:[function(data){
             let jsondata = JSON.parse(data)
             if(jsondata['code'] == 200){
               // return jsondata;

                  let newData = jsondata['data'];
                  if(newData['total'] == 0){
                    that.loadtext = '没有数据'
                  }else{
                    // dataName = ''
                    // console.log(newData['per_page'])
                    newData['data'].forEach(function(val){
                        that.loading = false
                        let riqi = val['create_time'].split(' ')

                        val['create_time'] = riqi[0]
                        dataName.push(val)

                    });
                    // console.log(dataName);

                    zongyeshu[0]['pageCount']= newData['last_page']
                  }

             }
           }]
         })

       }
    },
    mounted(){
      //初始化

      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'newslist'){
          $(".chonggou a[href$='/newslist']").attr('class','router-link-active')
        }
      })
      let anbtn = $('.anlinav button')
      let newsitemlist  = $('.newsitemlist')
      let homeid = this.$route['query']['id'];
      if(homeid != undefined){
        this.lmid = homeid
        this.ysactive('jigou',0,homeid,6)
        anbtn.removeClass('curr')
        newsitemlist.hide()
        switch(homeid){
          case '50':
          anbtn.eq(1).addClass('curr')
          newsitemlist.eq(1).show()
          break;

        }
      }else{
        this.zongbuGetData()
      }

      let that = this


      let anid = null

      anbtn.click(function(){
        // alert('aaa')
        let idx = $(this).index()
        localStorage.setItem("otherpage",1)
        if(idx == 0){
          localStorage.setItem("tabname", "冠领总部新闻")
        }else if(idx == 1){
          localStorage.setItem("tabname", "冠领机构新闻")
        }else if(idx == 2){
          localStorage.setItem("tabname", "业务相关新闻")
        }else{
          localStorage.setItem("tabname", "普法资讯")
        }
          anbtn.css({
            'background': '#f3f3f3',
            'color': '#333'
          })
          anbtn.eq(idx).addClass('curr').siblings().removeClass('curr')
          anbtn.eq(idx).css({
            'background': '#b80816',
            'color': '#fff'
          })
           newsitemlist.eq(idx).stop().fadeIn().siblings().hide()

      })

      //初始化页面对数据进行验证
      let jigouk = localStorage.getItem("jigouk")
      let yewuk = localStorage.getItem("yewuk")

      if(jigouk == 'null'){
        localStorage.setItem("jigouk",0)
      }else{
        that.lanmuclick[0]['jigouclick'] = jigouk
        //$('.yangshibox .yangshiitem').eq(2).addClass('ysactive').siblings().removeClass('ysactive')
      }
      if(yewuk == 'null'){
        localStorage.setItem("yewuk",0)
      }


      let tsname = localStorage.getItem("tabname")
      let zbpage = localStorage.getItem("zbpage") == null ? 1 : localStorage.getItem("zbpage")
      let otherpage = localStorage.getItem("otherpage") == null ? 1 : localStorage.getItem("otherpage")

      if(tsname == 'null' || tsname == undefined){
        // alert('空')
      }else{
        if(tsname == '冠领总部新闻'){
          this.zongbuGetData()
          newsitemlist.eq(0).stop().fadeIn().siblings().hide()
          anbtn.eq(0).addClass('curr').siblings().removeClass('curr')

        }else if(tsname == '冠领机构新闻'){
          this.ysactive('yewu',yewuk,50,20)
          newsitemlist.eq(1).stop().fadeIn().siblings().hide()
          anbtn.eq(1).addClass('curr').siblings().removeClass('curr')
        }else if(tsname == '业务相关新闻'){
          this.ysactive('yewu',yewuk,55,20)
          newsitemlist.eq(2).stop().fadeIn().siblings().hide()
          anbtn.eq(2).addClass('curr').siblings().removeClass('curr')
        }else if(tsname == '普法资讯'){
          this.ysactive('pufa',0,64,20)
          newsitemlist.eq(3).stop().fadeIn().siblings().hide()
          anbtn.eq(3).addClass('curr').siblings().removeClass('curr')
        }
      }

      // alert('cccc')





      let strongbox = $('.yangshibox .yangshiitem strong')
      strongbox.click(function(){
        let that = $(this)
        that.parents('.yangshiitem').addClass('ysactive').siblings().removeClass('ysactive')
      })
    },
    watch:{
      jigoulanmu(){
        // alert('bbb')

          let tsname = localStorage.getItem("tabname")
          let nzbpage = localStorage.getItem("zbpage") == null ? 1 : localStorage.getItem("zbpage")
          let otherpage = localStorage.getItem("otherpage") == null ? 1 : localStorage.getItem("otherpage")
          // alert(localStorage.getItem("otherpage"))
          if(tsname == Object){
            this.zongbuGetData()
            $('.newsitemlist').eq(0).stop().fadeIn().siblings().hide()
            $('.anlinav button').eq(0).addClass('curr').siblings().removeClass('curr')
          }else if(tsname == '冠领总部新闻'){
            // alert(nzbpage)
            this.zbpage = nzbpage
            this.zongbuGetData()
            $('.newsitemlist').eq(0).stop().fadeIn().siblings().hide()
            $('.anlinav button').eq(0).addClass('curr').siblings().removeClass('curr')
            // alert('b')
          }else if(tsname == '冠领机构新闻'){
            // this.zbpage = zbpage
            this.otherpage = otherpage
            this.ysactive('jigou',otherpage,50,20)
            $('.newsitemlist').eq(1).stop().fadeIn().siblings().hide()
            $('.anlinav button').eq(1).addClass('curr').siblings().removeClass('curr')
            // alert('c')
          }else if(tsname == '业务相关新闻'){
            this.otherpage = otherpage
            this.ysactive('yewu',otherpage,55,20)
            $('.newsitemlist').eq(2).stop().fadeIn().siblings().hide()
            $('.anlinav button').eq(2).addClass('curr').siblings().removeClass('curr')
          }else if(tsname == '普法资讯'){
            this.otherpage = otherpage
            alert(otherpage)
            this.ysactive('pufa',0,64,20)
            $('.newsitemlist').eq(3).stop().fadeIn().siblings().hide()
            $('.anlinav button').eq(3).addClass('curr').siblings().removeClass('curr')
          }
      }
    },
      created(){
        //总部新闻数据
        let that = this


        //机构新闻栏目以及业务相关栏目
        request({
          url: '/Category/getcatelist?id=8',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              // console.log(jsondata)
              that.jigoulanmu = jsondata['data'][3]['child']
              that.yewulanmu = jsondata['data'][4]['child']
            }
          }]
        })
        //机构栏目默认请求第一个数据




    }
  }
</script>

<style lang="scss" scoped="scoped">
.news{
  .linebanbox{
    strong,small{
      color: #333;
    }
  }
  .newsinner{
    .anlinav{
      margin-top: 30px;
      padding-bottom: 30px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #f5f5f5;
      button{
        height: 70px;
        width: 285px;
        font-size: 22px;
        color: #333;
        background: #f3f3f3;
        border: none;
        cursor: pointer;
        border-radius: 4px;
        transition: all .2s linear 0s;
        position: relative;
      }
      button.curr{
        background: #b80816;
        color: #fff;
      }
      button.curr::after{
        content: "";
        width: 0;
        height: 0;
        border: 12px solid #b80816;
        border-bottom:12px solid transparent;
        border-right:12px solid transparent;
        border-left: 12px solid transparent;
        position: absolute;
        bottom: -23px;
        left: 50%;
        margin-left: -6px;
        transition: all .3s linear .5s;

      }

    }
    .newswrap{
      .zongbunews{
        .page{
          justify-content: center !important;
        }
      }
      margin-top: 20px;
      .newsitemlist:first-child{
        display: block;
      }
      .newsitemlist{

        display: none;
        .newsitembox{
          ul{
            li:Hover{
              strong{
                color: #b80816 !important;
              }
              img{
                transform: scale(1.1);
              }
            }
            li{
              height: 150px;
              padding-bottom: 20px;
              padding-top: 20px;
              border-bottom: 1px solid #eeeeee;
              a{
                display: flex;
                .itemboxl{
                  width: 180px;
                  margin-right: 20px;
                  overflow: hidden;
                  margin-left: 20px;
                  img{
                    transition: all .2s linear 0s;
                  }
                }
                .itemboxr{
                  width: 915px;
                  font-size: 18px;
                  color: #999999;
                  position: relative;
                  height: 150px;
                  strong{
                    font-size: 20px;
                    color: #333;
                    line-height: 100%;
                    margin-bottom: 14px;
                    display: block;
                    transition: all .2s linear 0s;
                  }
                  p{
                    line-height: 22px;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                    -webkit-line-clamp: 2;
                    overflow: hidden;
                  }
                  .newsnum{
                    position: absolute;
                    bottom: 0;
                    span{
                      display: inline-block;
                      background-repeat: no-repeat;
                      background-position: left center;
                      padding-left: 28px;
                      margin-right: 32px;
                    }
                    span:first-child{
                      background-image: url(../assets/yan.png);
                    }
                    span:last-child{
                      background-image: url(../assets/riqi.png);
                    }
                  }

                }
              }
            }
          }
        }
      }
      .newsjigou{
        .page{
          justify-content: flex-end;
          margin-right: 80px;
        }
        .newsitembox{
          display: flex;
          .newsjigoul{
            .yangshiwrapl{
              margin-right: 25px;
              width: 270px;
              box-sizing: border-box;

              h2{
                font-size: 22px;
                font-weight: bold;
                height: 68px;
                line-height: 68px;
                border: 1px solid #e5e5e5;
                text-align: center;
                border-radius: 8px 8px 0 0;
                border-bottom: none;
              }
              .yangshibox{
                border: 1px solid #e5e5e5;
                border-radius: 0 0 8px 8px;
                .yangshiitem:last-child{
                  strong,ul{
                    border-bottom: none;
                  }

                }
                .yangshiitem:first-child ul{
                  height: auto;
                }
                .yangshiitem:first-child ul li:first-child{
                  color: #b80816;
                }
                .yangshiitem{
                  strong{
                    font-weight: bold;
                    font-size: 20px;
                    color: #666666;
                    line-height: 70px;
                    height: 70px;
                    display: block;
                    padding-left: 85px;
                    border-bottom: 1px solid #e5e5e5;
                    cursor: pointer;
                    background: url(../assets/yangshiicon.jpg) no-repeat 188px center;
                    position: relative;
                  }

                }
                .ysactive{
                  strong{
                    color: #b80816;
                    background-image: url(../assets/yangshiicon-c.jpg);
                  }
                }
              }
            }
          }
          .newsjigour{
            width: 905px;
            ul{
              overflow: hidden;
              li{
                width: 100%;
                height: 60px;
                line-height: 60px;
                border: 1px solid #eeeeee;
                box-sizing: border-box;
                border-radius: 4px;
                margin-bottom: 15px;
                padding-left: 54px;
                background: url(../assets/alitemicon.png) no-repeat 29px center;
                display: flex;
                align-items: center;
                cursor: pointer;
                transition: all .3s linear 0s;
                b{
                  color: #999797;
                }
                a{
                  font-size: 18px;
                  display: block;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                  width: 60%;
                }
                em,span{
                  font-size: 18px;
                  color: #999999;
                }
                em{
                    background: url(../assets/yan.png) no-repeat left center;
                    padding-left: 28px;
                    margin-right: 32px;
                    margin-left: 70px;
                }
                span{
                  background: url(../assets/riqi.png) no-repeat left center;
                  padding-left: 24px;
                }

              }
              li:hover{
                background-image: url(../assets/alitemicon-s.png);
                border: 1px solid #b80816;
                em,span,a,b{
                  color: #b80816;
                }
                em{
                  background-image: url(../assets/yan-s.png);
                }
                span{
                  background-image: url(../assets/riqi-s.png);
                }
              }
            }
          }
        }
      }
      .newsyewu{
        .yangshiwrapl{
          strong{
            padding-left: 52px !important;
            background-position: 210px center !important;
          }
        }
      }
      .newspufa{
        .page{
          justify-content: center !important;
        }
        .yangshiboxwrap{
          ul{
            overflow: hidden;
            li{
              width: 100%;
              height: 60px;
              line-height: 60px;
              border: 1px solid #eeeeee;
              box-sizing: border-box;
              border-radius: 4px;
              margin-bottom: 15px;
              padding-left: 54px;
              background: url(../assets/alitemicon.png) no-repeat 29px center;
              display: flex;
              align-items: center;
              cursor: pointer;
              transition: all .3s linear 0s;
              b{
                color: #999797;
              }
              a{
                font-size: 18px;
                display: block;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: 70%;
              }
              em,span{
                font-size: 18px;
                color: #999999;
              }
              em{
                  background: url(../assets/yan.png) no-repeat left center;
                  padding-left: 28px;
                  margin-right: 32px;
                  margin-left: 70px;
              }
              span{
                background: url(../assets/riqi.png) no-repeat left center;
                padding-left: 24px;
              }

            }
            li:hover{
              background-image: url(../assets/alitemicon-s.png);
              border: 1px solid #b80816;
              em,span,a,b{
                color: #b80816;
              }
              em{
                background-image: url(../assets/yan-s.png);
              }
              span{
                background-image: url(../assets/riqi-s.png);
              }
            }
          }
        }
      }
    }
  }
}
</style>
