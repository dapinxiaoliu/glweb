<template>
  <div class="anli">
    <div class="comban">
      <img src="../assets/anliban.jpg" >
      <div>
        <strong>胜诉案例</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="anliwrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>胜诉案例</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="anlibox m20">
        <div class="anlibtn">
          <button class="curr" @click="anliHead('bj')">北京总部</button>
          <button @click="anliHead('sh')">上海</button>
          <button @click="anliHead('sz')">深圳</button>
          <button @click="anliHead('xa')">西安</button>
          <button @click="anliHead('km')">昆明</button>
        </div>
        <div class="anlisel">
          <div class="anliseline" @click="selectData"><span>选择业务领域：</span><p>{{one}} - {{two}}</p></div>
          <div class="anliseldata">
              <div class="anliseldatawrap">
                <div class="anliselleft">
                  <div class="anliselleftbox">
                    <span v-for="item,index in anliLanmu" :key="index"  @click="setColor(index,item.id)" :class="{ysactive: index==current}"><em></em>{{item.name}}</span>
                  </div>
                </div>
                <div class="anliselright">
                  <div class="anliselrightbox">
                    <div class="anlispan"><span v-for="item,index in anliLanmu[0]['child']" :data-id="item.id" :key="index" @click="anlispanColor(index,item.id)" :class="{ff: index==f}"><em></em>{{item.name}}</span></div>
                    <div class="anlispan"><span v-for="item,index in anliLanmu[1]['child']" :data-id="item.id" :key="index" @click="anlispanColor(index,item.id)" :class="{ff: index==f}"><em></em>{{item.name}}</span></div>
                    <div class="anlispan"><span @click="anlispanColor(0,item.id)" data-id=7 :class="{ff: 0==f}"><em></em>公司胜诉</span></div>
                    <div class="anlispan"><span @click="anlispanColor(0,item.id)" data-id=8 :class="{ff: 0==f}"><em></em>刑事胜诉</span></div>
                    <div class="anlispan"><span v-for="item,index in anliLanmu[4]['child']" :key="index" @click="anlispanColor(index,item.id)" :class="{ff: index==f}"><em></em>{{item.name}}</span></div>
                    <div class="anlispan"><span @click="anlispanColor(0,item.id)" data-id=10 :class="{ff: 0==f}"><em></em>交通胜诉</span></div>
                    <div class="anlispan"><span @click="anlispanColor(0,item.id)" data-id=31 :class="{ff: 0==f}"><em></em>行政诉讼</span></div>
                    <div class="anlispan"><span @click="anlispanColor(0,item.id)" data-id=47 :class="{ff: 0==f}"><em></em>待审核</span></div>
                    <div class="anlispan"><span @click="anlispanColor(0,item.id)" data-id=65 :class="{ff: 0==f}"><em></em>涉外胜诉</span></div>
                    <div class="anlispan"><span @click="anlispanColor(0,item.id)" data-id=66 :class="{ff: 0==f}"><em></em>招投标业务</span></div>
                    <div class="anlispan"><span @click="anlispanColor(0,item.id)" data-id=67 :class="{ff: 0==f}"><em></em>法律顾问</span></div>
                  </div>
                </div>
              </div>
              <div class="anliselbtn"><button class="reset">重置</button><button class="queding" @click="queding">确定</button></div>
          </div>
        </div>
        <ul class="anlisellist">
        	<li v-for="item,index in anliData" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">
            <p>{{item.title}}</p>
            <div><span>2022-02-22 </span><span>23055</span></div>
          </router-link></li>
        </ul>
      </div>
      <div class="page">
        <el-pagination
          background
          hide-on-single-page
          @current-change='compage'
          current-page=1
          layout="prev, pager, next"
          prev-text="上一页"
          next-text="下一页"
          pager-count= 5
          :page-count='lastPage'
          :key='cid'>
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default{
    name:'Anli',
    data(){
      return{
        one:'民事胜诉案例',
        two:'民间借贷案例',
        current:0,
        f:0,
        anliLanmu:[],
        anliData:[],
        lmid:0,
        cid:68,
        diyuid:1,
        pageSize:10,
        lastPage:0
      }
    },
    methods:{
      setColor(index,id){
        let e = window.event || event
        this.current = index
        this.f = 0
        this.lmid = id
        this.cid = $('.anlispan').eq(index).find('span').eq(0).data('id')
        this.one = e.target.innerText
        this.two = $('.anlispan').eq(index).find('span').eq(0).text()
        $('.anlispan').eq(index).fadeIn().siblings().hide()
        $('.anlispan').eq(index).find('span').eq(0).addClass('curr')
      },
      anlispanColor(index,cid){
        let e = window.event || event
        this.f = index
        this.two = e.target.innerText
        this.cid = cid

      },
      selectData(){
        $('.anliseldata').fadeIn()
      },
      //发送数据查询
      queding(){
        let that = this
        $('.anliseldata').fadeOut()
        this.getAnliData()
      },
      getAnliData(){
        let that = this
        request({
          url: '/anli/read?catid='+that.cid+'&id='+that.diyuid+'&page=1&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.anliData = []
               that.lastPage = 0
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
                $('.anli').css('padding-bottom','2rem')
              }else{
                $('.anli').css('padding-bottom','0')
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    let riqi = val['create_time'].split(' ')
                    val['create_time'] = riqi[0]
                    that.anliData.push(val)
                });
                // that.perpage = newData['per_page']
                that.lastPage = newData['last_page']
                // alert( that.lastPage)
              }
            }
          }]
        })
      },
      anliHead(name){
        this.cid = 68
        switch(name){
          case 'bj':
          this.diyuid = 1
          $('.anlibtn button').eq(0).addClass('curr').siblings().removeClass('curr')
          break;
          case 'sh':
          this.diyuid = 2
          $('.anlibtn button').eq(1).addClass('curr').siblings().removeClass('curr')
          break;
          case 'sz':
          this.diyuid = 3
          $('.anlibtn button').eq(2).addClass('curr').siblings().removeClass('curr')
          break;
          case 'xa':
          this.diyuid = 4
          $('.anlibtn button').eq(3).addClass('curr').siblings().removeClass('curr')
          break;
          case 'km':
          this.diyuid = 5
          $('.anlibtn button').eq(4).addClass('curr').siblings().removeClass('curr')
          break;
        }
        this.getAnliData()
        this.current = 0
        this.f = 0
        this.one = $('.anliselleftbox span').eq(0).eq(0).text()
        this.two = $('.anlispan').eq(0).find('span').eq(0).text()
        $('.anliseldata').fadeOut()
        $('.anlisellist').hide(0,function(){
          $('.anlisellist').fadeIn()
        })
      },
      compage(val){
        let that = this
        request({
          url: '/anli/read?catid='+that.cid+'&id='+that.diyuid+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.anliData = []
               that.lastPage = 0
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'

              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    let riqi = val['create_time'].split(' ')
                    val['create_time'] = riqi[0]
                    that.anliData.push(val)
                });
                // that.perpage = newData['per_page']
                that.lastPage = newData['last_page']
              }
            }
          }]
        })
      },
      //获取侧边栏目
      getLanmu(){
        let that = this
        that.anliLanmu = []
        request({
          url: '/Category/getcatelist?id=2',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata['data'])
            if(jsondata['code'] == 200){
             jsondata['data'].forEach(function(val){
                  if(val['child'][0] == undefined){
                      val['cid'] =  val['id'];
                      that.anliLanmu.push(val)
                  }else{
                    val['cid'] =  val['child'][0]['id'];
                    that.anliLanmu.push(val)
                  }
              });
              // console.log( that.anliLanmu);
            }
          }]
        })
      },

    },
    mounted() {
      this.getAnliData()
      this.queding()
      this.getLanmu()
      let that = this
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'case'){
          $(".chonggou a[href$='/case']").attr('class','router-link-active')
        }
      })
      //按钮
      let anlibtn = $('.anlibtn button')
      anlibtn.click(function(){
        // alert('a')
        // $(this).addClass('curr').siblings().removeClass('curr')
        // anliselright.eq(0).addClass('f').siblings().removeClass('f')
        // anliselleftbox.eq(0).addClass('f').siblings().removeClass('f')
        // that.one = anliselleftbox.eq(0).text()
        // that.two = anliselright.eq(0).text()
        // $('.anlisellist').hide(0,function(){
        //   $('.anlisellist').fadeIn()
        // })
        // $('.anliseldata').fadeOut()
      })

      // let anliselleftbox = $('.anliselleftbox span')
      // let anliselright = $('.anliselright span')
      // anliselleftbox.eq(0).addClass('f')
      // anliselright.eq(0).addClass('f')
      // that.one = anliselleftbox.eq(0).text()
      // that.two = anliselright.eq(0).text()
      // anliselleftbox.click(function(){
      //   let index = $(this).index()
      //   that.two = anliselright.eq(0).text()
      //   anliselright.eq(0).addClass('f').siblings().removeClass('f')
      //   $(this).addClass('f').siblings().removeClass('f')
      //   that.one = $(this).text()
      // })
      // anliselright.click(function(){
      //    that.two = $(this).text()
      //   $(this).addClass('f').siblings().removeClass('f')
      // })


      // let anliselinep = $('.anliseline p')
      // let queding = $('.queding')
      // let reset = $('.reset')
      // anliselinep.click(function(){
      //   $('.anliseldata').fadeIn()
      // })
      // queding.click(function(){

      //   $('.anliseldata').fadeOut(0,function(){
      //     $('.anlisellist').hide(0,function(){
      //       $('.anlisellist').fadeIn()
      //     })
      //   })

      // })
      // reset.click(function(){
      //   that.one = anliselleftbox.eq(0).text()
      //   that.two = anliselright.eq(0).text()
      //   anliselright.eq(0).addClass('f').siblings().removeClass('f')
      //   anliselleftbox.eq(0).addClass('f').siblings().removeClass('f')
      // })
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .anlispan{
    display: none;
  }
  .anlispan:first-child{
    display: block;
  }
  .ysactive,.ff{
    color: #b80816;
    em{
      border: 1px solid #b80816 !important;
      background: url(../assets/duihao.png) no-repeat center / .16rem .11rem;
    }
  }
  .anli{
    .anliwrap{
      .anlibox{
        position: relative;
        .anlibtn{
          margin-top: .25rem;
          margin-bottom: .3rem;
          display: flex;
          justify-content: space-between;

          button{
            height: .5rem;
            width: 1.26rem;
            background: #eeeeee;
            color: #666666;
            cursor: pointer;
            font-size: .26rem;
            white-space: nowrap;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          button.curr{
            color: #fff;
            background-color: #b80816;
          }
        }
        .anlisel{

          .anliseldata{
            display: none;
            width: 7.1rem;
            padding-bottom: .4rem;
            background: #fff;
            position: absolute;
            top: 1.7rem;
            left: 0;
            z-index: 999;
            left: 50%;
            margin-left: -3.55rem;
            padding-top: .5rem;
            box-shadow: 0 0 .08rem #ccc;
            border-radius: .08rem;
              .anliseldatawrap{
                 display: flex;
              }
              .anliselbtn{
                display: flex;
                justify-content: center;
                margin-top: .26rem;
                margin-bottom: .1rem;
                button{
                  height: .5rem;
                  width: 1.8rem;
                  border-radius: .25rem;
                  box-sizing: border-box;
                  text-align: center;
                  line-height: .5rem;
                  cursor: pointer;
                  font-size: .24rem
                }
                button:first-child{
                  background: #fff;
                  border: 1px solid #b80816;
                  margin-right: .2rem;
                  color: #b80816;
                }
                button:last-child{
                  background: #b80816;
                  color: #fff;
                }
              }
            .anliselright,.anliselleft{
              flex:1;
              margin-left: .8rem;
              .anliselleftbox,.anliselrightbox{
                display: flex;
                flex-direction: column;
                justify-content: space-around;

              }
              span{
                display:block;
                font-size: .26rem;
                margin-bottom: .12rem;
                margin-top: .12rem;
                padding: .02rem 0;
                cursor: pointer;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                position: relative;
                text-indent: .4rem;

                em{
                  content: "";
                  width: .24rem;
                  height: .24rem;
                  border: 1px solid #666666;
                  position: absolute;
                  left: 0;
                  top: .05rem;
                  border-radius: .05rem;
                }
              }

            }
            .anliselleft{
              border-right: 1px solid #dddddd;
            }
          }
          .anliseline{
            display: flex;
            flex-wrap: nowrap;
            justify-content: space-between;
            span{
              font-size: .26rem;
              font-weight: bold;
              color: #333;
              height: .6rem;
              line-height: .6rem;
              white-space: nowrap;
            }
            p{
              height: .6rem;
              line-height: .6rem;
              width: 5.15rem;
              border: 1px solid #dcdcdc;
              box-sizing: border-box;
              text-indent: .1rem;
              font-size: .28rem;
              position: relative;
              cursor: pointer;
            }
            p::after{
              content: "";
              width: 0;
              height: 0;
              border-top: .18rem solid #000000;
              border-left: .18rem solid transparent;
              border-right: .18rem solid transparent;
              border-bottom: .18rem solid transparent;
              position: absolute;
              bottom: -.03rem;
              right: .17rem;
              cursor: pointer;
            }
          }

        }
        ul{
          margin-top: .4rem;
          margin-bottom: .25rem;
          li:first-child{
            border-top: 1px dashed #dddddd;
          }
          li{
            overflow: hidden;
            height: 1.48rem;
            border-bottom: 1px dashed #dddddd;
             position: relative;
            p{
              font-size: .28rem;
              line-height: .36rem;
              margin-top: .16rem;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
            div{
              position: absolute;
              bottom: .16rem;
              span{
                font-size: .26rem;
                color: #999;
                background-repeat: no-repeat;
                background-position: left center;
                display: inline-block;
                text-indent: .28rem;
              }
              span:first-child{
                background-image: url(../assets/riqi.png);
                background-size: .19rem;
                margin-right: .65rem;
              }
              span:last-child{
                background-image: url(../assets/yan.png);
                background-size: .2rem .16rem;
              }
            }

          }
        }
      }
    }
  }
</style>
