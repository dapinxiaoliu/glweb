<template>
  <div class="anli">
   <div class="linebanbox">
     <img src="../assets/newslineimg.jpg" class="autoc">
     <div class="linebanhead">
       <strong>冠领公告</strong>
       <small>全球咨询热线：400-8789-888</small>
     </div>
   </div>
  <div class="anliinner w1200">
    <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;冠领公告</div>
    <div class="anlinav">
      <button class="curr" @click="getNewData(48)">委托公告</button>
      <button  @click="getNewData(1)">开庭公告</button>
      <button  @click="getNewData(2)">办案公告</button>
    </div>
    <div class="anliwrap">
      <div class="yangshiwrapr" v-loading="loading" :element-loading-text="loadtext">
        <div class="yangshiboxwrap" >
          <ul>
            <li v-for="item,index in ggdata" :key="index">
              <router-link :to="{path: '/notice/'+item.id+'.html'}">
              <i v-if="item.leibie == 1">民商</i>
              <i v-else-if="item.leibie == 2">行政</i>
              <i v-else>无</i>
                <p>{{item.title}}</p>   <em>{{item.count}}</em> <span>{{item.create_time}}</span>
              </router-link>
            </li>
          </ul>
        </div>

        <div class="page">
           <el-pagination
             background
             hide-on-single-page
            :current-page.sync='fenyeid'
             @current-change="fenye"
             layout="prev, pager, next"
             prev-text="上一页"
             next-text="下一页"
             :page-sizes="pageSize"
             :pager-count= pagerCount
             :page-count="lastPage"
             :key='lmid'>
           </el-pagination>
        </div>
      </div>
    </div>
  </div>
<div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'AnliView',
    data(){
      return{
        ggdata:[],
        pageSize:20,
        pagerCount:5,
        lastPage:0,
        lmid:0,
        loadtext:'数据加载中...',
        loading: false,
        isable: true,
        ggname:'委托',
        fenyeid:1,
        weituoid:1,
        kaitingid:1,
        bananid:1,
        currentPage:1

      }
    },
    methods:{
      getNewData(id){
        this.fenyeid = 1

        this.getData(id)
      },
      getData(id){
        let that = this
        that.lmid = id
        that.loading = true
        that.loadtext = '数据加载中...'
        // let fenyeid = localStorage.getItem('fenyeid')
        // that.fenyeid = localStorage.getItem('fenyeid') == null ? 1 : localStorage.getItem('fenyeid')
  // alert(typeof localStorage.getItem('weituoid'))
        if(id == 48){
          localStorage.setItem('ggname','委托')
        }else if(id == 1){
          localStorage.setItem('ggname','开庭')
        }else{
          localStorage.setItem('ggname','办案')
        }
        request({
          url: '/gonggao/read?id='+that.lmid+'&page='+that.fenyeid+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            console.log(jsondata);
            if(jsondata['code'] == 200){
            // alert(jsondata['data'])
              that.ggdata = []
              if(jsondata['data']['total'] == 0){
                that.loading = false
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];

                newData['data'].forEach(function(val){
                    that.loading = false
                    let riqi = val['create_time'].split(' ')
                    val['create_time'] = riqi[0]
                    that.ggdata.push(val)
                });
                that.fenyeid = newData['current_page']
                that.currentPage = newData['current_page']
                that.pageSize = newData['per_page']
                that.lastPage = newData['last_page']
              }
            }
          }]
        })
      },
      fenye(val){
        let that = this
        that.loading = true
        that.fenyeid = val
        localStorage.setItem('fenyeid',val)
        request({
          url: '/gonggao/read?id='+that.lmid+'&page='+that.fenyeid+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){

              that.ggdata = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{

                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let riqi = val['create_time'].split(' ')
                    val['create_time'] = riqi[0]
                    that.ggdata.push(val)
                });

                // that.pageSize = newData['per_page']
                that.fenyeid = newData['current_page']
                that.currentPage = newData['current_page']
                that.lastPage = newData['last_page']
              }
            }
          }]
        })
      }
    },
    mounted(){
      let that = this

      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'notice'){
          $(".chonggou a[href$='/notice']").attr('class','router-link-active')
        }

      })




      let anbtn = $('.anlinav button')
      let yangshiboxwrap = $('.yangshiboxwrap')

      let anid = null
      anbtn.click(function(){
        let idx = $(this).index()
        //验证是否为中间的数据
        if(idx == 1){
          $('.yangshiboxwrap em').css('margin-left','18px')
        }else{
          $('.yangshiboxwrap em').css('margin-left','70px')
        }

        // alert(typeof that.lmid)
        $('.yangshiboxwrap li i').hide()
        if(that.lmid == 1){
          $('.yangshiboxwrap ul i').show()
        }
        $(this).addClass('curr').siblings().removeClass('curr')

        yangshiboxwrap.hide(0,function(){
          $(this).fadeIn()
        })
      })

      // //页面初始化
      let gaoname = localStorage.getItem('ggname')
      // let gaoname = this.ggname

      // alert(this.ggname)
      if(gaoname == null){
        this.getData(48)
        localStorage.setItem('ggname','委托')
      }else{
        // alert('b')
        // let aname = localStorage.getItem('ggname')

        let fyid = localStorage.getItem('fenyeid')
        // alert(fyid)
        // alert(fyid)
        if(fyid == null){
          fyid = 1
        }else{
            this.fenyeid = fyid
            if(gaoname == '委托'){
              this.getData(48)
              $('.anlinav button').eq(0).addClass('curr').siblings().removeClass('curr')
            }else if(gaoname == '开庭'){
              this.getData(1)
              $('.yangshiboxwrap ul i').show()
              $('.anlinav button').eq(1).addClass('curr').siblings().removeClass('curr')
            }else if(gaoname == '办案'){
              this.getData(2)
              $('.anlinav button').eq(2).addClass('curr').siblings().removeClass('curr')
            }
        }

      }


    },
    watch:{
      lmid(){
        let that = this
        setTimeout(function(){
          let fyidx = localStorage.getItem('fenyeid') == null ? 1 : localStorage.getItem('fenyeid')
          let ggname = localStorage.getItem('ggname') == null ? '委托' : localStorage.getItem('ggname')
          // alert(fyidx)
          if(fyidx == 1){
            // that.fenyeid = 1
          }
           // that.fenyeid = fyidx
          if(ggname == '委托'){
            // alert('aa')
            that.fenyeid = 1
            that.getData(48)
            $('.anlinav button').eq(0).addClass('curr').siblings().removeClass('curr')
          }

        },10)
        
        if(ggname == '开庭'){
          // alert('a')
          that.fenyeid = fyidx
          that.getData(1)
          $('.yangshiboxwrap ul i').show()
          $('.anlinav button').eq(1).addClass('curr').siblings().removeClass('curr')
        }else if(ggname == '办案'){
          that.fenyeid = fyidx
          that.getData(2)
          $('.anlinav button').eq(2).addClass('curr').siblings().removeClass('curr')
        }


      }
    }

  }
</script>

<style lang="scss" scoped="scoped">
  .anli{
    .linebanbox{
      div{
        color: #333;
      }
    }
    .anliinner{
      .anliwrap{
        // display: flex;
      }
      .anlinav{
        width: 940px;
        margin: 30px auto 40px;
        display: flex;
        justify-content: space-between;
        button{
          height: 70px;
          width: 300px;
          font-size: 22px;
          color: #333;
          background: #f3f3f3;
          border: none;
          cursor: pointer;
          border-radius: 4px;
          // transition: all .2s linear 0s;
          position: relative;
        }
        button.curr{
          background: #b80816;
          color: #fff;
        }
        button.curr::after{
          content: "";
          width: 0;
          height: 0;
          border: 12px solid #b80816;
          border-bottom:12px solid transparent;
          border-right:12px solid transparent;
          border-left: 12px solid transparent;
          position: absolute;
          bottom: -23px;
          left: 50%;
          margin-left: -6px;
          transition: all .3s linear .5s;
        }

      }
      .yangshiwrapr:first-child{
        display: block;
      }
      .yangshiwrapr{
        display: none;
        .yangshiboxwrap{
          ul{
            overflow: hidden;
            li{
              width: 100%;
              height: 60px;
              line-height: 60px;
              border: 1px solid #eeeeee;
              box-sizing: border-box;
              border-radius: 4px;
              margin-bottom: 15px;
              padding-left: 54px;
              background: url(../assets/alitemicon.png) no-repeat 29px center;
              display: flex;
              align-items: center;
              cursor: pointer;
              transition: all .3s linear 0s;
              i{
                display: none;
                width: 50px;
                position: relative;
              }
              i::after{
                content: "";
                width: 1px;
                height: 20px;
                background: #333;
                position: absolute;
                top: 50%;
                right: 7px;
                margin-top: -10px;

              }
              b{
                color: #999797;
              }
              a{
                font-size: 18px;
                display: flex;
                align-items: center;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                p{
                  width: 850px;
                }

              }
              em,span{
                font-size: 18px;
                color: #999999;
              }

              em{
                  background: url(../assets/yan.png) no-repeat left center;
                  padding-left: 28px;
                  margin-right: 32px;
                  margin-left: 70px;
              }
              span{
                background: url(../assets/riqi.png) no-repeat left center;
                padding-left: 24px;
                width: 100px;
                display: block;
              }

            }
            li:hover{
              background-image: url(../assets/alitemicon-s.png);
              border: 1px solid #b80816;
              em,span,a,b,i{
                color: #b80816;
              }
              i:after{
                background: #b80816;
              }
              em{
                background-image: url(../assets/yan-s.png);
              }
              span{
                background-image: url(../assets/riqi-s.png);
              }
            }
          }
        }

      }
    }
  }
</style>
