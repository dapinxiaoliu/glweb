<template>
  <div class="honor">
    <div class="linebanbox">
      <img src="../assets/newslineimg.jpg" class="autoc">
      <div class="linebanhead">
        <strong>冠领荣誉</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="honorinner w1200">
      <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;冠领荣誉</div>
      <div class="honorwrap">
        <div class="honorbtn">
          <button class="f" @click="jinqi(24,15)">锦旗荣誉</button>
          <button @click="jiangbei(25,9)">奖杯荣誉</button>
          <button @click="haoping(149,12)">好评荣誉</button>
        </div>
        <div class="honorbox">
          <div class="honorboxwrap">
            <ul class="honorjq honoritem">
            	<li v-for="item,index in jinqiData" :key="index"><router-link :to="{path:'/honor/'+item.id+'.html'}"><div><img :src="item.thumb" ></div><p>{{item.title}}</p></router-link></li>
            </ul>
          </div>
          <div class="honorboxwrap">
            <ul class="honorjb honoritem">
              <li v-for="item,index in jiangbeiData" :key="index"><router-link :to="{path:'/honor/'+item.id+'.html'}"><div><img :src="item.thumb" ></div><p>{{item.title}}</p></router-link></li>

            </ul>
          </div>
          <div class="honorboxwrap">
            <ul class="honorhp honoritem">
              <li v-for="item,index in haopingData" :key="index"><router-link :to="{path:'/honor/'+item.id+'.html'}"><div><img :src="item.thumb" ></div></router-link></li>
            </ul>
          </div>
        </div>
        <div class="page">
          <el-pagination
            background
            hide-on-single-page
            @current-change='compage'
            current-page=1
            layout="prev, pager, next"
            prev-text="上一页"
            next-text="下一页"
            pager-count= 5
            :page-count = a
            :key='lmid'>
          </el-pagination>
      </div>
    </div>
    </div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default{
    name: 'HonorView',
    data(){
      return {
        fenye:0,
        jinqiData:[],
        jiangbeiData:[],
        haopingData:[],
        jinqiCount:0,
        jiangbeiCount:0,
        haopingCount:0,
        lmid:0,
        a:0
      }
    },
    methods:{
      jinqi(id,size){
        this.getjinqiData(id,size)
      },
      jiangbei(id){
        this.getjinqiData(id)
      },
      haoping(id,size){
        this.getjinqiData(id,size)
      },
      getjinqiData(lmid,pagesize=9){
        let that = this
        that.lmid = lmid
        that.fenye = pagesize
        request({
          url: '/honor/read?id='+lmid+'&page=1&page_size='+pagesize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.jinqiData = []
              that.jiangbeiData = []
              that.haopingData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[21].length
                  val['thumb'] = 'http://api.guanlingms.com'+thumb[21].substr(1,thumblength-4);
                  if(lmid == 24){
                    that.jinqiData.push(val)
                  }else if(lmid == 25){
                    that.jiangbeiData.push(val)
                  }else{
                    that.haopingData.push(val)
                  }
              });
              if(lmid == 24){
                that.a = newData['last_page']
              }else if(lmid == 25){
                that.a = newData['last_page']
              }else{
                that.a = newData['last_page']
              }
            }
          }]
        })
      },
      compage(val){
        let that = this
        request({
          url: '/honor/read?id='+that.lmid+'&page='+val+'&page_size='+that.fenye,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.jinqiData = []
              that.jiangbeiData = []
              that.haopingData = []
              that.a = 0
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[21].length
                  val['thumb'] = 'http://api.guanlingms.com'+thumb[21].substr(1,thumblength-4);
                  if(that.lmid == 24){
                    that.jinqiData.push(val)
                  }else if(that.lmid == 25){
                    that.jiangbeiData.push(val)
                  }else{
                    that.haopingData.push(val)
                  }
              });
              if(that.lmid == 24){
                that.a = newData['last_page']
              }else if(that.lmid == 25){
                that.a = newData['last_page']
              }else{
                that.a = newData['last_page']
              }
            }
          }]
        })
      }
    },
    mounted() {

      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'honor'){
          $(".chonggou a[href$='/honor']").attr('class','router-link-active')
        }
      })
      let honorbtn = $('.honorbtn button')
      honorbtn.click(function(){
        let index = $(this).index()
        $(this).addClass('f').siblings().removeClass('f')
        $('.honorboxwrap').eq(index).stop().show().siblings().hide()
      })
      let homeid = this.$route['query']['id'];
      if(homeid != undefined){
        this.lmid = homeid
        this.getjinqiData(homeid)
        $('.honorbtn button').removeClass('f')
        $('.honorboxwrap').hide()
        if(homeid == 24){
          $('.honorbtn button').eq(0).addClass('f')
          $('.honorboxwrap').eq(0).show()
        }
        if(homeid == 25){
          $('.honorbtn button').eq(1).addClass('f')
          $('.honorboxwrap').eq(1).show()
        }
        if(homeid == 149){
          $('.honorbtn button').eq(2).addClass('f')
          $('.honorboxwrap').eq(2).show()
        }
      }else{
         this.getjinqiData(24,15)
      }


    }
  }
</script>

<style lang="scss" scoped="scoped">
  .honor{
    .f{
      background: #b80816;
      color: #fff !important;
      position: relative;
    }
    .f::after{
      content: "";
      position: absolute;
      bottom: -5px;
      left: 50%;
      margin-left: -5px;
      width: 10px;
      height: 10px;
      background: #b80816;
      transform: rotate(45deg);
    }

    .linebanbox{
      div{
        color: #333 !important;
      }
    }
    .honorinner{
      .honorwrap{
        .honorbtn{
          display: flex;
          justify-content: center;
          margin-top: 30px;
          button{
            font-size: 22px;
            color: #333;
            height: 70px;
            width: 300px;
            border-radius: 6px;
            line-height: 70px;
            text-align: center;
            border: none;
            outline: none;
            cursor: pointer;
          }
          button:nth-child(2){
            margin: 0 20px;
          }
        }
        .honorbox{
          margin-top: 30px;
          .honorboxwrap:first-child{
            display: block;
          }
          .honorboxwrap{
            display: none;
          }
          .honoritem{
            border-top: 1px solid #f5f5f5;
            padding-top: 40px;
            display: flex;
            justify-content: flex-start;
            flex-wrap: wrap;
            // li:hover{
            //   img{
            //     transform: scale(1.1);
            //   }
            // }

            p{
              font-size: 18px;
              color: #666;
              text-align: center;
              line-height: 28px;
              padding: 10px 0;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
            img{
              transition: all .3s linear 0s;
            }
            div{
              overflow: hidden;
            }
          }
          .honorjq{
            // height: 1334px;
            li:nth-child(5n+5){
              margin-right: 0;
            }
            li{
              width: 215px;
              margin-right: 31px;
              overflow: hidden;
              margin-bottom: 35px;

              div{
                width: 215px;
                height: 320px;
              }
              a{
                img{
                  height: 320px;
                  border-radius: 6px;
                }

              }
            }
          }
          .honorjb{
            // height: 1110px;
            li:nth-child(3n+3){
              margin-right: 0;
            }
            li{
              width: 380px;
              margin-right: 30px;
              margin-bottom: 50px;
              p{
                  -webkit-line-clamp: 2;
              }
              img{
                width: 380px;
                height: 259px;
              }
            }
          }
          .honorhp{
            // height: 815px;
            li:nth-child(4n+4){
              margin-right: 0;
            }
            li{
              width: 280px;
              border: 1px solid #c2c2c2;
              margin-right: 23px;
              margin-bottom: 30px;
            }
          }
        }
      }
    }
  }
</style>
