<template>
  <div class="news">
    <div class="linebanbox">
      <img src="../assets/newslineimg.jpg" class="autoc" >
      <div class="linebanhead">
        <strong>冠领新闻</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>

    <div class="newsinner w1200">
      <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;冠领新闻</div>
      <div class="anlinav">
        <button class="curr">冠领总部新闻</button>
        <button>冠领机构新闻</button>
        <button>业务相关新闻</button>
        <button>普法资讯</button>
      </div>
      <div class="newswrap">
        <!-- 总部开始-->
        <div class="zongbunews newsitemlist">
          <div class="newsitembox">
            <ul>

            	<li v-for="item in zongbuData" :key="item.id">
                <router-link to="">
                  <div class="itemboxl"><img :src="item.thumb" ></div>
                  <div class="itemboxr">
                    <strong>{{item.title}}{{nowpage}}</strong>
                    <p>{{item.miaoshu}}</p>
                    <div class="newsnum"><span>{{item.count}}</span><span>{{item.create_time}}</span></div>
                  </div>
              </router-link>
              </li>


            </ul>
          </div>
          <div class="page">
              <div class="pageleft"><button class="zbsy">首页</button><button class="zbpre">上一页</button></div>
              <div class="pagemid">
                <ul class="pageul">
                  <li class="xuanzhong">1</li>
                  <li>2</li>
                  <li>3</li>
                  <li>4</li>
                  <li class="pagenull">...</li>
                  <li>8</li>
                </ul>
              </div>
              <div class="pageright"><button>下一页</button><p>共<em>{{totalpage}}</em>页<em>{{totalnum}}</em>条数据</p></div>
          </div>
        </div>
        <!-- 总部结束 -->
        <div class="newsjigou newsitemlist">
          <div class="newsitembox">
              <div class="newsjigoul">
                <div class="yangshiwrapl">
                  <h2>- 全  部 -</h2>
                  <div class="yangshibox">
                    <div class="yangshiitem ysactive">
                      <strong>上海冠领</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>深圳冠领</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>昆明冠领</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>西安冠领</strong>
                    </div>
                  </div>
                </div>
              </div>
              <div class="newsjigour">
                <ul>
                  <li><router-link :to="{path: '/gonggao/gginfo'}">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">1华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙为申请鸿为申请鸿为申请鸿为申请鸿商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                </ul>
              </div>
          </div>
          <div class="page">
              <div class="pageleft"><button>首页</button><button>上一页</button></div>
              <div class="pagemid">
                <ul class="pageul">
                  <li class="xuanzhong">1</li>
                  <li>2</li>
                  <li>3</li>
                  <li>4</li>
                  <li class="pagenull">...</li>
                  <li>8</li>
                </ul>
              </div>
              <div class="pageright"><button>下一页</button><p>共<em>{{totalpage}}</em>页<em>12</em>条数据</p></div>
          </div>
        </div>
        <!-- 业务相关 -->
        <div class="newsyewu newsjigou newsitemlist">
          <div class="newsitembox">
              <div class="newsjigoul">
                <div class="yangshiwrapl">
                  <h2>- 全  部 -</h2>
                  <div class="yangshibox">
                    <div class="yangshiitem ysactive">
                      <strong>民事诉讼</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>行政诉讼</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>公司业务</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>刑事诉讼</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>知识产权诉讼</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>交通事故诉讼</strong>
                    </div>
                    <div class="yangshiitem">
                      <strong>涉外业务</strong>
                    </div>
                  </div>
                </div>
              </div>
              <div class="newsjigour">
                <ul>
                  <li><router-link :to="{path: '/gonggao/gginfo'}">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">1华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙为申请鸿为申请鸿为申请鸿为申请鸿商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                  <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
                </ul>
              </div>
          </div>
          <div class="page">
              <div class="pageleft"><button>首页</button><button>上一页</button></div>
              <div class="pagemid">
                <ul class="pageul">
                  <li class="xuanzhong">1</li>
                  <li>2</li>
                  <li>3</li>
                  <li>4</li>
                  <li class="pagenull">...</li>
                  <li>8</li>
                </ul>
              </div>
              <div class="pageright"><button>下一页</button><p>共<em>8</em>页<em>12</em>条数据</p></div>
          </div>
        </div>
        <!-- 业务相关 -->
        <!-- 普法资讯 -->
        <div class="newspufa newsitemlist">
          <div class="yangshiboxwrap">
            <ul>
              <li><router-link :to="{path: '/gonggao/gginfo'}">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">3华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">华为申请鸿蒙为申请鸿为申请鸿为申请鸿为申请鸿商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
              <li><router-link to="">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</router-link> <em>23055</em> <span>2021-11-12</span></li>
            </ul>
          </div>

          <div class="page">
              <div class="pageleft"><button>首页</button><button>上一页</button></div>
              <div class="pagemid">
                <ul class="pageul">
                	<li class="xuanzhong">1</li>
                	<li>2</li>
                	<li>3</li>
                	<li>4</li>
                	<li class="pagenull">...</li>
                	<li>8</li>
                </ul>
              </div>
              <div class="pageright"><button>下一页</button><p>共<em>8</em>页<em>12</em>条数据</p></div>
          </div>
        </div>
        <!-- 普法资讯 -->
      </div>

    </div>
  <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'NewsView',
    data(){
      return {
        zongbuData:{},
        totalpage: 0,
        totalnum: 0,
        nowpage: 1,
        pagenum: 6, //每页显示多少条
        nowli: 0  //当前选中第几个li
      }
    },
    methods:{
    },
    mounted(){
      let that = this
      $(".chonggou a").attr('class','')
      if(this.$route.name == 'news'){
        $(".chonggou a[href='/news']").attr('class','router-link-active')
      }

      let anbtn = $('.anlinav button')
      let newsitemlist  = $('.newsitemlist')
      let anid = null
      anbtn.mouseover(function(){
        let idx = $(this).index()
        clearTimeout(anid)
        anid = setTimeout(function(){
          anbtn.css({
            'background': '#f3f3f3',
            'color': '#333'
          })
          anbtn.eq(idx).addClass('curr').siblings().removeClass('curr')
          anbtn.eq(idx).css({
            'background': '#b80816',
            'color': '#fff'
          })
           newsitemlist.eq(idx).stop().fadeIn().siblings().hide()
        },200)
      })

      let strongbox = $('.yangshibox .yangshiitem strong')
      strongbox.click(function(){
        let that = $(this)
        that.parents('.yangshiitem').addClass('ysactive').siblings().removeClass('ysactive')
      })
    //总部新闻

      //上一页
      let zbpre = $('.zbpre');
      zbpre.click(function(){
        // alert(typeof that.nowpage)
        // alert(that.nowpage)
        if(that.nowpage != 1){

          let npage = parseInt(that.nowpage)
          that.nowli == 0 ? that.nowli = 1 : that.nowli
          if(that.nowli == 1){//选中第二个li
              if(that.nowpage == 2){
                pageulli.eq(0).addClass('xuanzhong').siblings().removeClass('xuanzhong')
              }else{
                pageulli.eq(0).text(npage-2)
                pageulli.eq(1).text(npage-1)
                pageulli.eq(2).text(npage)
                pageulli.eq(3).text(npage+1)
                npage = npage+5 >= that.totalpage ? that.totalpage : npage+5
                pageulli.eq(5).text(npage)
              }
          }
          if(that.nowli == 2){//选中第三个li
            if(that.nowpage == 3){
              pageulli.eq(1).addClass('xuanzhong').siblings().removeClass('xuanzhong')
            }else if(that.nowpage == 2){
              pageulli.eq(0).addClass('xuanzhong').siblings().removeClass('xuanzhong')
            }else{

              pageulli.eq(0).text(npage-3)
              pageulli.eq(1).text(npage-2)
              pageulli.eq(2).text(npage-1)
              pageulli.eq(4).show()
              pageulli.eq(3).text(npage)

              pageulli.eq(5).text(npage+4)



            }
          }
          if(that.nowli == 5){
            // if(that.nowpage == 6){
            //   pageulli.eq(0).text(npage-5)
            //   pageulli.eq(1).text(npage-4)
            //   pageulli.eq(2).text(npage-3)
            //   pageulli.eq(3).text(npage-2)
            //   pageulli.eq(4).css('display','none')
            //   pageulli.eq(5).text(npage-1)
            // }else if(that.nowpage == 5){
            //    pageulli.eq(3).addClass('xuanzhong').siblings().removeClass('xuanzhong')
            // }else if(that.nowpage == 4){
            //    pageulli.eq(2).addClass('xuanzhong').siblings().removeClass('xuanzhong')
            // }else if(that.nowpage == 3){
            //    pageulli.eq(1).addClass('xuanzhong').siblings().removeClass('xuanzhong')
            // }else if(that.nowpage == 2){
            //    pageulli.eq(0).addClass('xuanzhong').siblings().removeClass('xuanzhong')
            //    pageulli.eq(4).css('display','block')
            //    pageulli.eq(5).text(npage+6)
            // }else{
              if(that.nowpage == that.totalpage){
                pageulli.eq(3).addClass('xuanzhong').siblings().removeClass('xuanzhong')
              }else if(that.nowpage == that.totalpage-1){
                pageulli.eq(2).addClass('xuanzhong').siblings().removeClass('xuanzhong')
              }else if(that.nowpage == that.totalpage-2){
                pageulli.eq(1).addClass('xuanzhong').siblings().removeClass('xuanzhong')
                that.nowli = 1
                pageulli.eq(4).show()
              }else{
                pageulli.eq(0).text(npage-5)
                pageulli.eq(1).text(npage-4)
                pageulli.eq(2).text(npage-3)
                pageulli.eq(3).text(npage-2)
                // pageulli.eq(4).css('display','none')
                pageulli.eq(5).text(npage-1)
              }

            // }
          }
          that.zongbunew(--that.nowpage, that.pagenum)
        }
      })
      //首页
      let zbsy = $('.zbsy')
      zbsy.click(function(){

        that.zongbunew(1, that.pagenum)
        pageulli.eq(0).addClass('xuanzhong').siblings().removeClass('xuanzhong')
        pageulli.eq(0).text(1)
        pageulli.eq(1).text(2)
        pageulli.eq(2).text(3)
        pageulli.eq(3).text(4)
        pageulli.eq(4).text('...')
        pageulli.eq(5).text(8)
        pageulli.eq(4).addClass('pagenull')

      })
      //点击每一页
      let pageulli = $('.pageul li')

      pageulli.click(function(){

        let idx = $(this).text()
         // alert(idx)
        if(idx == '...') return false
        if($(this).index() != 3){
          that.nowli = $(this).index()
          if($(this).index() == 5){
            // let npage = parseInt(that.nowpage)
            let npage = parseInt(pageulli.eq(5).text())
                if(npage == 8){
                  pageulli.eq(0).text(npage-1)
                  pageulli.eq(1).text(npage)
                  pageulli.eq(2).text(npage+1)
                  pageulli.eq(3).text(npage+2)
                }

                  // alert(er)
                // npage = npage >=  that.totalpage ? that.totalpage : npage+6
            // alert(npage)
                let cha = that.totalpage-npage
                if(cha <= 4){

                  npage+=2
                  if(cha <= 0) return false
                }else{
                  npage+=6
                }
                if(npage == that.totalpage){
                  pageulli.eq(0).text(npage-4)
                  pageulli.eq(1).text(npage-3)
                  pageulli.eq(2).text(npage-2)
                  pageulli.eq(3).text(npage-1)
                  // pageulli.eq(4).hide()
                  pageulli.eq(5).text(npage)
                  pageulli.eq(5).addClass('xuanzhong').siblings().removeClass('xuanzhong')
                  that.nowli = 4
                }else{
                  pageulli.eq(0).text(npage-5)
                  pageulli.eq(1).text(npage-6)
                  pageulli.eq(2).text(npage-4)
                  pageulli.eq(3).text(npage-3)
                  pageulli.eq(5).text(npage)
                  pageulli.eq(1).addClass('xuanzhong').siblings().removeClass('xuanzhong')
                 that.nowli = 1
                }




                that.zongbunew(npage, that.pagenum)
          }else{
            $(this).addClass('xuanzhong').siblings().removeClass('xuanzhong')
            $('.pagenull').removeClass('xuanzhong')
            if(that.nowpage != idx){
              that.zongbunew(idx, that.pagenum)
            }
          }
        }else{
          // alert(idx)
          idx = parseInt(idx)
            pageulli.eq(5).text(idx+6)
            // pageulli.eq(4).text(idx+3)
            pageulli.eq(3).text(idx+2)
            pageulli.eq(2).text(idx+1)
            pageulli.eq(1).text(idx)
            pageulli.eq(0).text(idx-1)
            // pageulli.eq(4).removeClass('pagenull')
            pageulli.eq(1).addClass('xuanzhong').siblings().removeClass('xuanzhong')

          if(idx+4 >= that.totalpage){
            pageulli.eq(0).text(that.totalpage-4)
            pageulli.eq(1).text(that.totalpage-3)
            pageulli.eq(2).text(that.totalpage-2)
            pageulli.eq(3).text(that.totalpage-1)
            pageulli.eq(5).text(that.totalpage)
            // pageulli.eq(5).addClass('xuanzhong').siblings().removeClass('xuanzhong')
            pageulli.each(function(){
              if($(this).text() == that.nowpage){
                $(this).addClass('xuanzhong').siblings().removeClass('xuanzhong')
              }
            })
          }

            that.nowli = 1




            that.zongbunew(idx, that.pagenum)

        }




      })


    },
    methods:{

     zongbunew(nowpage,shownum){
        let that = this
         request({
          url: '/news/read?id=29&page='+nowpage+'&page_size='+ shownum,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata)
            if(jsondata['code'] == 200){
              // return jsondata;
              let newdata = jsondata['data']['data']
              let formateData = []
              // console.log(newdata)
              newdata.forEach(function(val){
                  // console.log(val['thumb']);
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[17].length
                  val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                  formateData.push(val);
              });
              that.zongbuData = formateData
              that.totalnum = jsondata['data']['total']
              that.totalpage = jsondata['data']['last_page']
              that.nowpage = jsondata['data']['current_page']
            }
          }]
        })
      }
    },
    created(){
   //总部新闻
      let that = this
      zongbunew(1, that.pagenum)
      // alert(zbdata)
      function zongbunew(nowpage, shownum){
         request({
          url: '/news/read?id=29&page='+nowpage+'&page_size='+ shownum,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            console.log(jsondata)
            if(jsondata['code'] == 200){
              // return jsondata;
              let newdata = jsondata['data']['data']
              let formateData = []
              // console.log(newdata)
              newdata.forEach(function(val){
                  // console.log(val['thumb']);
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[17].length
                  val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                  formateData.push(val);
              });
              that.zongbuData = formateData
              that.totalnum = jsondata['data']['total']
              that.totalpage = jsondata['data']['last_page']
              that.nowpage = jsondata['data']['current_page']
            }
          }]
        })
      }
    }
  }
</script>

<style lang="scss" scoped="scoped">
.news{
  .linebanbox{
    strong,small{
      color: #333;
    }
  }
  .newsinner{
    .anlinav{
      margin-top: 30px;
      padding-bottom: 30px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #f5f5f5;
      button{
        height: 70px;
        width: 285px;
        font-size: 22px;
        color: #333;
        background: #f3f3f3;
        border: none;
        cursor: pointer;
        border-radius: 4px;
        transition: all .2s linear 0s;
        position: relative;
      }
      button:first-child{
        background: #b80816;
        color: #fff;
      }
      button.curr::after{
        content: "";
        width: 0;
        height: 0;
        border: 12px solid #b80816;
        border-bottom:12px solid transparent;
        border-right:12px solid transparent;
        border-left: 12px solid transparent;
        position: absolute;
        bottom: -23px;
        left: 50%;
        margin-left: -6px;
        transition: all .3s linear .5s;
      }

    }
    .newswrap{
      .zongbunews{
        .page{
          justify-content: center !important;
        }
      }
      margin-top: 20px;
      .newsitemlist:first-child{
        display: block;
      }
      .newsitemlist{

        display: none;
        .newsitembox{
          ul{
            li:Hover{
              strong{
                color: #b80816 !important;
              }
              img{
                transform: scale(1.1);
              }
            }
            li{
              padding-bottom: 20px;
              padding-top: 20px;
              border-bottom: 1px solid #eeeeee;
              a{
                display: flex;
                .itemboxl{
                  width: 180px;
                  margin-right: 20px;
                  overflow: hidden;
                  margin-left: 20px;
                  img{
                    transition: all .2s linear 0s;
                  }
                }
                .itemboxr{
                  width: 915px;
                  font-size: 18px;
                  color: #999999;
                  strong{
                    font-size: 20px;
                    color: #333;
                    line-height: 100%;
                    margin-bottom: 14px;
                    display: block;
                    transition: all .2s linear 0s;
                  }
                  p{
                    line-height: 22px;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                    -webkit-line-clamp: 2;
                    overflow: hidden;
                  }
                  .newsnum{
                    margin-top: 33px;
                    span{
                      display: inline-block;
                      background-repeat: no-repeat;
                      background-position: left center;
                      padding-left: 28px;
                      margin-right: 32px;
                    }
                    span:first-child{
                      background-image: url(../assets/yan.png);
                    }
                    span:last-child{
                      background-image: url(../assets/riqi.png);
                    }
                  }

                }
              }
            }
          }
        }
      }
      .newsjigou{
        .page{
          justify-content: flex-end;
          margin-right: 80px;
        }
        .newsitembox{
          display: flex;
          .newsjigoul{
            .yangshiwrapl{
              margin-right: 25px;
              width: 270px;
              box-sizing: border-box;

              h2{
                font-size: 22px;
                font-weight: bold;
                height: 68px;
                line-height: 68px;
                border: 1px solid #e5e5e5;
                text-align: center;
                border-radius: 8px 8px 0 0;
                border-bottom: none;
              }
              .yangshibox{
                border: 1px solid #e5e5e5;
                border-radius: 0 0 8px 8px;
                .yangshiitem:last-child{
                  strong,ul{
                    border-bottom: none;
                  }

                }
                .yangshiitem:first-child ul{
                  height: auto;
                }
                .yangshiitem:first-child ul li:first-child{
                  color: #b80816;
                }
                .yangshiitem{
                  strong{
                    font-weight: bold;
                    font-size: 20px;
                    color: #666666;
                    line-height: 70px;
                    height: 70px;
                    display: block;
                    padding-left: 85px;
                    border-bottom: 1px solid #e5e5e5;
                    cursor: pointer;
                    background: url(../assets/yangshiicon.jpg) no-repeat 188px center;
                    position: relative;
                  }

                }
                .ysactive{
                  strong{
                    color: #b80816;
                    background-image: url(../assets/yangshiicon-c.jpg);
                  }
                }
              }
            }
          }
          .newsjigour{
            width: 905px;
            ul{
              overflow: hidden;
              li{
                width: 100%;
                height: 60px;
                line-height: 60px;
                border: 1px solid #eeeeee;
                box-sizing: border-box;
                border-radius: 4px;
                margin-bottom: 15px;
                padding-left: 54px;
                background: url(../assets/alitemicon.png) no-repeat 29px center;
                display: flex;
                align-items: center;
                cursor: pointer;
                transition: all .3s linear 0s;
                b{
                  color: #999797;
                }
                a{
                  font-size: 18px;
                  display: block;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                  width: 60%;
                }
                em,span{
                  font-size: 18px;
                  color: #999999;
                }
                em{
                    background: url(../assets/yan.png) no-repeat left center;
                    padding-left: 28px;
                    margin-right: 32px;
                    margin-left: 70px;
                }
                span{
                  background: url(../assets/riqi.png) no-repeat left center;
                  padding-left: 24px;
                }

              }
              li:hover{
                background-image: url(../assets/alitemicon-s.png);
                border: 1px solid #b80816;
                em,span,a,b{
                  color: #b80816;
                }
                em{
                  background-image: url(../assets/yan-s.png);
                }
                span{
                  background-image: url(../assets/riqi-s.png);
                }
              }
            }
          }
        }
      }
      .newsyewu{
        .yangshiwrapl{
          strong{
            padding-left: 52px !important;
            background-position: 210px center !important;
          }
        }
      }
      .newspufa{
        .page{
          justify-content: center !important;
        }
        .yangshiboxwrap{
          ul{
            overflow: hidden;
            li{
              width: 100%;
              height: 60px;
              line-height: 60px;
              border: 1px solid #eeeeee;
              box-sizing: border-box;
              border-radius: 4px;
              margin-bottom: 15px;
              padding-left: 54px;
              background: url(../assets/alitemicon.png) no-repeat 29px center;
              display: flex;
              align-items: center;
              cursor: pointer;
              transition: all .3s linear 0s;
              b{
                color: #999797;
              }
              a{
                font-size: 18px;
                display: block;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: 70%;
              }
              em,span{
                font-size: 18px;
                color: #999999;
              }
              em{
                  background: url(../assets/yan.png) no-repeat left center;
                  padding-left: 28px;
                  margin-right: 32px;
                  margin-left: 70px;
              }
              span{
                background: url(../assets/riqi.png) no-repeat left center;
                padding-left: 24px;
              }

            }
            li:hover{
              background-image: url(../assets/alitemicon-s.png);
              border: 1px solid #b80816;
              em,span,a,b{
                color: #b80816;
              }
              em{
                background-image: url(../assets/yan-s.png);
              }
              span{
                background-image: url(../assets/riqi-s.png);
              }
            }
          }
        }
      }
    }
  }
}
</style>
