<template>
  <div class="caifu">
    <div class="caifuban"><img src="@/assets/caifuban.jpg" alt=""></div>
    <div class="caifubox">
      <!-- 私人财富规划传承 -->
      <div class="chuancheng">
        <div class="chuanchengwrap w1200">
          <div class="ccleft">
            <strong>私人财富规划传承</strong>
              <p>冠领坚持为每一位客户提供优质的私人财富规划与传承服务，拥有该领域专业知识和丰富经验的高端人才。为客户的财产管理、继承纠纷、资产及投资等提供专业的法律服务。同时，专注于家族企业、高净值人士等私人财富法律风险管理诉讼及非诉服务，以实现家庭的和谐与传承。</p>              <p>强烈的市场需求催生了私人财富管理业务的飞速发展，也为私人财富管理专业人士提供了前所未有的机遇和挑战。冠领整合优化律师资源，建立私人财富管理专家库，可提供专业的私人财富管理服务和专家支持。</p>
          </div>
          <div class="ccright">
            <img src="@/assets/ccimg.jpg" alt="">
          </div>
        </div>
      </div>

      <!-- 业务领域 -->
      <div class="lingyu">
        <strong>业务领域</strong>
        <div class="lingyuwrap w1200">
          <div thumbsSlider="" class="swiper mySwiper  ">
            <div class="swiper-wrapper">
              <div class="swiper-slide">企业财富管理</div>
              <div class="swiper-slide">家族信托规划</div>
              <div class="swiper-slide">家族财富管理</div>
              <div class="swiper-slide">私人财富传承</div>
              <div class="swiper-slide">税务规划</div>
              <div class="swiper-slide">分家析产</div>

            </div>
          </div>
         <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper2 swiper-no-swiping">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="inner">
                  <span>企业财富管理</span>
                  <p>企业进行的财富规划和资产管理， 包括投资与筹资活动管理、 营运资本管理， 以及品牌、 人力资本等隐性财富的管理等， 以达到降低风险和资产增值的目的。</p>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="inner">
                  <span>家族信托规划</span>
                  <p>信托是指委托人基于对受托人的信任，将其财产权委托给受托人，由受托人按委托人的意愿以自己的名义，为受益人的利益或者特定目的，进行管理或者处理。</p>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="inner">
                  <span>家族财富管理</span>
                  <p>家族财富是指具有继承家族文化、民族精神、家族价值与家族资产来传承与拓展基业长青的财富。</p>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="inner">
                  <span>私人财富传承</span>
                  <p>高净值人士数量迅速增长，他们在财富增值与传承方面面临诸多问题与困惑。</p>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="inner">
                  <span>税务规划</span>
                  <p>我们熟悉各区拆迁政策、拆迁协议、拆迁调查取证的流程以及各地法院的判决思路，有大量办理因拆迁引发的分家析产案件经验，合理保障当事人的合法权益。</p>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="inner">
                  <span>分家析产</span>
                  <p>我们熟悉各区拆迁政策、拆迁协议、拆迁调查取证的流程以及各地法院的判决思路，有大量办理因拆迁引发的分家析产案件经验，合理保障当事人的合法权益。</p>
                </div>
              </div>


            </div>

          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
      <!-- 冠领优势 -->
      <div class="youshi">
        <div class="w1200">
           <strong>冠领优势</strong>
            <ul>
              <li><img src="@/assets/caifuys01.jpg" alt=""></li>
              <li>
                <span>周旭亮主任优势</span>
                <p>选择合适的财富传承工具，是私人财富传承中非常重要的环节之一。北京冠领律师事务所主任周旭亮律师，法律实务经验丰富，重视客户需求，擅长为客户量身制定私人财富传承规划，遗嘱、家族信托、保险等常见的财富传承手段都是他熟悉的领域。</p>
              </li>
              <li><img src="@/assets/caifuys02.jpg" alt=""></li>
              <li>
                <span>团队优势</span>
                <p>不同家庭对财富传承规划的理念不同，但是重视程度都在加深。北京冠领律师事务所员工多来自于国内外知名院校，拥有研究生学历，工作经验丰富，可以根据各种需求，制定高品质私人财富传承规划方案。</p>
              </li>
              <li><img src="@/assets/caifuys03.jpg" alt=""></li>
              <li>
                <span>任战敏执行主任优势</span>
                <p>私人财富传承规划涉及到非常多的法律问题，一不小心牵扯的便是整个家庭的财富。北京冠领律师事务所执行主任任战敏律师，在金融法领域经验丰富，擅长各类重大法律事务的咨询策划，为私人制定无法律死角的财富传承规划是他努力的方向之一。</p>
              </li>
              <li><img src="@/assets/caifuys04.jpg" alt=""></li>
              <li>
                <span>地域优势</span>
                <p>私人财富传承规划随着社会经济的发展也在不断的受到大众的重视，全国各地的人们都有着财富传承规划的需求。北京冠领律师事务所足迹遍布全国三十四个省市，私人财富传承规划的需求在哪里，冠领就到哪里。</p>
              </li>
              <li><img src="@/assets/caifuys05.jpg" alt=""></li>
              <li>
                <span>业务优势</span>
                <p>私人财富传承规划往往会涉及到分配不均的情况，在这种情况下，法律建议的介入是非常有必要的。冠领业务范围广泛，在解决继承、房产、金融保险等问题上有深厚功底，擅长定制先进私人财富传承规划方案。</p>
              </li>
              <li><img src="@/assets/caifuys06.jpg" alt=""></li>
              <li>
                <span>专家优势</span>
                <p>私人财富传承规划需要量身定做，其中涉及的知识范围极为广泛，专家学者的意见对于规划的制定来说非常可贵。北京冠领律师事务所特有专家网络，聘请了国内知名院校以及各法律领域法的知名学者组成顾问团队，提供全面的业务指导。</p>
              </li>
            </ul>
        </div>
      </div>
      <!-- emd -->
    </div>
  </div>
</template>

<script>
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  export default{
    name: 'CaifuView',
    methods:{},
    mounted() {

        var swiper = new Swiper(".mySwiper", {
          spaceBetween: 0,
          slidesPerView: 9,
          // slidesPerView: "auto",
          freeMode: true,
          watchSlidesProgress: false,
        });
        var swiper2 = new Swiper(".mySwiper2", {
          loop:true,
          spaceBetween: 0,
          slidesPerView: 1,
          initialSlide : 0,//默认第三页
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          thumbs: {
            swiper: swiper,
          },
        });
    }

  }
</script>

<style scoped lang="scss">
  .caifu{
    .caifuban{
      img{
        width: 100%;
      }

    }
    .caifubox{
      .chuancheng{
        margin-top: 82px;
        .chuanchengwrap{
          display: flex;
          justify-content: space-between;
          .ccleft{
            width: 690px;
            margin-left: 30px;
            strong{
              display: block;
              font-size: 24px;
              font-weight: bold;
              line-height: 100%;
              color: #b80816;
              margin-bottom: 30px;
              position: relative;
              width: 192px;
              margin-top: 25px;
            }
            strong::after{
              content: "";
              position: absolute;
              width: 100%;
              height: 2px;
              left: 0;
              bottom: -10px;
              background: linear-gradient(to right,#b80816,#c7c7c7);

            }
            p{
              font-size: 16px;
              color: #333;
              line-height: 27px;
              text-indent: 2em;
            }
            p:nth-of-type(1){
              margin-bottom: 26px;
            }
          }
          .ccright{
            width: 430px;
            display: flex;
            justify-content: center;
            position: relative;
            img{
              position: relative;
              z-index: 2;
              border: 3px solid #fff;
            }
          }
          .ccright::after{
            content: "";
            position: absolute;
            width: 100%;
            height: 112px;
            background: #b80816;
            bottom: -16px;
            z-index: 1;
          }
        }
      }
      .lingyu{
        margin-top: 66px;
        height: 446px;
        background: url('../../../assets/caifubg01.jpg') no-repeat center top / 1920px 446px;
        overflow: hidden;
        strong{
          display: block;
          font-size: 36px;
          font-weight: bold;
          color: #fff;
          text-align: center;
          line-height: 100%;
          margin-top: 50px;
          margin-bottom: 34px;
          letter-spacing: 2px;
        }
        .lingyuwrap{
          width: 1070px;
          margin: 0 auto;
          position: relative;
          // overflow: hidden;
          .mySwiper{
              .swiper-wrapper{
                display: flex;
                justify-content: space-between;
                .swiper-slide{
                  font-size: 20px;
                  color: #fff;
                  border: 1px solid #fff;
                  height: 60px;
                  text-align: center;
                  line-height: 60px;
                  cursor: pointer;
                  border-radius: 6px;
                  white-space: nowrap;
                  padding: 0 20px;
                  position: relative;
                  z-index: 5;
                }
                .swiper-slide-thumb-active{
                  background-color: #b80816;
                }
                .swiper-slide-thumb-active::after{
                  content: "";
                  position: absolute;
                  width: 25px;
                  height: 13px;
                  background: url('../../../assets/sanjiao.png') no-repeat center / 25px 13px;
                  bottom: -13px;
                  left: 50%;
                  margin-left: -6px;
                }
              }
          }
          .mySwiper2{
            height: 170px;
            margin-top: 35px;
            background: #fff;
            border-radius: 6px;
            position: relative;
            overflow: hidden;
            .swiper-slide{
              width: 1070px !important;
              .inner{
                margin: 0 50px;
                span{
                  display: block;
                  font-size: 20px;
                  font-weight: bold;
                  color: #b80816;
                  line-height: 100%;
                  margin: 25px 0;
                  position: relative;
                  text-indent: 10px;
                }
                span::after{
                  content: "";
                  width: 4px;
                  height: 20px;
                  background: #b80816;
                  position: absolute;
                  left: 0;
                  top: 1px;
                }
                p{
                  line-height: 26px;
                }
              }
            }
          }
          .swiper-button-next,.swiper-button-prev{
            width: 50px;
            height: 50px;
            top: 66%;
          }
          .swiper-button-next::after,.swiper-button-prev::after{
            content: "";
          }
          .swiper-button-prev{
            background: url('../../../assets/caifuleft.png') no-repeat center / 50px;
            left: -70px;
          }
          .swiper-button-next{
            background: url('../../../assets/caifuright.png') no-repeat center / 50px;
            right: -70px;
          }
        }
      }
      .youshi{
        padding-bottom: 30px;
        background: #f4f5f7 url('../../../assets/caifuysbg.jpg') no-repeat center bottom / 1920px 292px;
        strong{
          display: block;
          line-height: 100%;
          font-size: 36px;
          font-weight: bold;
          text-align: center;
          color: #333;
          padding-top: 50px;
          margin-bottom: 34px;
        }
        ul{
          display: flex;
          flex-wrap: wrap;
          justify-content: space-between;
          li{
            width: 386px;
            margin-bottom: 40px;

            img{
              transition: all .3s linear;
            }
          }
          li:hover{
            img{
              transform: scale(1.1);
            }
          }
          li:nth-child(even)::after{
            content: "";
            position: absolute;
            width: 40px;
            height: 40px;
            background: #b80816;
            top: -13px;
            left: 50%;
            margin-left: -20px;
            transform: rotate(45deg);
          }
          li:nth-child(2)::after,
          li:nth-child(8)::after{
            content: "";
            width: 42px;
            height: 21px;
            top: auto;
            bottom: -20px;
            background: transparent;
            transform: rotate(0);
            background: url('../../../assets/caifuysicon.png') no-repeat center / 42px 21px;
          }
          li:nth-child(odd){
            overflow: hidden;
          }
          li:nth-child(even){
            position: relative;
            background: url('../../../assets/caifuys.jpg') no-repeat center / 386px 242px;
            color: #fff;
            span{
              display: block;
              line-height: 100%;
              text-align: center;
              font-weight: bold;
              font-size: 20px;
              margin-top: 30px;
              position: relative;
            }
            span::after{
              content: "";
              width: 30px;
              height: 3px;
              background: #fff;
              position: absolute;
              left: 50%;
              margin-left: -15px;
              bottom: -15px;
            }
            p{
              line-height: 24px;
              padding: 0 22px;
              margin-top: 20px;
            }
          }
        }
      }

    }
  }
</style>
