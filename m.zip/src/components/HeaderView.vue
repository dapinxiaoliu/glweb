<template>
  <div>
    <div class="header">
       <a href="/"><img src="../assets/logo.jpg" ></a>
       <a href="tel:4008789888"><img src="../assets/htel.jpg" ></a>
     </div>
     <div class="nav">
       <ul class="chonggou">
       	<li><router-link to="/">冠领首页</router-link></li>
       	<li><router-link to="/yewu">全球业务</router-link></li>
       	<li><router-link to="/branch">冠领机构</router-link></li>
       	<li><router-link to="/tv">冠领央视</router-link></li>
       	<li><router-link to="/case">胜诉案例</router-link></li>
       	<li><router-link to="/newslist">新闻动态</router-link></li>
       	<li><router-link to="/lawyer">律师团队</router-link></li>
       	<li><router-link to="/notice">冠领公告</router-link></li>
       	<li><router-link to="/honor">冠领荣誉</router-link></li>
       	<li><router-link to="/about/1497.html">关于我们</router-link></li>
       </ul>
     </div>
  </div>
</template>
<script>

</script>

<style lang="scss" scoped="scoped">
  .header{
    display: flex;
    justify-content: space-between;
    height: .9rem;
    align-items: center;
    padding: 0 .2rem;
    background: #fff;
    a:first-child{
      width: 4.04rem;
    }
    a:last-child{
      width: 2.33rem;
    }
  }
  .nav{
    ul{
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;

      li{
        display: flex;
        justify-content: center;
        align-items: center;
        background: #f3f3f3;
        margin-bottom: .02rem;
        transition: all .3s linear 0s;
        a{
          font-size: .3rem;
          color: #b80816;
          transition: all .3s linear 0s;
          height: .78rem;
          width: 1.48rem;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        a.router-link-active{
          color: #fff;
          background: #b80816;
        }
      }
    }
  }
</style>
