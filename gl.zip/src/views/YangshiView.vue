<template>
  <div class="yangshi">
    <div class="linebanbox">
      <img src="../assets/spfm.jpg" class="autoc">
      <div class="linebanhead">
        <strong>冠领在央视</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="yangshiinner w1200">


    <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;冠领在央视</div>
    <div class="yangshiwrap">
      <div class="yangshiwrapl">
        <h2>- 全  部 -</h2>
        <div class="yangshibox">
          <div class="yangshiitem" v-for="item,index in anliLanmu" :key="index" @click="ysactive(index)" :class="{ysactive: index==isSelect}">
            <strong @click="getlanmuData(item.cid)">{{item.name}}</strong>
            <ul>
              <li v-for="i,idx in item.child" @click="setRed(idx,i.id)" :class="{isredclass:isRed == idx}">{{i.name}}</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="yangshiwrapr" v-loading="loading" :element-loading-text="loadtext">
        <div class="yschild">
          <div class="yschildwrap">
            <div class="yschilditem" v-for="item,index in vdata" :key="index" @click="setcache(lmid,isSelect,item.id,isRed)">
              <router-link :to="{path: '/tv/'+item.id+'.html'}">
                <h2><img :src="item.thumb" ></h2>
                <p>{{item.title}}</p>
              </router-link>
            </div>
          </div>
          <div class="page">
             <el-pagination
               background
               hide-on-single-page
               @current-change="compage"
               :current-page.sync=pagenow
               layout="prev, pager, next"
               prev-text="上一页"
               next-text="下一页"
               :page-sizes=pageSize
               :pager-count= 5
               :page-count='lastPage'
               :key='lmid'>
             </el-pagination>
          </div>
        </div>
      </div>
    </div>
    </div>
    <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'YangshiView',
    data(){
      return {
        anliLanmu:[],
        isSelect: 0,
        isRed:0,
        pageSize:9,
        lastPage:0,
        vdata:[],
        lmid:0,
        loading: false,
        loadtext:'数据加载中...',
        pagenow:1,
        gengxin:''
      }
    },
    methods:{
      ysactive(index){
        this.isSelect = index
        localStorage.setItem("nowpage", 1)
      },
      setRed(val,idx){
        this.isRed = val
        localStorage.setItem("nowpage", 1)
        this.getData(idx)
      },
      getlanmuData(idx){
        localStorage.setItem("nowpage", 1)
        this.getData(idx)
        this.isRed = 0
      },
      setcache(lmid,lmids,idx,tvid){
          localStorage.setItem("tvlmid", lmid)
          localStorage.setItem("tvlmids", lmids)
          localStorage.setItem("tvidx", idx)
          localStorage.setItem("tvid", tvid)
      },
      compage(val){
        let that = this
        that.loading = true
        that.loadtext = '数据加载中...'
        that.pagenow = val
        localStorage.setItem("nowpage", that.pagenow)
        request({
           url: '/video/read?id='+that.lmid+'&page='+that.pagenow+'&page_size='+ that.pageSize,
           responseType: 'json',
           transformResponse:[function(data){
             let jsondata = JSON.parse(data)
             if(jsondata['code'] == 200){
              let newData = jsondata['data'];
               that.vdata = []
               if(jsondata['data']['total'] == 0){
                 that.loadtext = '没有数据'
                 that.pageSize = newData['per_page']
                 that.lastPage = newData['last_page']
               }else{


                 newData['data'].forEach(function(val){
                     that.loading = false
                     let thumb = val['thumb'].split(':')
                     let thumblength = thumb[21].length
                     val['thumb'] = GLOBAL.httpurl+thumb[21].substr(1,thumblength-4);
                     that.vdata.push(val)
                      // console.log(val)
                 });

                 that.pageSize = newData['per_page']
                 that.lastPage = newData['last_page']

               }
             }
           }]
         })
      },
      //获取数据
      getData(lmid){
        let that = this
        that.loading = '数据加载中...'
        that.lmid = lmid
        that.pagenow = localStorage.getItem("nowpage") == null ? 1 : localStorage.getItem("nowpage")
       request({
          url: '/video/read?id='+lmid+'&page='+that.pagenow+'&page_size='+ that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
            // console.log(jsondata['data']);
              that.vdata = []
                let newData = jsondata['data'];
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
                that.pageSize = newData['per_page']
                that.lastPage = newData['last_page']
              }else{


                newData['data'].forEach(function(val){
                    that.loading = false
                    let thumb = val['thumb'].split(':')
                    let thumblength = thumb[21].length
                    val['thumb'] = GLOBAL.httpurl+thumb[21].substr(1,thumblength-4);
                    that.vdata.push(val)
                     // console.log(val)
                });
                that.pagenow = newData['current_page']
                that.pageSize = newData['per_page']
                that.lastPage = newData['last_page']

              }
            }
          }]
        })
      },
      asidelanmu(){
        //获取侧边栏目
        let that = this
        that.anliLanmu = []
        request({
          url: '/Category/getcatelist?id=7',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata['data'])
            if(jsondata['code'] == 200){
             jsondata['data'].forEach(function(val){
                  if(val['child'][0] == undefined){
                      val['cid'] =  val['id'];
                      that.anliLanmu.push(val)
                  }else{
                    val['cid'] =  val['child'][0]['id'];
                    that.anliLanmu.push(val)
                  }
                  that.loading = false
              });
              // that.anliLanmu = jsondata['data']
              // console.log(that.anliLanmu)
            }
          }]
        })
      }
    },
    created(){
      this.asidelanmu()
      // this.getData(33)
    },
    watch:{
     anliLanmu(val){
       this.gengxin = localStorage.getItem("tvlmid")
        if(this.gengxin == 'null' || this.gengxin == undefined){
            this.isSelect = 0
            this.isRed = 0
            localStorage.setItem("nowpage",1)
            this.getData(33)
        }else{
          let tvlmids = localStorage.getItem("tvlmids")
          let tvidx = localStorage.getItem("tvidx")
          let tvid = localStorage.getItem("tvid")
          let idx = localStorage.getItem("tvidx")

          this.getData(this.gengxin)
          // this.pagenow = nowpage
          this.pagenow = localStorage.getItem("nowpage")
          this.isSelect = tvlmids
          this.isRed = tvid
          $('.anlinav button').eq(idx).addClass('curr').siblings().removeClass('curr')
        }
     }
    },
    mounted(){
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'tv'){
          $(".chonggou a[href$='/tv']").attr('class','router-link-active')
        }
      })

      let homeid = this.$route['query']['id'];
      if(homeid != undefined){
        this.lmid = homeid
        this.getData(homeid)
        switch(homeid){
          case '35':
          this.isRed = 2
          break;
          case '36':
          this.isRed = 3
          break;
          case '39':
          this.isRed = 0
          this.isSelect = 2
          break;
          case '42':
          this.isRed = 3
          this.isSelect = 2
          break;
          case '40':
          this.isRed = 1
          this.isSelect = 2
          break;
          case '33':
          this.isRed = 0
          this.isSelect = 0
          break;
          case '34':
          this.isRed = 1
          this.isSelect = 0
          break;
          case '37':
          this.isRed = 4
          this.isSelect = 0
          break;
          case '43':
          this.isRed = 4
          this.isSelect = 2
          break;
          case '38':
          this.isRed = 5
          this.isSelect = 0
          break;
          case '44':
          this.isRed = 5
          this.isSelect = 2
          break;
          case '41':
          this.isRed = 2
          this.isSelect = 2
          break;
          case '45':
          this.isRed = 0
          this.isSelect = 1
          break;
        }
      }else{
        this.isSelect = 0
        this.isRed = 0
        if(this.gengxin ==  ''){
          this.getData(33)
        }


      }


    }
  }
</script>

<style scoped="scoped" lang="scss">
  .isredclass{
    color: #b80816;
  }
  .yangshi{
    .yangshiwrap{
      display: flex;
      justify-content: space-between;
      margin-top: 60px;
      .yangshiwrapr{
        width: 905px;
        .yschild{

          .yschildwrap{
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;
            .yschilditem:nth-child(3n){
              margin-right: 0;
            }
            .yschilditem{
              box-shadow: 0 0 8px #c5c1c1;
              width: 290px;
              background: #fff;
              overflow: hidden;
              margin-bottom: 16px;
              margin-right: 16px;
              h2{
                width: 280px;
                margin: 4px auto 0;
                overflow: hidden;
                img{
                  width: 280px;
                }

              }
              p{
                font-size: 18px;
                margin: 20px 15px;
                line-height: 28px;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                overflow: hidden;
              }
            }
          }
        }
      }
      .yangshiwrapl{
        width: 270px;
        box-sizing: border-box;

        h2{
          font-size: 22px;
          font-weight: bold;
          height: 68px;
          line-height: 68px;
          border: 1px solid #e5e5e5;
          text-align: center;
          border-radius: 8px 8px 0 0;
          border-bottom: none;
        }
        .yangshibox{
          border: 1px solid #e5e5e5;
          border-radius: 0 0 8px 8px;
          .yangshiitem:last-child{
            strong,ul{
              border-bottom: none;
            }

          }
          .yangshiitem ul{
            height: 0;
            overflow: hidden;
          }
          .yangshiitem{
            strong{
              font-weight: bold;
              font-size: 20px;
              color: #666666;
              line-height: 70px;
              height: 70px;
              display: block;
              padding-left: 32px;
              border-bottom: 1px solid #e5e5e5;
              cursor: pointer;
              background: url(../assets/yangshiicon.jpg) no-repeat 230px center;
            }
            ul{
              // padding: 20px 0 20px 32px;
              border-bottom: 1px solid #e5e5e5;
              height: 0;
              overflow: hidden;
              li{
                height: 42px;
                line-height: 42px;
                margin-left: 32px;
                font-size: 18px;
                cursor: pointer;
              }

            }
          }
          .ysactive{
            ul{
              height: 100% !important;
            }
            strong{
              color: #b80816;
              background-image: url(../assets/yangshiicon-s.jpg);
            }
          }
        }
      }
    }
  }
</style>
