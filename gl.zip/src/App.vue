<template>
  <div class="container">
      <!-- 主体开始 -->
      <HeaderView/>
      <router-view/>
      <FooterView/>
      <!-- 主体结束 -->
  </div>

</template>
<script>
import HeaderView  from '@/components/HeaderView'
import FooterView  from '@/components/FooterView'
export default {
  components: {
    HeaderView,
    FooterView
  },
  data(){
    return {

    }
  },
  beforeMount(){

  },
  mounted(){

  },
  watch(){
    
  }
}

</script>
<style lang="scss" scoped="scoped">
@import './assets/css/common.css';
</style>
