<template>
  <div id="app">
    <HeaderView/>
    <router-view></router-view>
    <FooterView/>
  </div>
</template>

<script>
  import HeaderView from './components/HeaderView.vue'
  import FooterView from './components/FooterView.vue'

 var deviceWidth = document.documentElement.clientWidth;
 var dpr=window.devicePixelRatio;
 document.documentElement.setAttribute('data-dpr',dpr );
 if(deviceWidth > 750) deviceWidth = 750;
 document.documentElement.style.fontSize = deviceWidth / 7.5 + 'px';
 window.onresize = function(){
     var deviceWidth = document.documentElement.clientWidth;
     var dpr=window.devicePixelRatio;
     document.documentElement.setAttribute('data-dpr',dpr );
     if(deviceWidth > 750) deviceWidth = 750;
     document.documentElement.style.fontSize = deviceWidth / 7.5 + 'px';
 }
  export default{
    components: {
        HeaderView,
        FooterView
      },
      data(){
        return {

        }
      },
      beforeMount(){

      },
      mounted(){

      },
      watch(){

      }
    }


</script>


<style lang="scss" scoped="scoped">

@import './assets/css/common.css';

</style>
