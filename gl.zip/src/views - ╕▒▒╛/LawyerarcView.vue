<template>
  <div class="yangshiinfo">
    <div class="ban"></div>
    <div class="yangshiinfobox w1200">
      <div class="yangshiinfowrap"  v-loading="loading" :element-loading-text="loadtext">
        <div class="minabao">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

            <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
            <!-- <el-breadcrumb-item>{{arcTitle}}</el-breadcrumb-item> -->
          </el-breadcrumb>
        </div>
        <h2 class="yangshititle">{{arcTitle}}</h2>
        <div class="yangshitype">
          <div>文章来源： 北京冠领律师事务所</div>
          <div>阅读：{{readCount}}</div>
          <div>发布时间： {{createTime}}</div>
          <div>字体： 【<em @click="bigfont('big')">大</em> <em @click="bigfont('cur')">中</em> <em @click="bigfont('lit')">小</em>】</div>
        </div>
        <div class="yangshicontent">
          <div class="vintro">
            <div class="vintrol"><img :src="thumb" ></div>
            <div class="vintror">
              <strong>{{arcTitle}}</strong>
              <div class="vintrobtn"><button>{{zhicheng}}</button></div>
              <p><em>律师简介：</em>{{description}}</p>
              <!-- <p><em>专业领域：</em></p> -->
              <div class="chatbtn"><span>在线咨询</span><span>咨询电话：400-8789-888</span></div>
            </div>
          </div>
          <div class="lawline"><img src="../assets/lawline.jpg" ></div>
          <div v-html="content" class="vhtml lawyerhtml"></div>
          <!-- <div class="biaoqian">标签： 拆迁 民事 拆迁 民事 拆迁 民事 拆迁 民事</div> -->
        </div>
        <div class="prenext" v-if="ispre == 'k'">
          <span>上一篇：没有了</span>
           <router-link :to="{path: '/'+arcpath+'/'+nextArc['id']+'.html'}" :title="nextArc['title']">下一篇：{{nextArc['title']}}</router-link>
        </div>
        <div class="prenext" v-else-if="isnext == 'k'">
          <router-link :to="{path: '/'+arcpath+'/'+preArc['id']+'.html'}" :title="preArc['title']">上一篇：{{preArc['title']}}</router-link>
           <span>下一篇：没有了</span>
        </div>
        <div class="prenext" v-else>
          <router-link :to="{path: '/'+arcpath+'/'+preArc['id']+'.html'}" :title="preArc['title']">上一篇：{{preArc['title']}}</router-link>
          <router-link :to="{path: '/'+arcpath+'/'+nextArc['id']+'.html'}" :title="nextArc['title']">下一篇：{{nextArc['title']}}</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'LawyerarcView',
    data(){
      return {
        breadcrumbList:[],
        currentArcId:1,
        arcTitle:null,
        readCount:0,
        createTime:0,
        content:'',
        nextArc:[],
        preArc:[],
        loadtext: '数据加载中...',
        loading: false,
        arcpath:'',
        ispre:'',
        isnext:'',
        thumb:'',
        description:'',
        zhicheng:'',
        miaoshu:'',
        catid:''
      }
    },
    methods:{

        bigfont(val){
          let yangshiem = $('.yangshitype em')
          let yangshicontent = $('.yangshicontent p')
          let yangshicontentspan = $('.yangshicontent p span')
          yangshiem.css('color','#666666')
          if(val == 'big'){
            yangshiem.eq(0).css('color','#b80816')
            yangshicontent.animate({'font-size':'18px'})
            yangshicontentspan.animate({'font-size':'18px'})
          }
          if(val == 'cur'){
            yangshiem.eq(1).css('color','#b80816')
            yangshicontent.animate({'font-size':'16px'})
            yangshicontentspan.animate({'font-size':'16px'})
          }
          if(val == 'lit'){
            yangshiem.eq(2).css('color','#b80816')
            yangshicontent.animate({'font-size':'14px'})
            yangshicontentspan.animate({'font-size':'14px'})
          }
        },
        // 获取上下篇
        getSX(id,path,catid){
          let that = this
          request({
            url: '/'+path+'/'+path+'next?id='+id+'&catid='+catid,
            responseType: 'json',
            transformResponse:[function(data){
              let jsondata = JSON.parse(data)
              // console.log(jsondata);
              if(jsondata['code'] == 200){
                that.ispre = ''
                that.isnext = ''
                if(jsondata['data']['up'] == null){
                  that.ispre = 'k'
                  that.nextArc = jsondata['data']['down']
                }else if(jsondata['data']['down'] == null){
                  that.isnext = 'k'
                  that.preArc = jsondata['data']['up']
                }else{
                  that.preArc = jsondata['data']['up']
                  that.nextArc = jsondata['data']['down']
                }
              }
            }]
          })
        },
        getArc(){
          let meta = this.$route.meta;
          let that = this
          let arcid = that.$route.params.id.split('.')
          that.currentArcId = arcid[0]
          // alert(that.currentArcId)

          let pathdiy = that.$route.path.split('/')[1]
          that.arcpath = pathdiy
          let sx = ''
          // console.log(pathdiy);
          let sendpath = ''
          switch(pathdiy){
            case 'lawyer':
            sx = 'team'
            sendpath = '/team/teamlist?id='
            break;
          }
          that.loading = true
          that.loadtext = '数据加载中...'
          request({
            url: sendpath+that.currentArcId,
            responseType: 'json',
            transformResponse:[function(data){
              let jsondata = JSON.parse(data)
              // console.log(jsondata);
              if(jsondata['code'] == 200){
                // return jsondata
                // console.log(jsondata['data'])
                let newData = jsondata['data'];

                that.loading = false
                let th = newData['thumb'].split(':')
                let thumblength = th[21].length
                that.thumb = 'http://api.guanlingss.com'+th[21].substr(1,thumblength-4);
                that.loading = false
                that.arcTitle = jsondata['data']['title']
                that.zhicheng = jsondata['data']['zhicheng']
                that.description = jsondata['data']['description']
                that.content= jsondata['data']['content']
                that.miaoshu= jsondata['data']['miaoshu']
                that.catid= jsondata['data']['catid']
                that.getSX(that.currentArcId,sx,that.catid)
              }
            }]
          })
        }
    },
    watch:{
      $route(to, from){
       this.getArc()
      }
    },
    mounted(){
      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }
      this.getArc()

      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'lawyerhtml'){
          $(".chonggou a[href$='/lawyer']").attr('class','router-link-active')
        }
      })
    }
  }
</script>


<style lang="scss" scoped="scoped">

  .prenext{
    display: flex;
    justify-content: space-between;
    font-size: 18px;
    height: 45px;
    align-items: center;
    border-top: 1px dashed #e5e5e5;
    margin: 0 auto;
    width: 1080px;
  }
  .prenext a{
    color: #666666;
    display: block;
    white-space: nowrap;
    width: 45%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .yangshiinfo{
    .ban{
      background-image: url(../assets/shipininfoimg.jpg);
    }
    .yangshiinfobox{
      background: #fff;
      .yangshiinfowrap{
        position: relative;
        width: 100%;
        background: #fff;
        margin-top: -218px;
        z-index: 99;
        box-shadow: 0 0 8px #dfdddd;
        padding-bottom: 30px;
        border: 1px solid transparent;
        .minabao{
          margin: 30px 60px 0;
          padding-bottom: 20px;
        }
        h2.yangshititle{
          text-align: center;
          margin-top: 35px;
          font-size: 20px;
        }
        .yangshitype{
          display: flex;
          border-bottom: 1px dashed #e5e5e5;
          font-size: 16px;
          color: #666666;
          margin: 30px 40px 0;
          padding-bottom: 14px;
          justify-content: center;
          margin-bottom: 26px;
          div:last-child{
            margin-right: 0;
          }
          div{
            margin-right: 50px;
            em{
               cursor: pointer;
               padding: 0 5px;
            }
            em:nth-child(2){
              color: #b80816;
            }
          }
        }

        .yangshicontent{
          margin: 0 60px;
          padding-bottom: 10px;
          .lawline{
            margin-bottom: 45px;
          }
          .vintro{
            display: flex;
            margin-bottom: 45px;
            .vintrol{
              width: 306px;
              height: 378px;
              margin-right: 35px;
              img{
                width: 306px;
              }
            }
            .vintror{
              position: relative;
              strong{
                font-size: 25px;
                font-weight: bold;
                color: #333;
                margin-top: 15px;
                margin-bottom: 15px;
                display: block;
              }
              .vintrobtn{
                margin-bottom: 40px;
                button{
                  border: none;
                  outline: none;
                  background: #e5e5e5;
                  font-size: 18px;
                  color: #666;
                  border-radius: 5px;
                  margin-right: 20px;
                  height: 30px;
                  width: 120px;

                }
              }

              p{
                font-size: 18px;
                line-height: 28px;
                text-indent: 0;
                em{
                  font-weight: bold;
                }
              }
              .chatbtn{
                display: flex;
                margin-top: 40px;
                position: absolute;
                bottom: 30px;
                span{
                  font-size: 18px;
                  color: #b80816;
                  height: 43px;
                  border: 1px solid #b80816;
                  line-height: 43px;
                  cursor: pointer;
                  text-indent: 55px;
                  background-repeat: no-repeat;
                  background-position: 30px center;
                  background-size: 15px 17px;
                  background-color: #fff;
                }
                span:first-child{
                  width: 158px;
                  margin-right: 20px;
                  background-image: url(../assets/lawchat.png);
                }
                span:last-child{
                  width: 298px;
                  background-image: url(../assets/dianhua-r.png);
                }
                span:first-child:hover{
                  background-color: #b80816;
                  color: #fff;
                  background-image: url(../assets/lawchat-s.png);
                }
                span:last-child:hover{
                  background-color: #b80816;
                  color: #fff;
                  background-image: url(../assets/dianhua-s.png);
                }
              }
            }
          }
          span{
            font-size: 16px;
          }
          p{
            font-size: 16px !important;
            color: #666666;
            line-height: 27px;
            text-indent: 2em;
            margin-bottom: 18px;

          }
          .biaoqian{
            padding: 20px 0 25px;
            color: #666;
            font-size: 16px;
          }

        }
      }
    }
  }
</style>
