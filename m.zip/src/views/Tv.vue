<template>
  <div class="tv">
    <div class="comban">
      <img src="../assets/tv.jpg" >
      <div>
        <strong>冠领央视</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="tvwrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>冠领央视</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="tvstyle">
        <div class="tvstylewrap">
          <div class="btnbox">
            <button v-for="item,index in anliLanmu" :key="index" @click="setColor(index,item.cid)" :class="{isactive: index == curr}">{{item.name}}</button>
          </div>
          <div class="tvlist">
            <p v-for="item,index in newLanmu['child']" :key="index" @click="setSel(index,item.id)" :class="{sel: index == ff}">{{item.name}}</p>
          </div>
        </div>
        <div class="tvitembox m20">
          <ul>
          	<li v-for="item,index in vdata" :key="index"><router-link :to="{path:'/tv/'+item.id+'.html'}"><img :src="item.thumb" ></router-link><p>{{item.title}}</p></li>
          </ul>
        </div>
        <div class="page">
          <el-pagination
            background
            hide-on-single-page
            @current-change='compage'
            current-page=1
            layout="prev, pager, next"
            prev-text="上一页"
            next-text="下一页"
            pager-count= 5
            :page-count='lastPage'
            :key='lmid'>
          </el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default {
    name: 'Tv',
    data(){
      return {
        anliLanmu:[],
        newLanmu:[],
        curr:0,
        ff:0,
        vdata:[],
        pageSize:8,
        lmid:0,
        lastPage:0
      }
    },
    methods:{
      setColor(id,cid){
        this.curr = id
        this.newLanmu = this.anliLanmu[id]
        this.ff=0
        this.lmid = cid
        this.getTvData(cid)
      },
      setSel(id,lmid){
        this.ff = id
        this.lmid = lmid
        this.getTvData(lmid)
      },
      getTvData(id){
        let that = this
        that.lmid = id
        request({
           url: '/video/read?id='+that.lmid+'&page=1&page_size='+ that.pageSize,
           responseType: 'json',
           transformResponse:[function(data){
             let jsondata = JSON.parse(data)
             if(jsondata['code'] == 200){
               that.vdata = []
               if(jsondata['data']['total'] == 0){
                 that.loadtext = '没有数据'
                 // that.pageSize = newData['per_page']
                 // that.lastPage = newData['last_page']
               }else{

                 let newData = jsondata['data'];
                 newData['data'].forEach(function(val){
                     that.loading = false
                     let thumb = val['thumb'].split(':')
                     let thumblength = thumb[21].length
                     val['thumb'] = GLOBAL.httpurl+thumb[21].substr(1,thumblength-4);
                     that.vdata.push(val)
                 });
                 // that.pageSize = newData['per_page']
                 that.lastPage = newData['last_page']
               }
             }
           }]
         })
      },
      getLanmu(){
        let that = this
        that.anliLanmu = []
        request({
          url: '/Category/getcatelist?id=7',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)

            if(jsondata['code'] == 200){
             jsondata['data'].forEach(function(val){
                  if(val['child'][0] == undefined){
                      val['cid'] =  val['id'];
                      that.anliLanmu.push(val)
                  }else{
                    val['cid'] =  val['child'][0]['id'];
                    that.anliLanmu.push(val)
                  }
              });
              that.newLanmu = that.anliLanmu[that.curr]
              // that.anliLanmu = jsondata['data']
              // console.log(that.anliLanmu)
            }
          }]
        })
      },
      compage(val){
        let that = this
        request({
           url: '/video/read?id='+that.lmid+'&page='+val+'&page_size='+ that.pageSize,
           responseType: 'json',
           transformResponse:[function(data){
             let jsondata = JSON.parse(data)
             if(jsondata['code'] == 200){
               that.vdata = []
               if(jsondata['data']['total'] == 0){
                 that.loadtext = '没有数据'
                 // that.pageSize = newData['per_page']
                 // that.lastPage = newData['last_page']
               }else{

                 let newData = jsondata['data'];
                 newData['data'].forEach(function(val){
                     that.loading = false
                     let thumb = val['thumb'].split(':')
                     let thumblength = thumb[21].length
                     val['thumb'] = GLOBAL.httpurl+thumb[21].substr(1,thumblength-4);
                     that.vdata.push(val)
                 });
                 // that.pageSize = newData['per_page']
                 that.lastPage = newData['last_page']
               }
             }
           }]
         })
      }
    },
    mounted() {

      this.getLanmu()
      let homeid = this.$route['query']['id'];
      if(homeid != undefined){
        this.lmid = homeid
        this.getTvData(homeid)
        switch(homeid){
          case '35':
          this.ff = 2
          break;
          case '36':
          this.ff = 3
          break;
          case '42':
          this.ff = 3
          this.curr = 2
          break;
          case '34':
          this.ff = 1
          break;
          case '38':
          this.ff = 5
          break;
          case '39':
          this.ff = 0
          this.curr = 2
          break;
          case '41':
          this.ff = 2
          this.curr = 2
          break;
        }
      }else{
        this.getTvData(33)
      }
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'tv'){
          $(".chonggou a[href$='/tv']").attr('class','router-link-active')
        }
      })



      let btnbox = $('.btnbox button')
      btnbox.click(function(){
        $(this).addClass('curr').siblings().removeClass('curr')
        $('.tvlist').hide(0,function(){
          $('.tvlist').fadeIn()
        })
        tvp.removeClass('sel')
        tvp.eq(0).addClass('sel')
      })

      let tvp = $('.tvlist p')
      tvp.click(function(){
        $(this).addClass('sel').siblings().removeClass('sel')
      })
    }
  }
</script>

<style lang="scss" scoped="scoped">

  .tv{
    .tvwrap{
      .tvstyle{
        .tvstylewrap{
          padding: 0 .2rem .1rem;
          border-bottom: .2rem solid #f3f3f3;
        }
        .tvitembox{
          margin-top: .34rem;
          ul{
            display: flex;
            justify-content:  flex-start;
            flex-wrap: wrap;
            margin: 0 .1rem;
            li:nth-child(odd){
              margin-right: .16rem;
            }
            li{
              width: 3.37rem;
              margin-bottom: .22rem;
              p{
                font-size: .24rem;
                line-height: .36rem;
                padding: 0 .15rem;
                margin-top: .1rem;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                overflow: hidden;
              }
            }
          }
        }
        .btnbox{
          display: flex;
          justify-content: space-between;
          margin-top: .25rem;
          button{
            font-size: .24rem;
            color: #333;
            height: .5rem;
            width: 2.24rem;
            background: #eeeeee;
            cursor: pointer;
            position: relative;
          }
          button.isactive{
            background: #b80816;
            color: #fff;
          }
          button.isactive::after{
            content: "";
            width: .24rem;
            height: .24rem;
            background: #b80816;
            position: absolute;
            bottom: -.13rem;
            left: 50%;
            margin-left: -.12rem;
            transform: rotate(45deg);
            z-index: -1;
          }
        }
        .tvlist{
          display: flex;
          flex-wrap: wrap;
          justify-content: space-between;
          margin-top: .22rem;
          p{
            width: 3.45rem;
            height: .5rem;
            border-radius: 1.725rem;
            border: 1px solid #d2d2d2;
            box-sizing: border-box;
            text-align: center;
            margin-bottom: .2rem;
            cursor: pointer;
            font-size: .22rem;
            color: #999999;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          p.sel{
            color: #bd1826;
            border: 1px solid #bd1826;
          }
        }
      }
    }
  }
</style>
