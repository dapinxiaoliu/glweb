<template>
  <div class="honor">
    <div class="comban">
      <img src="../assets/honor.jpg" >
      <div>
        <strong>冠领荣誉</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="honorwrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>冠领荣誉</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="honorbox">
        <div class="honorbtn m20">
          <button class="f" @click="jinqi(24)">锦旗荣誉</button>
          <button @click="jiangbei(25)">奖杯荣誉</button>
          <button @click="haoping(149)">好评荣誉</button>
        </div>
        <div class="honorlist">
          <div class="itemjq comitem">
            <ul class="m20">
            	<li v-for="item,index in jinqiData" :key="index"><router-link :to="{path:'/honor/'+item.id+'.html'}"><img :src=item.thumb ><p>{{item.title}}{{jinqilastPage}}</p></router-link></li>
            </ul>
            <div class="page">
              <el-pagination
                background
                @current-change='jinqiPage'
                current-page=1
                layout="prev, pager, next"
                prev-text="上一页"
                next-text="下一页"
                pager-count= 5
                :page-count=jinqiCount
                :key=lmid>
              </el-pagination>
            </div>
          </div>
          <div class="itemjb comitem">
            <ul class="m20">
            	<li v-for="item,index in jiangbeiData" :key="index"><router-link :to="{path:'/honor/'+item.id+'.html'}"><img :src=item.thumb ><p>{{item.title}}{{jinqiTotal}}</p></router-link></li>
            </ul>
            <div class="page">
              <el-pagination
                background
                 hide-on-single-page
                @current-change='jinqiPage'
                current-page=1
                layout="prev, pager, next"
                prev-text="上一页"
                next-text="下一页"
                pager-count= 5
                :page-count=jiangbeiCount
                :key=lmid>
              </el-pagination>
            </div>
          </div>
          <div class="itemhp comitem">
            <ul class="m20">
            	<li v-for="item,index in haopingData" :key="index"><router-link :to="{path:'/honor/'+item.id+'.html'}"><img :src=item.thumb ></router-link></li>
            </ul>
            <div class="page">
              <el-pagination
                background
                hide-on-single-page
                @current-change='jinqiPage'
                current-page=1
                layout="prev, pager, next"
                prev-text="上一页"
                next-text="下一页"
                page-count = 5
                pager-count= 5
                page-sizes = 2
                :total='haopingCount'
                :key='lmid'>
              </el-pagination>
            </div>
          </div>

        </div>

      </div>
    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default{
    name: 'Honor',
    data(){
      return {
        jinqiData:[],
        jiangbeiData:[],
        haopingData:[],
        fenye:8,
        jinqiCount:null,
        jiangbeiCount:null,
        haopingCount:null,
        lmid:0
      }
    },
    methods:{
      jinqi(id){
        this.getjinqiData(id)
      },
      jiangbei(id){
        this.getjinqiData(id,10)
      },
      haoping(id){
        this.getjinqiData(id)
      },
      getjinqiData(lmid,pagesize=8){
        let that = this
        that.lmid = lmid
        that.fenye = pagesize

        request({
          url: '/honor/read?id='+lmid+'&page=1&page_size='+pagesize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.jinqiData = []
              that.jiangbeiData = []
              that.haopingData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[21].length
                  val['thumb'] = 'http://api.guanlingms.com'+thumb[21].substr(1,thumblength-4);
                  if(lmid == 24){
                    that.jinqiData.push(val)
                  }else if(lmid == 25){
                    that.jiangbeiData.push(val)
                  }else{
                    that.haopingData.push(val)
                  }
              });
              if(lmid == 24){
                that.jinqiCount = newData['last_page']
              }else if(lmid == 25){
                that.jiangbeiCount = newData['last_page']
              }else{
                that.haopingCount = newData['last_page']
              }
            }
          }]
        })
      },
      jinqiPage(val){
        let that = this
        request({
          url: '/honor/read?id='+that.lmid+'&page='+val+'&page_size='+that.fenye,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.jinqiData = []
              that.jiangbeiData = []
              that.haopingData = []
              let newData = jsondata['data'];
              newData['data'].forEach(function(val){
                  that.loading = false
                  let thumb = val['thumb'].split(':')
                  let thumblength = thumb[21].length
                  val['thumb'] = 'http://api.guanlingms.com'+thumb[21].substr(1,thumblength-4);
                  if(that.lmid == 24){
                    that.jinqiData.push(val)
                  }else if(that.lmid == 25){
                    that.jiangbeiData.push(val)
                  }
              });
              if(that.lmid == 24){
                that.jinqiCount = newData['last_page']
              }else if(that.lmid == 25){
                that.jiangbeiCount = newData['last_page']
              }
            }
          }]
        })
      }
    },
    mounted() {
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'honor'){
          $(".chonggou a[href$='/honor']").attr('class','router-link-active')
        }
      })

      let honorbtn = $('.honorbtn button')
      let comitem = $('.honorlist .comitem')
      honorbtn.click(function(){
        let index = $(this).index()
        $(this).addClass('f').siblings().removeClass('f')
        comitem.eq(index).fadeIn().siblings().hide()
      })
      this.getjinqiData(24)
    }
  }
</script>

<style lang="scss" scoped="scoped">

  .honor{
    .f{
      background: #b80816 !important;
      color: #fff !important;
    }
    .comban{
      div{
        color: #333;
      }
    }
    .honorwrap{
      .honorbtn{
        margin-top: .25rem;
        margin-bottom: .3rem;
        display: flex;
        justify-content: space-between;
        button{
          font-size: .28rem;
          height: .58rem;
          width: 2.24rem;
          text-align: center;
          line-height: .58rem;
          color: #666666;
          background: #eeeeee;
          cursor: pointer;
        }
      }
      .honorlist{
        .comitem{
          display: none;
        }
        .comitem:first-child{
          display: block;
        }
        .itemjq{

          ul{
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            li{
              width: 3.45rem;
              img{
                width: 3.45rem;
                height: 5.12rem;
              }
              a{
                p{
                  font-size: .28rem;
                  color: #666;
                  line-height: 100%;
                  text-align: center;
                  margin-top: .2rem;
                  margin-bottom: .35rem;
                  white-space: nowrap;
                  overflow: hidden;
                  text-overflow: ellipsis;
                }
              }
            }
          }

        }
        .itemjb{
          ul{
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            li{
              width: 3.45rem;
              img{
                width: 3.45rem;
                height: 2.31rem;
              }
              a{
                p{
                  font-size: .24rem;
                  color: #666;
                  line-height: .36rem;
                  text-align: center;
                  margin-top: .1rem;
                  margin-bottom: .2rem;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 3;
                  overflow: hidden;
                  text-align: left;
                }
              }
            }
          }


        }
        .itemhp{
          ul{
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            li{
              width: 3.45rem;
              border: 1px solid #c2c2c2;
              margin-bottom: .3rem;
            }
          }


        }
      }
    }
  }
</style>
