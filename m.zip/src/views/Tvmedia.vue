<template>
  <div class="tvmedia">
    <div class="comban">
      <img src="../assets/tv.jpg" >
      <div>
        <strong>冠领央视</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="tvmediawrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>

        </el-breadcrumb>
      </div>
      <div class="tvcontent">
        <h2>{{title}}</h2>
        <div class="intro m20"><span>来源：北京冠领律师事务所</span><span>阅读：{{count}}</span><span>发布时间：{{createTime}}</span></div>
        <div class="tvhtml">
          <p class="tvshipin">
            <video :src="Vurl" controls="controls" ></video>
          </p>
        </div>
        <!-- <div class="biaoqian m20">标签：<span>标签1</span><span>标签2</span><span>标签3</span></div> -->
        <div class="prenext m20" v-if="ispre == 'k'">
          <span>上一篇：没有了</span>
           <router-link :to="{path: '/tv/'+nextArc['id']+'.html'}" :title="nextArc['title']">下一篇：{{nextArc['title']}}</router-link>
        </div>
        <div class="prenext m20" v-else-if="isnext == 'k'">
          <router-link :to="{path: '/tv/'+preArc['id']+'.html'}" :title="preArc['title']">上一篇：{{preArc['title']}}</router-link>
           <span>下一篇：没有了</span>
        </div>
        <div class="prenext m20" v-else>
          <router-link :to="{path: '/tv/'+preArc['id']+'.html'}" :title="preArc['title']">上一篇：{{preArc['title']}}</router-link>
           <router-link :to="{path: '/tv/'+nextArc['id']+'.html'}" :title="nextArc['title']">下一篇：{{nextArc['title']}}</router-link>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default {
    name:'Tvmedia',
    data(){
      return {
        breadcrumbList:[],
        Vurl:'',
        title:'',
        count:0,
        createTime:'',
        currentArcId:0,
        nextArc:[],
        preArc:[],
        arcpath:'',
        ispre:'',
        isnext:'',
        catid:0
      }
    },
    methods:{
      getVData(){
        let that = this
        let arcid = that.$route.params.id.split('.')
        that.currentArcId = arcid[0]

        request({
          url: 'video/videolist?id='+ that.currentArcId,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            console.log(jsondata);
            if(jsondata['code'] == 200){
              // console.log(that.lawyerData);
              that.Vurl = jsondata['data']['video_url']
              that.title = jsondata['data']['title']
              that.count = jsondata['data']['count']
              that.catid = jsondata['data']['catid']
              that.createTime = jsondata['data']['create_time'].split(' ')[0]
              that.getSX(that.currentArcId)
            }
          }]
        })
      },
      getSX(id){
        let that = this
        request({
          url: 'video/videonext?id='+id+'&catid='+that.catid,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.ispre = ''
              that.isnext = ''
              if(jsondata['data']['up'] == null){
                that.ispre = 'k'
                that.nextArc = jsondata['data']['down']
              }else if(jsondata['data']['down'] == null){
                that.isnext = 'k'
                that.preArc = jsondata['data']['up']
              }else{
                that.preArc = jsondata['data']['up']
                that.nextArc = jsondata['data']['down']
              }
            }
          }]
        })
      }
    },
    watch:{
      $route(to, from){
       this.getVData()
      }
    },
    mounted() {
      this.getVData()
      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'tvmedia'){
          $(".chonggou a[href$='/tv']").attr('class','router-link-active')
        }
      })
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .tvmedia{
    .tvmediawrap{
      .tvcontent{
        h2{
          font-size: .32rem;
          color: #333;
          width: 6.35rem;
          margin: .3rem auto .2rem;
          text-align: center;
          line-height: .46rem;
        }
        .intro{
          font-size: .26rem;
          color: #999;
          text-align: center;
          display: flex;
          justify-content: center;
          span{
            margin: 0 .06rem;
            white-space: nowrap;
            letter-spacing: -.01rem;
          }
        }
        .tvhtml{
          margin: 0 .2rem .2rem;
          .tvshipin{
            width: 6.92rem;
            margin: .4rem auto .2rem;
            text-indent: 0;
            video{
              width: 6.92rem;
            }
          }
          p{
            font-size: .24rem;
            line-height: .45rem;
            text-indent: 2em;
          }
        }
        .biaoqian{
          font-size: .26rem;
          color: #999999;
          span:last-child::after{
            background: transparent;
          }
          span{
            margin-right: .2rem;
            position: relative;
          }
          span::after{
            content: "";
            width: .02rem;
            height: .24rem;
            background: #999;
            position: absolute;
            top: .06rem;
            right: -.1rem;
          }
        }
        .prenext{
          margin-top: .25rem;
          margin-bottom: .4rem;
          a{
            display: block;
            font-size: .26rem;
            color: #999;
            margin-bottom: .25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          a:hover{
            color: #b80816;
          }
        }
      }
    }
  }
</style>
