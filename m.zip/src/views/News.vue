<template>
  <div class="news">
    <div class="comban">
      <img src="../assets/newsban.jpg" >
      <div>
        <strong>新闻动态</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="newswrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>新闻动态</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="newsbtn">
        <button @click="getnewsData(29)">冠领总部新闻</button>
        <button @click="getnewsData(50)">冠领机构新闻</button>
        <button @click="getnewsData(64)">普法资讯</button>
      </div>
      <div class="newsbox m20">
        <div class="newslist">
          <ul>
          	<li v-for="item,index in newsData" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">
              <div class="newsleft"><img :src="item.thumb" ></div>
              <div class="newsright">
                <p><span class='diyu'>上海</span>{{item.title}}</p>
                <div><span>{{item.create_time}}</span><span>{{item.count}}</span></div>
              </div>
            </router-link></li>
          </ul>
          <ul>
          	<li v-for="item,index in newsData" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">
              <!-- <div class="newsleft"><img :src="item.thumb" ></div> -->
              <div class="newsright">
                <p><span class='diyu'>上海</span>{{item.title}}</p>
                <div><span>{{item.create_time}}</span><span>{{item.count}}</span></div>
              </div>
            </router-link></li>
          </ul>
          <ul>
          	<li v-for="item,index in newsData" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">
              <!-- <div class="newsleft"><img :src="item.thumb" ></div> -->
              <div class="newsright">
                <p>{{item.title}}</p>
                <div><span>{{item.create_time}}</span><span>{{item.count}}</span></div>
              </div>
            </router-link></li>
          </ul>
        </div>
        <div class="page">
          <el-pagination
            background
            hide-on-single-page
            @current-change='compage'
            current-page=1
            layout="prev, pager, next"
            prev-text="上一页"
            next-text="下一页"
            pager-count= 5
            :page-count='totalNum'
            :key='lmid'>
          </el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default{
    name:'News',
    data(){
      return {
        newsData:[],
        pageSize:10,
        totalNum:0,
        lmid:0,
        index:0
      }
    },
    methods:{
      getnewsData(id){
        this.getNewsData(id)
      },
      getNewsData(id){
        let that = this
        that.lmid = id
        request({
          url: '/news/read?id='+id+'&page=1&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
               that.newsData = []
               that.totalNum = ''
              let newdata = jsondata['data']['data']
              // console.log(newdata)
              newdata.forEach(function(val){
                  let thumb = val['thumb'].split(':')

                  let thumblength = thumb[17].length
                  val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                  val['create_time'] = val['create_time'].split(' ')[0]
                  that.newsData.push(val);
              });
              // console.log(jsondata['data']);
              that.totalNum = jsondata['data']['last_page']
            }
          }]
        })
      },
      compage(val){
        let that = this
        // console.log(val);
        request({
          url: '/news/read?id='+that.lmid+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
               that.newsData = []
               that.totalNum = 0
              let newdata = jsondata['data']['data']
              // console.log(newdata)
              newdata.forEach(function(val){
                  let thumb = val['thumb'].split(':')
                  if(thumb.length > 10){
                    let thumblength = thumb[17].length
                    val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                  }
                  val['create_time'] = val['create_time'].split(' ')[0]
                  that.newsData.push(val);
              });
              // console.log(jsondata['data']);
              that.totalNum = jsondata['data']['last_page']
            }
          }]
        })
      }
    },
    watch:{

    },
    mounted() {

      // 获取数据

      let homeid = this.$route['query']['id'];
      if(homeid != undefined){
        this.getNewsData(homeid)
        switch(homeid){
          case '50':
          this.index = 1
          $('.newslist ul').eq(this.index).fadeIn().siblings().hide()
          break;
        }
      }else{
        this.getNewsData(29)
      }

      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'newslist'){
          $(".chonggou a[href$='/newslist']").attr('class','router-link-active')
        }
      })

      let newsbtn = $('.newsbtn button')
      let newslist = $('.newslist ul')
      newsbtn.eq(this.index).addClass('f')
      newsbtn.click(function(){
        let idx = $(this).index()
        this.index = idx
        newsbtn.eq(this.index).addClass('f').siblings().removeClass('f')
        newslist.eq(this.index).fadeIn().siblings().hide()
      })






    }
  }
</script>

<style lang="scss" scoped="scoped">
  .comban div{
      color: #333 !important;
  }
  .news{
    .newswrap{
      border-top: .2rem solid #f3f3f3;
      .newsbtn{
        display: flex;
        justify-content: space-between;
        margin: .25rem .2rem;
        button{
          width: 2.22rem;
          height: .58rem;
          background: #eeeeee;
          font-size: .28rem;
          cursor:pointer;
          color: #333;
          white-space: nowrap;
        }
        button.f{
          color: #fff;
          background-color: #b80816;
        }
      }
      .newsbox{
        .newslist{
          margin-bottom: .3rem;
          ul:nth-child(n+2){
            li:first-child{
               border-top: 1px solid #dddddd;
            }
            li{
              overflow: hidden;
              position: relative;
              height: 1.54rem;
              border-bottom: 1px dashed #dddddd;
              margin-bottom: 0;
              .newsright{
                width: 100%;
                p{
                  margin-top: .15rem;
                  span{
                    display: inline-block;
                    width: .7rem;
                    color: #999;
                    position: relative;
                  }
                  span::after{
                    content: '';
                    position: absolute;
                    width: .02rem;
                    height: .26rem;
                    background-color: #333;
                    right: .05rem;
                    top: .06rem;
                  }
                }

              }
            }
          }
          ul:first-child{
            display: block;
          }
          ul{
            display: none;
            li{
              margin-bottom: .2rem;
              position: relative;
              a{
                display: flex;
                justify-content: space-between;
                // position: relative;
                .newsleft{
                  width: 1.8rem;
                }
                .newsright{
                  width: 5.1rem;
                  div{
                    position: absolute;
                    bottom: .12rem;
                    span{
                      font-size: .26rem;
                      color: #999;
                      background-repeat: no-repeat;
                      background-position: left center;
                      display: inline-block;
                      text-indent: .28rem;
                    }
                    span:first-child{
                      background-image: url(../assets/riqi.png);
                      background-size: .19rem;
                      margin-right: .65rem;
                    }
                    span:last-child{
                      background-image: url(../assets/yan.png);
                      background-size: .2rem .16rem;
                    }
                  }
                  p{
                    font-size: .28rem;
                    line-height: .36rem;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-box-orient: vertical;
                    -webkit-line-clamp: 2;
                    overflow: hidden;
                    margin-top: .05rem;
                    span{
                      display: none;
                    }
                  }
                }
              }
            }

          }
        }
      }
    }
  }
</style>
