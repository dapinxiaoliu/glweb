<template>
  <div class="footer">
    <div class="fnav w1200 chonggou">
      <ul>
      	<li><router-link to="/">首页</router-link></li>
      	<li><router-link to="/yewu">全球业务</router-link></li>
      	<li><router-link to="/branch">冠领机构</router-link></li>
      	<li><router-link to="/tv">冠领在央视</router-link></li>
      	<li><router-link to="/case">胜诉案例</router-link></li>
      	<li><router-link to="/newslist">冠领新闻</router-link></li>
      	<li><router-link to="/lawyer">律师团队</router-link></li>
      	<li><router-link to="/notice">冠领公告</router-link></li>
      	<li><router-link to="/honor">冠领荣誉</router-link></li>
      	<li><router-link to="/about/1497.html">关于我们</router-link></li>
      </ul>
    </div>
    <div class="fwrap w1200">
      <div class="fwrapl">
        <h2>北京冠领律师事务所</h2>
        <ol>
          <li><strong>全球咨询热线：</strong>400-8789-888</li>
          <li><strong>办案监督电话：</strong>010-51077632</li>
          <li><strong>邮     编：</strong>100052</li>
          <li><strong>邮     箱：</strong>69576000@qq.com</li>
          <li><strong>地     址：</strong>北京市西城区宣武门外大街庄胜广场中央办公楼5层、6层、15层、13层1309-1312</li>
        </ol>
      </div>
      <div class="fwrapr">
        <div class="fwraprtop">
          <div class="ftel"><strong>400-8789-888</strong><small>全球咨询热线（7*24）</small></div>
          <div class="fchat"><img src="@/assets/chatimg.jpg" ><p>官方微信</p></div>
        </div>
        <div class="links">
          <ol>
            <li><router-link to="">友情链接</router-link></li>
            <li><router-link to="">友情链接</router-link></li>
            <li><router-link to="">友情链接</router-link></li>
            <li><router-link to="">友情链接</router-link></li>
            <li><router-link to="">友情链接</router-link></li>
            <li><router-link to="">友情链接</router-link></li>
            <li><router-link to="">友情链接</router-link></li>
            <li><router-link to="">友情链接</router-link></li>
          </ol>
        </div>
      </div>
    </div>
    <div class="beian w1200">
      <p>《中华人民共和国电信与信息服务业务经营许可证》北京冠领律师事务所拆迁官网@版权所有 京ICP备14040642号-1</p>
      <p>免责声明：网站部分图片源于网络，如有侵权请联系删除。     网站版权所有，禁止仿建站。</p>
    </div>

  </div>
</template>

<script>
  export default{
    name: "FooterView",
    data(){
      return {}
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .footer{
    height: 434px;
    background-color: #fff;
    .fnav{
      height: 72px;
      border-bottom: 1px solid #dfdfdf;
      ul{
        display: flex;
        justify-content: space-between;
        padding-top: 40px;
        li{
          a{
            font-size: 16px;
            color: #666666;
          }
          a.router-link-active{
            color: #b80816;
          }
        }
      }
    }
    .fwrap{
       border-bottom: 1px solid #dfdfdf;
       padding-bottom: 15px;
      display: flex;
      justify-content: space-between;
      .fwrapl{
        flex: 1;
        color: #666666;
        h2{
          font-size: 28px;
          margin-top: 30px;
          margin-bottom: 30px;
        }
        li{
          font-size: 14px;
          line-height: 100%;
          margin-bottom: 18px;
          strong{
            font-weight: bold;
          }
        }
      }
      .fwrapr{
        .fwraprtop{
          display: flex;
          justify-content: flex-end;
          margin-top: 70px;
          .ftel{
            text-align: right;
            margin-top: 23px;
            margin-right: 63px;
            strong{
              font-size: 25px;
              color: #b80816;
              font-weight: bold;
              display: block;
            }
          }
          .fchat{
            text-align: center;
            margin-right: 2px;
            p{
              margin-top: 5px;
            }
          }
        }
      }
      .links{
        display: none;
        margin-top: 36px;
        ol{
            display: flex;
            li{
              margin-left: 16px;
              a{
                color: #808080;
              }
            }
        }

      }
    }
    .beian{
      font-size: 14px;
      color: #808080;
      text-align: center;
      padding-top: 25px;
      p{
        line-height: 100%;
        margin-bottom: 10px;
      }
    }
  }
</style>
