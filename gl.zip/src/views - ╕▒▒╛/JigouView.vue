<template>
  <div class="jigou">
    <div class="linebanbox">
      <img src="../assets/jg-line.jpg" class="autoc">
      <div class="linebanhead">
        <strong>冠领机构</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="jigouwrap w1200">
      <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;冠领机构</div>
      <div class="jigoumap">
        <img src="../assets/jigoumap_01.jpg" >
        <img src="../assets/jigoumap_02.jpg" >
        <img src="../assets/jigoumap_03.jpg" >
        <div class="jigoubox">
          <ul>
            <li>
              <div class="showinfo"><strong>北京冠领</strong>地址：北京市西城区宣武门外大街10号庄胜广场中央办公楼5层、6层、15层</div>
              <div class="yuan"><em></em></div>
            </li>
            <li>
              <div class="showinfo"><strong>西安冠领</strong>地址：陕西省西安市雁塔区雁翔路旺座曲江K座1804室</div>
              <div class="yuan"><em></em></div>
            </li>
            <li>
              <div class="showinfo"><strong>上海冠领</strong>地址：上海市黄浦区人民路300号外滩SOHO广场D幢</div>
              <div class="yuan"><em></em></div>
            </li>
            <li>
              <div class="showinfo"><strong>深圳冠领</strong>地址：广东省深圳市福田区益田路5033号平安金融中心104层10401单元</div>
              <div class="yuan"><em></em></div>
            </li>
            <li>
              <div class="showinfo"><strong>昆明冠领</strong>地址：云南省昆明市西山区广福路与前卫西路十一家具大厦八楼D座1-7号办公室</div>
              <div class="yuan"><em></em></div>
            </li>
          </ul>
        </div>
      </div>
      <div class="jigoulist">
        <ul>
        	<li>
            <router-link :to="{path: '/branch/beijing'+'.html'}">
            <div class="jigoufengmian"><img src="../assets/bjgl.jpg" ></div>
            <div class="jigouiteminfo">
              <strong><router-link to="">北京冠领</router-link></strong>
              <p>北京市西城区宣武门外大街10号庄胜广场中央办公楼5层、6层、15层</p>
              <p>400-8789-888(24小时)</p>
            </div>
            </router-link>
          </li>
          <li>
            <router-link :to="{path: '/branch/shanghai'+'.html'}">
            <div class="jigoufengmian"><img src="../assets/shanghai.jpg" ></div>
            <div class="jigouiteminfo">
              <strong><router-link to="">上海冠领</router-link></strong>
              <p>上海市黄浦区人民路300号外滩SOHO广场D幢</p>
              <p>400-8789-888(24小时)</p>
            </div>
            </router-link>
          </li>
          <li>
            <router-link :to="{path: '/branch/shenzhen'+'.html'}">
            <div class="jigoufengmian"><img src="../assets/shenzhen.jpg" ></div>
            <div class="jigouiteminfo">
              <strong><router-link to="">深圳冠领</router-link></strong>
              <p>广东省深圳市福田区益田路5033号平安金融中心104层10401单元</p>
              <p>400-8789-888(24小时)</p>
            </div>
            </router-link>
          </li>
          <li>
           <router-link :to="{path: '/branch/xian'+'.html'}">
           <div class="jigoufengmian"><img src="../assets/xian.jpg" ></div>
           <div class="jigouiteminfo">
             <strong><router-link to="">西安冠领</router-link></strong>
             <p>陕西省西安市雁塔区雁翔路旺座曲江K座1804室</p>
             <p>400-8789-888(24小时)</p>
           </div>
           </router-link>
          </li>
          <li>
            <router-link :to="{path: '/branch/kunming'+'.html'}">
            <div class="jigoufengmian"><img src="../assets/kunming.jpg" ></div>
            <div class="jigouiteminfo">
              <strong><router-link to="">昆明冠领</router-link></strong>
              <p>云南省昆明市西山区广福路与前卫西路十一家具大厦八楼D座1-7号办公室</p>
              <p>400-8789-888(24小时)</p>
            </div>
            </router-link>
          </li>
          <li></li>
        </ul>
      </div>
    </div>
     <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'

  export default{
    name: 'JigouView',
    data(){
      return{


      }
    },
    methods:{

    },
    mounted(){
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'branch'){
          $(".chonggou a[href$='/branch']").attr('class','router-link-active')
        }
      })
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .jigoumap{
    position: relative;
    @keyframes starshan {
      0%{
        transform: scale(1);
      }
      50%{
        transform: scale(1.2);
      }
      100%{
        transform: scale(1);
      }
    }
    @keyframes starborder {
      0%{
        box-shadow: 0 0 0px #fff;
      }
      50%{
        box-shadow: 0 0 6px 3px #fff;
      }
      100%{
        box-shadow: 0 0 0px #fff;
      }
    }
    .jigoubox{
      ul{
        li:hover{
          .showinfo{
            display: block;
          }
        }
        li{

          position: absolute;
          cursor: pointer;
          .showinfo{
            background: #fff;
            padding: 15px 20px;
            border-radius: 8px;
            width: 295px;
            box-shadow: 0 0 8px 3px #ccc;
            display: none;
            position: absolute;
            top: -116%;
            left: 50%;
            margin-left: -178px;
            font-size: 16px;
            strong{
              display: block;
              margin-bottom: 10px;
              font-weight: bold;
            }
          }
          .yuan{
            width: 63px;
            height: 54px;
            position: relative;
            // border: 1px solid #fff;
            em{
              display: block;
              width:7px;
              height: 7px;
              background: #fff;
              border-radius: 50%;
              margin-top: 40px;
              margin-left: 30px;
              transform-origin: center;
              position: relative;
              animation: starshan 3s linear 0s infinite;
            }
            em::after{
              content: "";
              width: 13px;
              height: 13px;
              background: transparent;
              border-radius: 50%;
              position: absolute;
              border: 1px solid #fff;
              left: -3px;
              top: -3px;
              box-sizing: border-box;
              animation: starborder 3s linear 0s infinite;
            }
          }
        }

        li:nth-child(1){
          left: 652px;
          top: 154px;
        }
        li:nth-child(2){
           left: 595px;
           top: 206px;
        }
        li:nth-child(3){
          left: 650px;
          top: 282px;
          .showinfo{
            top: -193%;
          }
          .yuan{
            width: 105px;
            height: 39px;
            em{
              margin-left: 85px;
              margin-top: 15px;
            }
          }
        }
        li:nth-child(4){
          left: 641px;
          top: 371px;
        }
        li:nth-child(5){
           left: 503px;
           top: 344px;
        }
      }
    }
  }
  .jigou{
    .jgban{
      position: relative;
      min-width: 1200px;

      strong,small{
        position: absolute;
        top: 0;
        width: 100%;
        color: #fff;
        text-align: center;
        line-height: 100%;
      }
      strong{
        font-size: 62px;
        top: 94px;
      }
      small{
        font-size: 20px;
        top: 180px;
      }
    }
    .jigouwrap{
      .jigoumap{
        margin-top: 50px;
      }
      .jigoulist{
        margin-top: 60px;
        ul{
          display: flex;
          flex-wrap: wrap;
          justify-content: space-between;
          li:hover img{
            transform: scale(1.1);
          }
          li:nth-child(n+4){
            margin-top: 40px;
          }
          li:hover{
            a{
              color: #333 !important;
            }
          }
          li{
            width: 380px;
            cursor: pointer;

            .jigoufengmian{
              overflow: hidden;
              img{
                transition: all .3s linear 0s;
              }
            }
            .jigouiteminfo{
              padding: 0 24px;
              border: 1px solid #dcdcdc;
              border-top: transparent;
              box-sizing: border-box;
              overflow: hidden;
              padding-bottom: 10px;
              strong{
                font-weight: bold;
                display: block;
                color: #333333;
                text-align: center;
                font-size: 20px;
                line-height: 100%;
                margin-top: 30px;
                margin-bottom: 16px;
              }
              p{
                line-height: 28px;
                margin-bottom: 5px;
                background-position: left 5px;
                background-repeat: no-repeat;
                padding-left: 30px;
                display: flex;
                align-items: center;
              }
              p:nth-of-type(1){
                background-image: url(../assets/mapicon.jpg);
              }
              p:nth-of-type(2){
                background-image: url(../assets/telicon.jpg);
              }
            }
          }
        }
      }
    }
  }
</style>
