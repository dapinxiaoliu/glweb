<template>
<div class="home">
 <!-- banner -->
    <div class="banner">
      <div class="banbox">
        <ul>
          <li v-for="item,index in bannerData" :key="index"><router-link :to="{path:item.url}" ><img :src="item.thumb" ></router-link></li>
        </ul>
      </div>
      <div class="baside w1200">
        <ol>
        	<li v-for="item,index in bannerData" :key="index"  @click="setColor(index)" :class="{banact: index == keys}">
            <router-link :to="{path:item.url}"><b>{{item.name}}</b></router-link>
          </li>
        </ol>
      </div>
    </div>
    <!-- 业务分类 -->
    <div class="yewu w1200">
      <ul>
      	<li>
          <router-link to='/yewu/minshi.html'>
            <div><img src="../assets/yw01.png" class="ywshow"><img src="../assets/yw1.png" class="ywhide"></div>
            <b>民事诉讼</b>
          </router-link>

        </li>
        <li>
           <router-link to='/yewu/xingzheng.html'>
          <div><img src="../assets/yw02.png" class="ywshow"><img src="../assets/yw2.png" class="ywhide"></div>
          <b>行政诉讼</b>
          </router-link>
        </li>
        <li>
           <router-link to='/yewu/gongsi.html'>
          <div><img src="../assets/yw03.png" class="ywshow"><img src="../assets/yw3.png" class="ywhide"></div>
          <b>公司业务</b>
          </router-link>
        </li>
        <li>
           <router-link to='/yewu/xingshi.html'>
          <div><img src="../assets/yw04.png" class="ywshow"><img src="../assets/yw4.png" class="ywhide"></div>
          <b>刑事诉讼</b>
          </router-link>
        </li>
        <li>
           <router-link to='/yewu/zhishi.html'>
          <div><img src="../assets/yw05.png" class="ywshow"><img src="../assets/yw5.png" class="ywhide"></div>
          <b>知识产权诉讼</b>
          </router-link>
        </li>
        <li>
           <router-link to='/yewu/jiaotong.html'>
          <div><img src="../assets/yw06.png" class="ywshow"><img src="../assets/yw6.png" class="ywhide"></div>
          <b>交通事故诉讼</b>
          </router-link>
        </li>
        <li>
           <router-link to='/yewu/shewai.html'>
          <div><img src="../assets/yw07.png" class="ywshow"><img src="../assets/yw7.png" class="ywhide"></div>
          <b>涉外业务</b>
          </router-link>
        </li>
        <li>
           <router-link to='/yewu/zhaobiao.html'>
          <div><img src="../assets/yw08.png" class="ywshow"><img src="../assets/yw8.png" class="ywhide"></div>
          <b>招投标业务</b>
          </router-link>
        </li>
        <li>
           <router-link to='/yewu/shangshi.html'>
          <div><img src="../assets/yw09.png" class="ywshow"><img src="../assets/yw9.png" class="ywhide"></div>
          <b>商事业务</b>
          </router-link>
        </li>
      </ul>
    </div>
    <!-- 新闻视频媒体 -->
    <div class="newsbox w1200">
      <div class="news">
        <h2>冠领总部新闻<router-link to="/newslist">更多 ></router-link></h2>
        <ul>
        	<li v-for="item,index in newsData" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">
            <div class="litpic"><img :src="item.thumb" ></div>
            <p>{{item.title}}</p>
          </router-link></li>
        </ul>
      </div>
      <div class="video">
        <div class="vidtab">
          <h2 class="active" @click="yangshihandle(1,0)">冠领在央视<router-link to="/tv">更多 ></router-link></h2>
          <h2  @click="yangshihandle(2,1)">冠领电视普法<router-link :to="{path:'/tv',query:{id:39}}">更多 ></router-link></h2>
        </div>
        <div class="vidbox">
          <div class="viditem">
            <!-- :src="shipinData[0]['video_url']" -->
            <div class="viditemtop"><video controls="controls" :src="shipinData[0]['video_url']" ></video></div>
            <ul>
            	<li><router-link :to="{path:'/tv/'+shipinData[1]['id']+'.html'}">
                <img :src="shipinData[1]['thumb']" >
                <p>{{shipinData[1]['title']}}</p>
              </router-link></li>
              <li><router-link :to="{path:'/tv/'+shipinData[2]['id']+'.html'}">
                <img :src="shipinData[2]['thumb']" >
                <p>{{shipinData[2]['title']}}</p>
              </router-link></li>
            </ul>
          </div>
<!--          <div class="viditem">
            <div class="viditemtop"><video controls="controls" src="http://gl.guanlingls.com/index.php?user/publicLink&fid=345a6PIK63siA1MjHXEYYH04I3uXOJuaEbnbHTXr6LpWYIyuwZXxBOegZD_wdS0O00i2aEFcIcsbQivezai8vHcw2Iqn0CHXQUwVS0hkFo-DIq8y8yYy-l3gSLNkoXKEZinE&file_name=/sdyw20211103.mp4" poster="../assets/vfm01.jpg"></video></div>
            <ul>
            	<li><router-link to="">
                <img src="../assets/vim02.jpg" >
                <p>央视《法律讲堂》周旭亮主讲《“喜得儿子”却被骗》</p>
              </router-link></li>
              <li><router-link to="">
                <img src="../assets/vim02.jpg" >
                <p>央视《法律讲堂》周旭亮主讲《“喜得儿子”却被骗》</p>
              </router-link></li>
            </ul>
          </div> -->
        </div>
      </div>
      <div class="jigou">
        <h2>冠领机构新闻<router-link :to="{path:'/newslist',query:{id:50}}">更多 ></router-link></h2>
        <ul>
        	<li v-for="item,index in newsjgData" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">{{item.title}}</router-link></li>
        </ul>
      </div>
    </div>
    <!-- 热点专题 -->
    <div class="hotzt w1200">
      <div class="hotl">
        <h2>热点专题<!-- <router-link to="">更多 ></router-link> --></h2>
        <ul>
        	<li><img src="../assets/hot01.jpg" ><a href="http://guanlingms.com/caifu/index.html" target="_blank"><img src="../assets/20220223181008.jpg" ></a></li>
        	<li><img src="../assets/hot02.jpg" ><a href="http://guanlingms.com/flzx.html"  target="_blank"><img src="../assets/20220223181014.jpg" ></a></li>
        	<li><img src="../assets/hot03.jpg" ><a href="http://guanlingzc.com/"  target="_blank"><img src="../assets/20220224094337.jpg" ></a></li>
        	<li><img src="../assets/hot04.jpg" ><router-link to=""><img src="../assets/20220223181001.jpg" ></router-link></li>
        </ul>
      </div>
      <!-- 十大要闻 -->
      <div class="yaowen">
        <h2>十大要闻<router-link to="/newslist">更多 ></router-link></h2>
        <div class="yaowenbox">
          <video controls="controls" src="http://gl.guanlingls.com/index.php?user/publicLink&fid=345a6PIK63siA1MjHXEYYH04I3uXOJuaEbnbHTXr6LpWYIyuwZXxBOegZD_wdS0O00i2aEFcIcsbQivezai8vHcw2Iqn0CHXQUwVS0hkFo-DIq8y8yYy-l3gSLNkoXKEZinE&file_name=/sdyw20211103.mp4" poster="../assets/yaowen.jpg"></video>
        </div>

      </div>
    </div>

    <!-- 新闻媒体 -->
    <div class="mediabox">
      <div class="mediawrap w1200">
        <div class="medtop">
          <ul class="medtop1">
            <li></li>
            <li><router-link :to="{path:'/tv',query:{'id':35}}"><img src="../assets/laile.png" style="width:148px"></router-link></li>
            <li><router-link :to="{path:'/tv',query:{'id':35}}"><!-- 央视<br>新媒体普法 --></router-link></li>
            <li></li>
            <li>
              <router-link :to="{path:'/tv',query:{'id':36}}">
                <img src="../assets/cctv12.png" style="width: 60px" >
                <p>以案说法</p>
              </router-link>

            </li>
          </ul>
          <div class="medtop2 combor">
            <router-link :to="{path:'/tv/'+shipinData[0]['id']+'.html'}">
            <strong>{{shipinData[0]['title']}}</strong>
            <p>{{shipinData[0]['miaoshu']}}</p>
            </router-link>
          </div>
          <ul class="medtop3">
            <li></li>
            <li><router-link :to="{path:'/tv',query:{'id':42}}">北京电视台BTV科教<br>《律师门诊室》</router-link></li>
            <li></li>
            <li><router-link :to="{path:'/tv',query:{'id':39}}">北京电视台BTV科教<br>《法治进行时》</router-link></li>
            <li></li>
            <li><router-link :to="{path:'/tv',query:{'id':40}}">庭审纪实</router-link></li>
          </ul>
        </div>
        <div class="medmil">
          <ul class="medmiline">
            <li></li>
            <li><router-link :to="{path:'/tv',query:{'id':33}}"><img src="../assets/jiangtang.png" style="width: 83px;"></router-link></li>
            <li></li>
            <li><router-link :to="{path:'/tv',query:{'id':41}}"><img src="../assets/tiaojie.png" style="width:142px"></router-link></li>
            <li></li>
            <li>
              <router-link :to="{path:'/tv',query:{'id':37}}">
                <img src="../assets/cctv13.png" style="width: 69px" >
                共同关注
              </router-link>
            </li>
            <li></li>
            <li><router-link :to="{path:'/tv',query:{'id':43}}">北京电视台BTV<br>生活频道《生活广角》</router-link></li>
            <li></li>
          </ul>
        </div>
        <div class="medbtm">
          <ul class="medmiline">
            <li>
              <router-link :to="{path:'/tv',query:{'id':38}}">
                <img src="../assets/cctv7.png" style="width: 60px;">
                军事农业
              </router-link>
            </li>
            <li></li>
            <li><router-link :to="{path:'/tv',query:{'id':44}}">北京电视台BTV青年<br>《谁在说》</router-link></li>
            <li></li>
            <li><router-link to="/tv"><img src="../assets/xiaologo.png" style="width: 42px;"></router-link></li>
            <li><!-- <router-link :to="{path:'/tv',query:{'id':41}}"><img src="../assets/tiaojie.png" style="width:142px"></router-link> --></li>

            <li><router-link :to="{path:'/tv',query:{'id':45}}">冠领说法</router-link></li>
            <li></li>
            <li><router-link to="/tv">其他视频</router-link></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- 律师团队 -->
    <div class="lawyer w1200 combox">
      <h2>
        <strong>律师团队</strong>
        <ol>
          <li><router-link :to="{path:'/lawyer',query:{id:13}}">律所主任</router-link></li>
          <li><router-link :to="{path:'/lawyer',query:{id:32}}">专家顾问</router-link></li>
          <li><router-link :to="{path:'/lawyer',query:{id:14}}">律师团队</router-link></li>
          <li><router-link :to="{path:'/lawyer',query:{id:16}}">律师助理</router-link></li>
          <li><router-link to="/lawyer">更多 ></router-link></li>
        </ol>
      </h2>
      <div class="zhuren">
        <div class="zhurenl">
          <router-link to="/lawyer/1.html">
          <div class="zhurenimg"><img src="../assets/zxl.jpg" ></div>
          <div class="zhureninfo">
            <h3>周旭亮<small>主任律师</small></h3>
            <strong>冠领创始合伙人</strong>
            <p>周旭亮，北京冠领律师事务所主任，参加过CCTV12《法律讲堂》主讲律师，CCTV12《律师来了》人气律师，文化部《中华英才》封底人物专访、BTV科教频道《法治进行时》等节目...</p>
          </div>
          </router-link>
        </div>
        <div class="zhurenr">
          <router-link to="/lawyer/9.html">
          <div class="zhurenimg"><img src="../assets/rzm.jpg" ></div>
          <div class="zhureninfo">
            <h3>任战敏<small>执行主任律师</small></h3>
            <strong>冠领创始合伙人</strong>
            <p>任战敏，男，北京冠领律师事务所创始人、执行主任，参加过CCTV12《律师来了》人气律师，CCTV12《法律的道理》人气律师，《法制晚报》法律大讲堂主讲律师，专为法律人化...</p>
          </div>
          </router-link>
        </div>
      </div>
      <ul>
      	<li v-for="item,index in lawyerData" :key="index"><router-link :to="{path:'/lawyer/'+item.id+'.html'}">
      	  <img :src="item.thumb" >
          <span>{{item.title}}</span>
      	  <div>
      	    <strong>{{item.title}}</strong>
      	    <p>{{item.description}}</p>
      	    <router-link :to="{path:'/lawyer/'+item.id+'.html'}">查看详情</router-link>
      	  </div>
      	</router-link></li>
      </ul>
    </div>
    <!-- 胜诉案例 -->
    <div class="anli w1200 combox">
      <h2>
        <strong>胜诉案例</strong>
        <ol>
          <li><router-link :to="{path:'/case',query:{'id':68}}">民事诉讼</router-link></li>
          <li><router-link :to="{path:'/case',query:{'id':75}}">行政诉讼</router-link></li>
          <li><router-link :to="{path:'/case',query:{'id':7}}">公司业务</router-link></li>
          <li><router-link :to="{path:'/case',query:{'id':8}}">刑事诉讼</router-link></li>
          <li><router-link :to="{path:'/case',query:{'id':81}}">知识产权诉讼</router-link></li>
          <li><router-link :to="{path:'/case',query:{'id':10}}">交通事故</router-link></li>
          <li><router-link :to="{path:'/case',query:{'id':65}}">涉外业务</router-link></li>
          <li><router-link to="/case">更多 ></router-link></li>
        </ol>
      </h2>
      <div class="anlibox">
        <div class="anlil">
          <div class="anlilone" v-for="item,index in anliData" :key="index">
            <router-link :to="{path:'/case/'+item.id+'.html'}">
            <div class="anlipic"><img :src="item.thumb" ></div>
              <p>{{item.title}}</p>
            <div class="anlitime">
              <time>{{item.create_time}}</time>
              <span>民事</span>
            </div>
            </router-link>
          </div>
        </div>
        <div class="anlir">
          <ul>
          	<li v-for="item,index in newanliData" :key="index"><em>行政</em>|<router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link><time>{{item.create_time}}</time></li>

          </ul>
        </div>
      </div>
    </div>

    <!-- 冠领荣誉 -->
    <div class="rongyu w1200 combox">
      <h2>
        <strong>冠领荣誉</strong>
        <ol>
          <li><router-link :to="{path:'/honor',query:{'id':24}}">锦旗荣誉</router-link></li>
          <li><router-link :to="{path:'/honor',query:{'id':25}}">奖杯荣誉</router-link></li>
          <li><router-link :to="{path:'/honor',query:{'id':149}}">好评荣誉</router-link></li>
          <li><router-link to="/honor">更多 ></router-link></li>
        </ol>
      </h2>
      <div class="ryimgbox">
        <img src="../assets/ryimg01.jpg" >
        <img src="../assets/ryimg02.jpg" >
        <img src="../assets/ryimg03.jpg" >
        <ul>
        	<li>法制晚报2017年度年度优秀律所</li>
        	<li>法制晚报优秀律师奖</li>
        	<li>十大无罪辩护案例</li>
        	<li>优秀个人奖</li>
        	<li>《律师来了》公益代理律师</li>
        </ul>
      </div>
    </div>

    <!-- 联系我们 -->
    <LianxiView/>

    <!-- 合作伙伴 -->
    <div class="huoban w1200 combox">
      <h2>
        <strong>合作伙伴</strong>
      </h2>
      <ul>
      	<li><img src="../assets/hbimg01.jpg" ></li>
      	<li><img src="../assets/hbimg02.jpg" ></li>
      	<li><img src="../assets/hbimg03.jpg" ></li>
      	<li><img src="../assets/hbimg04.jpg" ></li>
      	<li><img src="../assets/hbimg05.jpg" ></li>
      	<li><img src="../assets/hbimg06.jpg" ></li>
      	<li><img src="../assets/hbimg07.jpg" ></li>
      	<li><img src="../assets/hbimg08.jpg" ></li>
      	<li><img src="../assets/hbimg09.jpg" ></li>
      	<li><img src="../assets/hbimg10.jpg" ></li>
      	<li><img src="../assets/hbimg11.jpg" ></li>
      	<li><img src="../assets/hbimg12.jpg" ></li>
        <li><img src="../assets/hbimg19.jpg" ></li>
        <li><img src="../assets/hbimg20.jpg" ></li>
        <li><img src="../assets/hbimg21.jpg" ></li>
        <li><img src="../assets/hbimg22.jpg" ></li>
        <li><img src="../assets/hbimg23.jpg" ></li>
        <li><img src="../assets/hbimg24.jpg" ></li>
      </ul>
    </div>
  <FooterView/>
  </div>
</template>

<script>
import $ from 'jquery'
import LianxiView from '../components/LianxiView.vue'
import {request} from '../network/request.js'
import GLOBAL from '../global/global.js'
export default {
  name: 'HomeView',
  components: {
    LianxiView
  },
  data(){
    return {
      bannerData:[],
      bannerUrl:[],
      shipinData:[],
      newsData:[],
      newsjgData:[],
      lawyerData:[],
      anliData:[],
      newanliData:[],
      yangshinum:33,
      newsid:29,
      bannerID:0,
      keys:0
    }
  },
  methods:{
    setColor(index){
      this.keys = index
      $('.banbox li').eq(index).fadeIn().siblings().hide()
    },
    banner(){
      let that = this
      request({
        url: '/index/banner?id=2',
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          that.bannerData = []
          // console.log(jsondata);
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = jsondata['data'];
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              let thumblength = thumb[17].length
              val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4)

              //ID
              // console.log(val['url'].split('/'));
              val['url'] = val['url'].split('/')[3]+'/'+val['url'].split('/')[4]
              // console.log( val['url'] );
              that.bannerData.push(val)
            });

            // that.bannerUrl = jsondata['data']['']
          }
        }]
      })
    },
    news(id){
      let that = this
      request({
        url: '/index/news?id='+id,
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          // console.log(jsondata);
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = ''
            if(id == 1){
              that.newsData = []
              newData = jsondata['data'].splice(0,5)
              newData.forEach(function(val){
                let thumb = val['thumb'].split(':')
                let thumblength = thumb[17].length
                val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
                that.newsData.push(val)
              });
            }else if(id == 2){
              that.newsjgData = []
              newData = jsondata['data']
              newData.forEach(function(val){
                val['create_time'] = val['create_time'].split(' ')[0]
                that.newsjgData.push(val)
              });
            }
          }
        }]
      })
    },
    yangshihandle(id,lmid){
      $('.vidtab h2').eq(lmid).addClass('active').siblings().removeClass('active')
      this.shipin(id)
      if(id == 1){
        this.yangshinum = 33
      }else{
        this.yangshinum = 39
      }
    },
    shipin(id){
      let that = this
      request({
        url: '/index/video?id='+id,
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          console.log(jsondata);
          that.shipinData = []
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = jsondata['data'];
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              // console.log(thumb);
              let thumblength = thumb[21].length
              val['thumb'] = GLOBAL.httpurl+thumb[21].substr(1,thumblength-4);
              that.shipinData.push(val)
            });
          }
        }]
      })
    },
    lawyer(){
      let that = this
      request({
        url: '/index/team',
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          // console.log(jsondata);
          that.lawyerData = []
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = jsondata['data']
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              let thumblength = thumb[17].length
              val['thumb'] = 'http://api.guanlingss.com'+thumb[17].substr(1,thumblength-4);
              that.lawyerData.push(val)
            });
          }
        }]
      })
    },
    anli(id){
      let that = this
      request({
        url: '/index/anli',
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          // console.log(jsondata);
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = ''
            if(id == 2){
              that.anliData = []
              newData = jsondata['data'].slice(0,2)
            }else{

              that.newanliData = []
              newData = jsondata['data'].slice(2)
            }

            // console.log(newData);
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              let thumblength = thumb[17].length
              val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4)
              val['create_time'] = val['create_time'].split(' ')[0]
              if(id == 2){
                that.anliData.push(val)
              }else{
                that.newanliData.push(val)
              }
              // console.log(that.newanliData);
            });
          }
        }]
      })
    }
  },
  mounted(){
    this.banner()
    this.shipin(1)
    this.news(1)
    this.news(2)
    this.lawyer()
    this.anli(2)
    this.anli(3)
    $(".chonggou a").attr('class','')
    if(this.$route.name == 'home'){
      $(".chonggou a[href='/']").attr('class','router-link-active')
    }
    // banner
    setTimeout(function(){
      let oli = $('.baside ol li');
      let uli = $('.banbox ul li');
      let olisize = oli.length;
      let idx = 0;
      let timeid = null;
      oli.mouseover(function(){
        clearInterval(timeid)
        var _index = $(this).index();
        $(this).addClass('banact').siblings().removeClass('banact')
        uli.eq(_index).stop().fadeIn(200).siblings().hide();
      })
      oli.mouseout(function(){
        banrun()
      })
      banrun()
      function banrun(){
        timeid = setInterval(function(){
          idx++
          idx >= olisize ? idx = 0 : idx = idx
          oli.eq(idx).addClass('banact').siblings().removeClass('banact')
          uli.eq(idx).stop().fadeIn(200).siblings().hide();
        },5000)
      }
    },500)






    //冠领总部新闻
    request({
      url: '/News/newslist?id=1',
      transformResponse:[function(data){
        // console.log(data)
      }]
    })







// console.log(axios)
  }
}
</script>

<style lang="scss" scoped="scoped">

.home{
  background: #f3f3f3;
}
  .banner{
    min-width: 1200px;
    overflow: hidden;
      .baside{
        height: 1px;
        position: relative;
        z-index: 10;
        ol{
          width: 370px;
          height: 490px;
          background: rgba(0,0,0,.4);
          float: right;
          display: flex;
          flex-direction: column;
          padding-top: 10px;
          li{
            color: #f3f3f3;
            font-size: 14px;
            padding: 0 40px;
            line-height: 26px;
            height: 80px;
            // transition: all .3s linear 0s;
            cursor: pointer;
            display: flex;
            align-items: center;

            b{
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
              color: #fff;
            }

          }
          li.banact{
            background-image: linear-gradient(to right, #b80816, rgba(184,8,22,.5));
            background-image: -webkit-linear-gradient(to right, #b80816, rgba(184,8,22,.5));
            background-image: -moz-linear-gradient(to right, #b80816, rgba(184,8,22,.5));
            background-image: -ms-linear-gradient(to right, #b80816, rgba(184,8,22,.5));
            font-size: 18px;
            font-weight: bold;
          }

        }
      }
      @media screen and (max-width: 1500px) {
          .banbox{
            ul{
              margin-left: -250px;
            }
          }
      }
      .banbox{

        position: relative;
        ul{
          position: absolute;
          li{
            display:none;
            text-align: center;
            img{

            }
          }
          li:first-child{
            display:block;
          }
        }
      }
  }
  .yewu{
    height: 116px;
    border: 1px solid #dddddd;
    box-sizing: border-box;
    margin-top: 50px;
    ul{
      display: flex;
      li:hover{
        a{
          color: #fff;
        }
      }
      li{
        flex: 1;
        font-size: 16px;
        color: #1e1e1e;
        display:flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-right: 1px solid #dddddd;
        border-bottom: 1px solid #dddddd;
        box-sizing: border-box;
        height: 116px;
        cursor: pointer;
        transition: all .5s linear 0s;
        background-color: #fff;
        div{
          display: flex;
          justify-content: center;
        }
        a:hover{
          color: #fff !important;
        }
        .ywhide{
          opacity: 0;
          width: 0;
          height: 0;
          transition: all .3s linear 0s;
        }
        b{
           text-align: center;
           margin-top: 12px;
           display: block;
        }
      }
      li:last-child{
        border-right: none;
      }
      li:hover .ywhide{
        width: auto;
        height: auto;
        opacity: 1;
        transform: scale(1.2);
      }
      li:hover .ywshow{
        width: 0;
        height: 0;
       opacity: 0;
      }

      li:hover{
        background-color: #b80816;
        color: #fff;
      }
      li:hover b{
        font-weight: bold;
      }

    }
  }
  .newsbox{
      margin-top: 50px;
      display: flex;
      justify-content: space-between;
      h2{
        font-size: 20px;
        color: #b80816;
        padding-left: 22px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 54px;
        box-sizing: border-box;
        border-top: 3px solid #b80816;
        border-bottom: 1px solid #dedede;
        cursor: pointer;
        background: #f9f9f9;
        a{
          font-size: 16px;
          margin-right: 25px;
        }
      }
      .news,.video,.jigou{
        border: 1px solid #dedede;
        box-sizing: border-box;
        background-color: #fff;
        height: 610px;
      }
      .news h2, .jigou h2{
        background-color: #fff;
      }
      .news{
        width: 309px;
        ul{
          li:hover img{
            transform: scale(1.1);
          }
          li:last-child{
            border-bottom: none;
          }
          li{
            padding: 15px 0;
            border-bottom: 1px solid #dedede;
            box-sizing: border-box;
            a{
              display: flex;
              font-size: 14px;
              align-items: center;
              .litpic{
                margin-left: 20px;
                width: 100px;
                height: 75px;
                overflow: hidden;
                img{
                  transition: all .3s linear 0s;
                  width: 100px;
                  height: 75px;
                }
              }
              p{
                margin-left: 10px;
                margin-right: 15px;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 3;
                overflow: hidden;
                line-height: 26px;
                width: 160px;
              }
            }
          }
        }
      }
      .video{
        width: 542px;

        .vidtab{
          display: flex;
          h2{
            flex: 1;
            border-top: none;
            color: #333333;

          }
          h2.active{
             color: #b80816;
             border-top: 3px solid #b80816;
             background-color: #fff;
          }
        }
        .vidbox{
          .viditem:first-child{
            display: block;
          }
          .viditem{
            display: none;
            .viditemtop{
              display: flex;
              justify-content: center;
              height: 294px;
              video{
                margin-top: 24px;
                width: 482px;
              }
            }
          }
          ul{
            padding: 0 26px;
            margin-top: 16px;
            display: flex;
            justify-content: space-between;
            li{
              width: 234px;
              a{
                img{
                  width: 235px;
                }
                p{
                  line-height: 25px;
                  font-size: 16px;
                  margin-top: 12px;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2;
                  overflow: hidden;
                  line-height: 26px;
                }
              }
            }
          }
        }
      }
      .jigou{
        width: 309px;
        height: 500px;
        ul{
          padding: 0 20px;
          li{
            margin-top: 25px;
            line-height: 100%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            a{
              font-size: 14px;
              time{
                margin-right: 5px;
              }
            }
          }

        }
      }
  }
  .hotzt{
    margin-top: 65px;
    position: relative;
    margin-bottom: 70px;
    .hotl{
      width: 870px;
      h2{
        font-size: 30px;
        color: #333;
        display: flex;
        justify-content: space-between;
        background: url(../assets/hoticon.jpg) no-repeat left center;
        text-indent: 42px;
        a{
          font-size: 16px;
          padding-top: 18px;
        }
      }
      ul{
        display: flex;
        justify-content: space-between;
        margin-top: 12px;
        position: relative;
        overflow: hidden;
        li{
          width: 202px;
          cursor: pointer;
          a{
            position: absolute;
            left: -100%;
            top: 0;
            width: 100%;
            background: red;
            transition: all .3s linear 0s;
            z-index: 10;
          }
        }
        li:hover a{
          left: 0
        }
        li:nth-child(n+3){
          a{
            right: -100%;
            left: auto;
          }
        }
        li:nth-child(n+3):hover{
          a{
            // left: 0;
            right: 0;
          }
        }
      }
    }
    .yaowen{
      position: absolute;
      right: 0;
      top: -160px;
      h2{
        font-size: 30px;
        color: #333;
        display: flex;
        justify-content: space-between;
        background: url(../assets/hoticon.jpg) no-repeat left center;
        text-indent: 42px;
        margin-bottom: 10px;
        a{
          font-size: 16px;
          padding-top: 18px;
        }
      }
      .yaowenbox{
        background: #000;
        height: 237px;
        video{
          margin-top: 30px;
          width: 309px;
        }
      }

    }

  }
  .mediabox{
    display: flex;
    flex-wrap: wrap;
    background: url(../assets/medbg.png) no-repeat center top;
    padding-top: 74px;
    padding-bottom: 61px;
    .medtop{
      width: 100%;
      display: flex;
      justify-content: space-between;
      height: 210px;
      .medtop1,.medtop3{
        width: 320px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        li{
          width: 100px;
          height: 100px;
          box-sizing: border-box;
          margin-bottom: 10px;
          cursor: pointer;
          background-repeat: no-repeat;
          background-position: center;
          background-image:url(../assets/current.jpg);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-wrap: wrap;
          font-size: 16px;
          color: #fff;
          font-weight: bold;
          text-align: center;
          line-height: 24px;
          a{
            color: #fff !important;
          }
        }
        li:nth-child(2){
          width: 210px;
          background-image:url(../assets/zc.jpg);
        }
        li:nth-child(5){
          flex-direction: column;
          p{
            margin-top: 8px;
          }
        }
        li:nth-child(2):hover{
          background-image:url(../assets/zc-s.jpg);
        }

        li:nth-child(5){
          background-image:url(../assets/xc.jpg)
        }

        li:nth-child(5):hover{
          background-image:url(../assets/xc-s.jpg)
        }
      }
      .medtop2{
        width: 425px;
        height: 208px;
        color: #fff;
        cursor: pointer;
        background:#b80816 url(../assets/dc.jpg) no-repeat center;
        a{
          color: #fff !important;
        }
        strong{
          display: block;
          text-align: center;
          font-size: 20px;
          font-weight: bold;
          margin-top: 45px;
        }
        p{
          line-height: 26px;
          font-size: 16px;
          padding: 0 30px;
          margin-top: 20px;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
        }
      }
      .medtop2:hover{
         background: #c61b1b url(../assets/dc-s.jpg) no-repeat center;
      }
      .medtop3{
        width: 430px;
        li{
          background-image:url(../assets/current.jpg) ;
        }
        li:nth-child(3),li:nth-child(5){
          background-image:url(../assets/current.jpg) !important;
        }
        li:nth-child(2), li:nth-child(4){
          width: 210px;
          background-image:url(../assets/zc.jpg) ;
        }
        li:nth-child(2):hover, li:nth-child(4):hover{
          background-image:url(../assets/zc-s.jpg) ;
        }
        li:last-child{
          background-image:url(../assets/xc.jpg);
        }
        li:last-child:hover{
          background-image:url(../assets/xc-s.jpg);
        }
      }
    }
    .medmil,.medbtm{
       width: 100%;
       margin-top: 10px;
      .medmiline{
        display: flex;
        justify-content: space-between;
        li{
          width: 100px;
          height: 100px;
          box-sizing: border-box;
          margin-bottom: 10px;
          cursor: pointer;
          background-repeat: no-repeat;
          background-position: center;
          background-image:url(../assets/current.jpg);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          font-weight: bold;
          color: #FFFFFF;
          text-align: center;
          line-height: 24px;
          a{
            color: #fff !important;
          }
        }
        li:nth-child(6){
          flex-direction: column;
          img{
            margin-bottom: 8px;
          }
        }
        li:nth-child(4),
        li:nth-child(8){
          width: 210px;
          background-image:url(../assets/zc.jpg);
        }
        li:nth-child(4):hover,
        li:nth-child(8):hover{
           background-image:url(../assets/zc-s.jpg);
        }
        li:nth-child(2),
        li:nth-child(6){
          background-image:url(../assets/xc.jpg);
        }
        li:nth-child(2):hover,
        li:nth-child(6):hover{
          background-image:url(../assets/xc-s.jpg);
        }
      }
    }
    .medbtm{
      margin-top: 0;
      .medmiline{
        li:nth-child(1){
          flex-direction: column;
          img{
            margin-bottom: 8px;
          }
        }
        li,li:nth-child(4),li:nth-child(2){
          background-image:url(../assets/current.jpg);
        }
        li:nth-child(2):hover,
        li:nth-child(4):hover{
          background-image:url(../assets/current.jpg);
        }
        li:nth-child(4),
        li:nth-child(8){
          width: 100px;
        }
        li:nth-child(3),
        li:nth-child(6),
        li:nth-child(6):hover{
          width: 210px;
          background-image:url(../assets/zc.jpg);
        }
        li:nth-child(3):hover{
          background-image:url(../assets/zc-s.jpg);
        }
        li:nth-child(1),
        li:nth-child(5),
        li:nth-child(8),
        li:nth-child(9){
          background-image:url(../assets/xc.jpg) !important;
        }
        li:nth-child(1):hover,
        li:nth-child(5):hover,
        li:nth-child(7):hover,
        li:nth-child(9):hover{
          background-image:url(../assets/xc-s.jpg) !important;
        }
      }
    }
  }
  .lawyer{
    h2{
      strong{
        background-image: url(../assets/icon01.jpg);
      }
    }
    .zhuren{
      margin-top: 20px;
      display: flex;
      justify-content: space-between;
      .zhurenl,
      .zhurenr{
        width: 590px;
        background: #fff;
      }
      .zhurenl,.zhurenr{
        a{
          display: flex;
        }
        .zhurenimg{
          width: 204px;
        }
        .zhureninfo{
          margin-left: 25px;
          width: 358px;
          h3{
            font-size: 22px;
            color: #333;
            margin-top: 28px;
            small{
              font-size: 16px;
              margin-left: 10px;
            }
          }
          strong{
            font-size: 16px;
            display: block;
            color: #fff;
            text-align: center;
            width: 140px;
            height: 38px;
            line-height: 38px;
            background-image: linear-gradient(to right, #ba0a16,#ee3b19);
            background-image: -webkit-linear-gradient(to right, #ba0a16,#ee3b19);
            background-image: -moz-linear-gradient(to right, #ba0a16,#ee3b19);
            background-image: -ms-linear-gradient(to right, #ba0a16,#ee3b19);
            border-radius: 8px;
            margin-top: 12px;
          }
          p{
            font-size: 14px;
            color: #333;
            line-height: 26px;
            padding-right: 35px;
            margin-top: 20px;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 4;
            overflow: hidden;
          }
        }
      }
    }
    ul{
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
      li:hover{
        border: 2px solid #b80816;
      }
      li:hover div{
        opacity: 1;
      }
      li:hover span{
        opacity: 0;
      }
      li:hover div strong{
        background: transparent;
        font-size: 16px;
        font-weight: bold;
        padding-top: 12px;
      }
      li:hover div p,
      li:hover div a{
        opacity: 1;
      }
      li{
        position: relative;
        width: 160px;
        overflow: hidden;
        transition: all .3s linear 0s;
        box-sizing: border-box;
        background: #b80816;
        span{
          text-align: center;
          height: 36px;
          line-height: 36px;
          background: #b80816;
          position: absolute;
          bottom: 0;
          left: 0;
          width: 100%;
          color: #fff;
          transition: all .3s linear 0s;
        }
        img{
          width: 100%;
        }
        div{
          height: 100%;
          text-align: center;
          color: #fff;
          position: absolute;
          bottom: 0;
          left: 0;
          width: 100%;
          background: rgba(0,0,0,.4);
          transition: all .3s linear 0s;
          opacity: 0;
          strong{
            display: block;
            text-align: center;
            height: 36px;
            line-height: 36px;
            transition: all .3s linear 0s;
          }
          p{
            font-size: 14px;
            line-height: 22px;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 4;
            overflow: hidden;
            padding: 0 15px;
            margin-top: 0px;
            opacity: 0;
            transition: all .5s linear 0s;
          }
          a{
            height: 32px;
            line-height: 32px;
            text-align: center;
            width: 100px;
            display: block;
            background: transparent;
            border: 1px solid #fff;
            box-sizing: border-box;
            color: #fff;
            margin-top: 16px;
            opacity: 0;
            transition: all .6s linear 0s;
            margin: 16px auto 0;
          }
        }
      }
    }
  }
  .anli{
    h2{
      strong{
        background-image: url(../assets/icon02.jpg);
      }
    }
    .anlibox{
      display: flex;
      justify-content: space-between;
      margin-top: 18px;
      .anlil{
        width: 510px;
        display: flex;
        justify-content: space-between;
        .anlilone:hover img{
          transform: scale(1.1);
        }
        .anlilone{
          width: 248px;
          background: #fff;
          font-size: 14px;
          a{
            padding: 0!important;
            margin-top: 0!important;
            p{
              padding: 0 20px;
              margin-top: 10px;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
          }
          .anlipic{
            overflow: hidden;
            img{
              width: 248px;
              transition: all .3s linear 0s;
            }
          }
          a{
            line-height: 26px;
            margin-top: 12px;
            padding: 0 20px;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
          }
          .anlitime{
            padding: 0 20px;
            color: #b6b6b6 !important;
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            padding-bottom: 18px;
          }
        }
      }
      .anlir{
        width: 674px;
        background: #fff;
        ul{
          display: flex;
          flex-direction: column;
          justify-content: space-evenly;
          height: 100%;
          li:hover a,
          li:hover time{
            font-size: 16px;
            color: #b80816;
          }
          li{
            font-size: 14px;
            color: #999;
            padding-left: 20px;
            display: flex;
            flex-wrap: nowrap;
            em{
              margin-right: 10px;
              width: 30px;
            }
            a{
              margin-left: 10px;
              color: #333;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
              width: 66%;
              margin-right: 40px;
            }
            time{
             float: right;
             padding-right: 30px;
            }
          }
        }
      }
    }
  }
  .rongyu{
    h2{
      strong{
        background-image: url(../assets/icon03.jpg);
      }
    }
    .ryimgbox{
        margin-top: 20px;
        position: relative;
        ul{
          position: absolute;
          bottom: 0;
          left: 0;
          width: 100%;
          display: flex;
          justify-content: space-between;
          li{
            height: 30px;
            line-height: 30px;
            text-align: center;
            width: 228px;
            color: #fff;
            font-size: 14px;
          }
        }
    }
  }

  .huoban{
    h2{
      strong{
        background-image: url(../assets/icon06.jpg);
      }
    }
    ul{
      margin-top: 20px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      li:hover img{
        transform: translateZ(0) scale(1.1) ;
      }
      li{
        margin-bottom: 16px;
        overflow: hidden;
        cursor: pointer;
        img{
          transition: all .3s linear 0s;
        }
      }
    }
  }
</style>
