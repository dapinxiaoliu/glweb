<template>
  <div class="yewu">
    <div class="comban">
      <img src="../assets/yewuban.jpg" >
      <div>
        <strong>全球业务</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="yewuwrap">
      <div class="yewuitem">
        <h2><img src="../assets/yewuimg01.jpg" ><router-link :to="{path:'/yewu/minshi.html'}">民事诉讼</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[0]['child']" :key="index"><router-link :to="{path: '/yewu/minshi.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>
        </ul>
      </div>
      <div class="yewuitem">
        <h2><img src="../assets/yewuimg06.jpg" ><router-link :to="{path:'/yewu/jiaotong.html'}">交通事故诉讼</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[5]['child']" :key="index"><router-link :to="{path: '/yewu/jiaotong.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>
        </ul>
      </div>
      <div class="yewuitem">
        <h2><img src="../assets/yewuimg05.jpg" ><router-link :to="{path:'/yewu/zhishi.html'}">知识产权诉讼</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[4]['child']" :key="index"><router-link :to="{path: '/yewu/zhishi.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>

        </ul>
      </div>
      <div class="yewuitem">
        <h2><img src="../assets/yewuimg07.jpg" ><router-link :to="{path:'/yewu/shewai.html'}">涉外业务</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[6]['child']" :key="index"><router-link :to="{path: '/yewu/shewai.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>

        </ul>
      </div>
      <div class="yewuitem">
        <h2><img src="../assets/yewuimg09.jpg" ><router-link :to="{path:'/yewu/zhaobiao.html'}">招投标业务</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[7]['child']" :key="index"><router-link :to="{path: '/yewu/zhaobiao.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>
        </ul>
      </div>
      <div class="yewuitem">
        <h2><img src="../assets/yewuimg02.jpg" ><router-link :to="{path:'/yewu/xingzheng.html'}">行政诉讼</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[1]['child']" :key="index"><router-link :to="{path: '/yewu/xingzheng.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>
        </ul>
      </div>
      <div class="yewuitem">
        <h2><img src="../assets/yewuimg04.jpg" ><router-link :to="{path:'/yewu/xingshi.html'}">刑事诉讼</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[3]['child']" :key="index"><router-link :to="{path: '/yewu/xingshi.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>

        </ul>
      </div>


      <div class="yewuitem">
        <h2><img src="../assets/yewuimg03.jpg" ><router-link :to="{path:'/yewu/gongsi.html'}">公司业务</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[2]['child']" :key="index"><router-link :to="{path: '/yewu/gongsi.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>
        </ul>
      </div>

      <div class="yewuitem">
        <h2><img src="../assets/yewuimg08.jpg" ><router-link :to="{path:'/yewu/shangshi.html'}">商事业务</router-link></h2>
        <ul>
        	<li v-for="item,index in lmData[8]['child']" :key="index"><router-link :to="{path: '/yewu/shangshi.html',query:{'id':item.id}}" >{{item.name}}</router-link></li>
        </ul>
      </div>


    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default {
    name: 'Yewu',
    data(){
      return {
        lmData:[]
      }
    },
    methods:{
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lmData = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                // newData.forEach(function(val){
                //   val['id']
                //   val['child'].forEach(function(item){
                //     item['']
                //   })
                // })
                 that.lmData = newData
                 // console.log(newData);
                 // console.log(newData);

              }
            }
          }]
        })
      }
    },
    mounted() {
      this.getlmData()
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'yewu'){
          $(".chonggou a[href$='/yewu']").attr('class','router-link-active')
        }
      })

    }
  }
</script>

<style lang="scss" scoped="scoped">
  .yewu{
    margin-bottom: .3rem;
    .yewuwrap{
      padding: .3rem .2rem 0;
      border-top: .2rem solid #f3f3f3;
      overflow: hidden;
      columns: 2; // 默认列数
      column-gap: .2rem; // 列间距
      -webkit-columns: 2; // 默认列数
      -webkit-column-gap: .2rem; // 列间距
      -moz-columns: 2; // 默认列数
      -moz-column-gap: .2rem; // 列间距
      -ms-columns: 2; // 默认列数
      -ms-column-gap: .2rem; // 列间距

      .yewuitem:nth-child(5){
        margin-bottom: 0;
      }

      .yewuitem{
        width: 3.45rem;
        border: 1px solid #dcdcdc;
        border-radius: .08rem;
        overflow: hidden;
        padding-bottom: .22rem;
        break-inside: avoid;
        margin-bottom: .2rem;
        h2{
          position: relative;
          overflow: hidden;
          height: .99rem;
          margin-bottom: .22rem;
          a{
            position: absolute;
            height: .99rem;
            top: 0;
            left: 0;
            bottom: 0;
            width: 100%;
            color: #fff;
            text-align: center;
            line-height: .99rem;
          }
        }
        ul{
          li:hover{
            background-image: url(../assets/yewuicon-s.jpg);
            a{
              color: #b80816;
            }
          }
          li{
            line-height: .48rem;
            text-indent: .46rem;
            background: url(../assets/yewuicon.jpg) no-repeat .2rem center / .1rem .2rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            a{
              font-size: .28rem;
            }
          }
        }
      }
    }
  }
</style>
