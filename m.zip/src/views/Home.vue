<template>
  <div class="home">
    <div class="banner">
      <div class="swiper mySwiper banbox">
        <div class="swiper-wrapper">
          <div class="swiper-slide" v-for="item,index in bannerData" :key="index"><router-link :to="{path:'/newslist/'+item.url}"><img :src="item.thumb" ></router-link></div>
        </div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
    <!-- 业务 -->
    <div class="yewu">
      <ul>
      	<li><router-link to="/yewu/minshi.html">
          <div><img src="../assets/yw01.png" ></div>
          <strong>民事诉讼</strong>
        </router-link></li>
        <li><router-link to="/yewu/xingzheng.html">
          <div><img src="../assets/yw02.png" ></div>
          <strong>行政诉讼</strong>
        </router-link></li>
        <li><router-link to="/yewu/gongsi.html">
          <div><img src="../assets/yw03.png" ></div>
          <strong>公司业务</strong>
        </router-link></li>
        <li><router-link to="/yewu/xingshi.html">
          <div><img src="../assets/yw04.png" ></div>
          <strong>刑事诉讼</strong>
        </router-link></li>
        <li><router-link to="/yewu/zhishi.html">
          <div><img src="../assets/yw05.png" ></div>
          <strong>知识产权诉讼</strong>
        </router-link></li>
        <li><router-link to="/yewu/jiaotong.html">
          <div><img src="../assets/yw06.png" ></div>
          <strong>交通事故诉讼</strong>
        </router-link></li>
        <li><router-link to="/yewu/shewai.html">
          <div><img src="../assets/yw07.png" ></div>
          <strong>涉外业务</strong>
        </router-link></li>
        <li><router-link to="/yewu">
          <div><img src="../assets/yw08.png" ></div>
          <strong>更多业务</strong>
        </router-link></li>
      </ul>
    </div>

    <!-- 央视 -->
    <div class="yangshi">
      <div class="yangshitab">
        <button class="curr" @click="yangshihandle(1,0)">冠领在央视</button>
        <button @click="yangshihandle(2,1)">冠领电视普法</button>
      </div>
      <div class="yangshiwrap">
        <div class="yangshiitem">
          <div class="yangshitop">
            <router-link :to="{path:'/tv/'+shipinData[0]['id']+'.html'}">
              <img :src="shipinData[0]['thumb']" >
              <div><p>{{shipinData[0]['title']}}</p></div>
            </router-link>
          </div>
          <ul>
            <li><router-link :to="{path:'/tv/'+shipinData[1]['id']+'.html'}">
              <img :src="shipinData[1]['thumb']" >
              <p>{{shipinData[1]['title']}}</p>
            </router-link></li>
            <li><router-link :to="{path:'/tv/'+shipinData[2]['id']+'.html'}">
            <img :src="shipinData[2]['thumb']" >
              <p>{{shipinData[2]['title']}}</p>
            </router-link></li>
          </ul>
        </div>

      </div>
       <router-link :to="{path:'/tv',query:{'id':yangshinum}}" class="comlink">查看更多</router-link>
    </div>

    <!-- 新闻 -->
    <div class="news">
      <div class="newstab">
        <button class="curr" @click="newsColor(1,0)">冠领总部新闻</button>
        <button @click="newsColor(2,1)">冠领机构新闻</button>
      </div>
      <div class="newswrap">
        <div class="newsitem">
          <ul>

          	<li v-for="item,index in newsData" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">
              <img :src="item.thumb" >
              <div>
                <p>{{item.title}}</p>
                <strong>{{item.create_time}}</strong>
              </div>
            </router-link></li>
          </ul>
        </div>
        <div class="newsitemtwo newsitem">
          <ul>
          	<li v-for="item,index in newsData"><router-link :to="{path:'/newslist/'+item.id+'.html'}"><p>{{item.title}}</p> <strong>{{item.create_time}}</strong></router-link></li>
          </ul>
        </div>
      </div>
      <router-link :to="{path:'/news',query:{'id':newsid}}" class="comlink">查看更多</router-link>
    </div>

    <!-- 十大要闻 专题 -->
    <div class="yaowen">
      <div class="yaowentab">
        <button class="curr" @click="yaowenhandle(0)">冠领十大要闻</button>
        <button @click="yaowenhandle(1)">热点专题</button>
      </div>
      <div class="yaowenwrap">
        <div class="yaowenitem">
            <div class="yaowentop">
              <video src="http://gl.guanlingls.com/index.php?user/publicLink&fid=1203ue_k6Dos0NrZ4UN2ue_CDHnIRRmlsJs7cnDt2noHILkJmNVrSExm_XVfMmrkDrNkoIV3CXHZy1DAo_5Vs2pDfJGK4-ZS7jCq3JHrk8WFz2b8KPPuvoB_KEyLyhvPnt-u&file_name=/sdyw20220407.mp4" controls ></video>
            </div>

            <div class="yaowenbottom">

            </div>
        </div>
        <div class="yaowenzt yaowenitem">
          <ul>
          	<li><a href=""><img src="../assets/zt01.jpg" ></a></li>
          	<li><router-link :to="{path:'/caifu/index.html'}"><img src="../assets/zt02.jpg" ></router-link></li>
          	<li><router-link to=""><img src="../assets/zt03.jpg" ></router-link></li>
          	<li><router-link to=""><img src="../assets/zt04.jpg" ></router-link></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- 红框 -->
    <div class="redbox">
      <ul>
        <li><router-link to=""></router-link></li>
        <li><router-link :to="{path:'/tv',query:{'id':35}}"></router-link></li>
        <li><router-link :to="{path:'/tv',query:{'id':36}}"></router-link></li>
        <li><router-link :to="{path:'/tv',query:{'id':42}}"></router-link></li>
        <li><router-link :to="{path:'/tv',query:{'id':41}}"></router-link></li>
        <li><router-link to=""></router-link></li>
        <li><router-link to="/tv"></router-link></li>
        <li><router-link to=""></router-link></li>
        <li><router-link :to="{path:'/tv',query:{'id':38}}"></router-link></li>
        <li><router-link to=""></router-link></li>
        <li><router-link :to="{path:'/tv',query:{'id':39}}"></router-link></li>
        <li><!-- <router-link :to="{path:'/tv',query:{'id':41}}"></router-link> --></li>
      </ul>
    </div>

    <!-- 律师团队 -->
    <div class="lawyer">
       <h2 class="comh2"><strong>律师团队</strong></h2>
       <div class="zhurenbox">
         <div class="zhurenwrap">
           <router-link to="/lawyer/1.html">
             <div class="zhurenl"><img src="../assets/zxl.jpg" ></div>
             <div class="zhurenr">
               <h2><strong>周旭亮</strong><small>主任律师</small><span>冠领创始合伙人</span></h2>
               <p>周旭亮，北京冠领律师事务所主任，参加过CCTV12《法律讲堂》主讲律师，CCTV12《律师来了》人气律师，文化部《中华英才》封底人物专访、BRTV科教频道《法治进行时》等节目...</p>
             </div>
           </router-link>
         </div>
         <div class="zhurenwrap">
           <router-link to="/lawyer/9.html">
             <div class="zhurenl"><img src="../assets/hrzm.jpg" ></div>
             <div class="zhurenr">
               <h2><strong>任战敏</strong><small>主任律师</small><span>冠领创始合伙人</span></h2>
               <p>任战敏，男，北京冠领律师事务所创始人、执行主任，参加过CCTV12《律师来了》人气律师，CCTV12《法律的道理》人气律师，《法制晚报》法律大讲堂主讲律师，专为法律人化...</p>
             </div>
          </router-link>
         </div>
       </div>
       <div class="lawyerlist">
         <ul>
         	<li v-for="item,index in lawyerData"><router-link :to="{path:'/lawyer/'+item.id+'.html'}"><img :src="item.thumb" > <p>{{item.title}}</p></router-link></li>
         </ul>
       </div>
       <router-link to="/lawyer" class="comlink">查看更多</router-link>
    </div>

    <!-- 胜诉案例 -->
    <div class="anli">
      <h2 class="comh2"><strong>胜诉案例</strong></h2>
      <div class="anlituwen">
        <ul>
        	<li v-for="item,index in anliData"><router-link :to="{path:'/case/'+item.id+'.html'}">
            <img :src="item.thumb" >
            <p>{{item.title}}</p>
            <p>
              <strong v-if="item.catid == 68 || item.catid == 69 || item.catid == 70 || item.catid == 71 || item.catid == 72">民事</strong>
              <strong v-else="item.catid == 75 || item.catid == 76 || item.catid == 77 || item.catid == 78 || item.catid == 79">行政</strong>
              <time>{{item.create_time}}</time></p>
          </router-link></li>
        </ul>
      </div>
      <div class="anliul">
        <ul>

        	<li v-for="item,index in newanliData"><router-link :to="{path:'/case/'+item.id+'.html'}">
          <span v-if="item.catid == 68 || item.catid == 69 || item.catid == 70 || item.catid == 71 || item.catid == 72">民事</span>
          <span v-else="item.catid == 75 || item.catid == 76 || item.catid == 77 || item.catid == 78 || item.catid == 79">行政</span>
          {{item.title}}</router-link></li>

        </ul>
         <router-link to="/case" class="comlink">查看更多</router-link>
      </div>
    </div>
    <!-- 冠领荣誉 -->
    <div class="rongyu">
      <h2 class="comh2"><strong>冠领荣誉</strong></h2>
      <div class="rongyuimg">
        <p><img src="../assets/ryimg_01.jpg" ></p>
        <p><img src="../assets/ryimg_02.jpg" ></p>
        <p><img src="../assets/ryimg_03.jpg" ><span>法制晚报优秀律师奖</span><span>十大无罪辩护案例</span><span>优秀个人奖</span></p>
      </div>
      <router-link to="/honor" class="comlink">查看更多</router-link>
    </div>
    <!-- 联系我们 -->
    <div class="ours">
       <h2 class="comh2"><strong>联系我们</strong></h2>
       <div class="oursimg">
            <div class="swiper mySwiper ourbox">
               <div class="swiper-wrapper">
                 <div class="swiper-slide"><router-link to="/branch/beijing.html"><img src="../assets/ourimg01.jpg" ><p>北京冠领</p></router-link></div>
                 <div class="swiper-slide"><router-link to="/branch/shanghai.html"><img src="../assets/shanghai.jpg" ><p>上海冠领</p></router-link></div>
                 <div class="swiper-slide"><router-link to="/branch/shenzhen.html"><img src="../assets/shenzhen.jpg" ><p>深圳冠领</p></router-link></div>
                 <div class="swiper-slide"><router-link to="/branch/xian.html"><img src="../assets/xian.jpg" ><p>西安冠领</p></router-link></div>
                 <div class="swiper-slide"><router-link to="/branch/kunming.html"><img src="../assets/kunming.jpg" ><p>昆明冠领</p></router-link></div>
               </div>
               <div class="swiper-button-next"></div>
               <div class="swiper-button-prev"></div>
             </div>
       </div>
    </div>
    <!-- 合作伙伴 -->
    <div class="huoban">
      <h2 class="comh2"><strong>合作伙伴</strong></h2>
      <ul>
      	<li><img src="../assets/hb01.jpg" ></li>
      	<li><img src="../assets/hb02.jpg" ></li>
      	<li><img src="../assets/hb03.jpg" ></li>
      	<li><img src="../assets/hb04.jpg" ></li>
      	<li><img src="../assets/hb05.jpg" ></li>
      	<li><img src="../assets/hb06.jpg" ></li>
      	<li><img src="../assets/hb07.jpg" ></li>
      	<li><img src="../assets/hb08.jpg" ></li>
      	<li><img src="../assets/hb09.jpg" ></li>
      	<li><img src="../assets/hb10.jpg" ></li>
      	<li><img src="../assets/hb11.jpg" ></li>
      	<li><img src="../assets/hb12.jpg" ></li>
      </ul>
    </div>
  </div>
</template>

<script>
import {request} from '../network/request.js'
import GLOBAL from '../global/global.js'
import $ from 'jquery'
import Swiper from 'swiper'
import 'swiper/css/swiper.css'

// import 'swiper/css/swiper.css'

export default {
  name: 'home',
  data(){
    return {
      bannerData:[],
      bannerUrl:[],
      shipinData:[],
      newsData:[],
      lawyerData:[],
      anliData:[],
      newanliData:[],
      yangshinum:33,
      newsid:29,
      bannerID:0
    }
  },
  methods:{
    banner(){
      let that = this
      request({
        url: '/index/banner?id=3',
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          that.bannerData = []
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = jsondata['data'];
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              let thumblength = thumb[17].length
              val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4)
              //ID
              val['url'] = val['url'].split('/')[4]
              // console.log( val['url'] );
              that.bannerData.push(val)
            });
          }
        }]
      })
    },
    yangshihandle(id,lmid){
      let  yangshitabbtn = $('.yangshitab button')
      yangshitabbtn.eq(lmid).addClass('curr').siblings().removeClass('curr')
      $('.yangshiitem').hide(0,function(){
        $('.yangshiitem').fadeIn()
      })
      this.shipin(id)
      if(id == 1){
        this.yangshinum = 33
      }else{
        this.yangshinum = 39
      }
    },
    shipin(id){
      let that = this
      request({
        url: '/index/video?id='+id,
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          // console.log(jsondata);
          that.shipinData = []
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = jsondata['data'];
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              // console.log(thumb);
              let thumblength = thumb[21].length
              val['thumb'] = GLOBAL.httpurl+thumb[21].substr(1,thumblength-4);
              that.shipinData.push(val)
            });
          }
        }]
      })
    },
    newsColor(id,lmid){
      let newstabbtn = $('.newstab button')
      newstabbtn.eq(lmid).addClass('curr').siblings().removeClass('curr')
      $('.newsitem').eq(lmid).fadeIn().siblings().hide()
      this.news(id)
      if(id == 1){
        this.newsid = 29
      }else{
        this.newsid = 50
      }
    },
    news(id){
      let that = this
      request({
        url: '/index/news?id='+id,
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          console.log(jsondata);
          that.newsData = []
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = ''
            if(id == 1){
              newData = jsondata['data'].splice(0,5)
            }else if(id == 2){
              newData = jsondata['data']
            }
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              let thumblength = thumb[17].length
              val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
              val['create_time'] = val['create_time'].split(' ')[0]
              that.newsData.push(val)
            });
          }
        }]
      })
    },
    yaowenhandle(lmid){
      $('.yaowentab button').eq(lmid).addClass('curr').siblings().removeClass('curr')
      $('.yaowenitem').eq(lmid).fadeIn().siblings().hide()
    },
    lawyer(){
      let that = this
      request({
        url: '/index/team',
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          that.lawyerData = []
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = jsondata['data'].splice(0,4)
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              let thumblength = thumb[17].length
              val['thumb'] = 'http://api.guanlingss.com'+thumb[17].substr(1,thumblength-4);
              that.lawyerData.push(val)
            });
          }
        }]
      })
    },
    anli(id){
      let that = this
      request({
        url: '/index/anli',
        responseType: 'json',
        transformResponse:[function(data){
          let jsondata = JSON.parse(data)
          // console.log(jsondata);
          if(jsondata['code'] == 200){
          // alert(jsondata['data']['total'])
            let newData = ''
            if(id == 2){
              that.anliData = []
              newData = jsondata['data'].slice(0,2)
            }else{
              that.newanliData = []
              newData = jsondata['data'].slice(2)
            }

            // console.log(newData);
            newData.forEach(function(val){
              let thumb = val['thumb'].split(':')
              let thumblength = thumb[17].length
              val['thumb'] = GLOBAL.httpurl+thumb[17].substr(1,thumblength-4);
              val['create_time'] = val['create_time'].split(' ')[0]
              if(id == 2){
                that.anliData.push(val)
              }else{
                that.newanliData.push(val)
              }
            });
          }
        }]
      })
    }
  },
  watch:{

  },
  mounted(){
    this.banner()
    this.shipin(1)
    this.news(1)
    this.lawyer()
    this.anli(2)
    this.anli(3)
    setTimeout(function(){
      var swiper = new Swiper(".banbox", {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        autoplay: {
          delay: 5000,
          stopOnLastSlide: false,
          disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        }
      });
    },500)


    setTimeout(function(){
      var swiper = new Swiper(".ourbox", {
        slidesPerView: 3,
        spaceBetween: 10,
        loop: true,
        autoplay: {
          delay: 5000,
          stopOnLastSlide: false,
          disableOnInteraction: false,
        },
        navigation: {
           nextEl: ".swiper-button-next",
           prevEl: ".swiper-button-prev",
        },
      });
    },500)










  }
}
</script>

<style lang="scss" scoped>
  .banner{
    height: 3rem;
  }
  .yangshitab,.newstab,.yaowentab{
    border-bottom: 1px solid #dedede;
    height: .85rem;
    display: flex;
    align-items: center;
    justify-content: space-around;
    button{
      font-size: .3rem;
      font-weight: bold;
      border: none;
      background: transparent;
      cursor: pointer;
      width: 2.45rem;
      position: relative;
      color: #333;
    }
    button.curr::after{
      content: "";
      height: 0.03rem;
      width: 2.45rem;
      position: absolute;
      bottom: -.24rem;
      background: #b80816;
      left: 50%;
      margin-left: -1.225rem;
      color: #333;
    }
  }
  .yewu{
    border-bottom: .2rem solid #f3f3f3;
    ul{
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      margin-top: .15rem;
      a{
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
        align-items: center;
      }
      li::after{
        content: "";
        height: .34rem;
        width: 1px;
        background-color: #dddddd;
        position: absolute;
        right: -.04rem;
        top: 50%;
        margin-top: -.17rem;
      }
      li{
        position: relative;
        width: 1.82rem;
        height: 1.4rem;
        margin-bottom: .02rem;
        // border: 1px solid red;
        div{
          margin-top: .2rem;
        }
        strong{
          font-size: .26rem;
          line-height: 100%;
          margin-top: .16rem;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }
      li:first-child div{
        width: .36rem;
      }
      li:nth-child(4)::after,
      li:nth-child(8)::after{
        background: transparent;
      }
      li:nth-child(6) div{
        margin-top: .3rem;
      }
      li:nth-child(2) div,
      li:nth-child(3) div,
      li:nth-child(4) div,
      li:nth-child(5) div,
      li:nth-child(6) div,
      li:nth-child(7) div,
      li:nth-child(8) div{
        width: .41rem;
      }
    }
  }


  .yangshi{
    border-bottom: .2rem solid #f3f3f3;
    .yangshiwrap{
      margin-top: .35rem;
      .yangshiitem:first-child{
        display: block;
      }
      .yangshiitem{
        display: none;
        .yangshitop{
          width: 6.94rem;
          margin: 0 auto;
          position: relative;
          img{
            height: 4.45rem;
          }
          div{
            height: .7rem;
            display: flex;
            align-items: center;
            font-size: .28rem;
            color: #fff;
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: rgba(0,0,0,.8);
            p{
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
              padding: 0 .2rem;
            }
          }
        }

        ul{
          display: flex;
          justify-content: space-between;
          padding: 0 .25rem;
          margin-top: .24rem;
          li{
            width: 3.37rem;
            p{
              font-size: .28rem;
              line-height: .36rem;
              margin-top: .15rem;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
          }
        }
      }
    }
  }
  .news{
    padding: 0 .2rem;
    border-bottom: .2rem solid #f3f3f3;
    .newswrap{
      .newsitem:first-child{
        display: block;
      }

      .newsitem{
        display: none;
        ul{
          margin-top: .2rem;
          li{
            margin-bottom: .2rem;
            a{
              display: flex;
              justify-content: space-between;
              img{
                width: 1.8rem;
                height: 1.35rem;
              }
              div{
                width: 5.08rem;
                p{
                  font-size: .28rem;
                  line-height: .36rem;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2;
                  overflow: hidden;
                  margin-top: .05rem;
                }
                strong{
                  font-size: .24rem;
                  color: #999999;
                  margin-top: .2rem;
                  display: block;
                }
              }
            }
          }
        }
      }
      .newsitemtwo{
        margin-bottom: .2rem;
        ul{
          li{
            height: 1.4rem;
            border-bottom: 1px dashed #dddddd;
            position: relative;
            margin-bottom: 0;
            p::after{
              content: "";
              width: .06rem;
              height: .06rem;
              background: #b80816;
              border-radius: 50%;
              position: absolute;
              left: 0;
              top: 40%;
            }
            p{
              font-size: .28rem;
              line-height: .4rem;
              margin-top: .2rem;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
              position: relative;
              text-indent: .1rem;
              padding-left: .05rem;
            }
            strong{
              position: absolute;
              right: 0;
              font-size: .24rem;
              bottom: .2rem;
              color: #999;
            }
          }
        }
      }
    }
  }
  .yaowen{
    border-bottom: .2rem solid #f3f3f3;
    padding-bottom: .3rem;
    .yaowenwrap{
      margin-top: .3rem;
      .yaowenitem:first-child{
        display: block;
      }
      .yaowenitem{
        display: none;
        // height: 4.65rem;
        .yaowentop{
          width: 6.96rem;
          border: 1px solid #d9d9d9;
          margin: 0 auto;
          height: 4.47rem;
          background: #000000;
          video{
            width: 6.96rem;
            height: 4.47rem;
          }
        }
      }
      .yaowenzt{
        display: none;
        margin: 0 .2rem;
        ul{
          display: flex;
          flex-wrap: wrap;
          justify-content: space-between;
          li:nth-child(n+3){
            margin-bottom: 0;
          }
          li{
            width: 3.45rem;
            height: 1.5rem;
            margin-bottom: .2rem;
          }
        }
      }
    }
  }
  .redbox{
    margin: .2rem .2rem 0;
    ul{
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      li:nth-child(n+9){
        margin-bottom: 0;
      }
      li{
        width: 1.08rem;
        height: 1.08rem;
        background-color: #9f2728;
        margin-bottom: .12rem;
        border: 1px solid #fca2a2;
        box-sizing: border-box;
        box-shadow: inset 0 0 .08rem #b35556;
        background-size: 100%;
        a{
          display: block;
          height: 100%;
          width: 100%;
        }
      }
      li:nth-child(2),
      li:nth-child(4),
      li:nth-child(5),
      li:nth-child(7),
      li:nth-child(11),
      li:nth-child(12){
        width: 2.28rem;
      }
      li:nth-child(2){
        background-image: url(../assets/lsll.jpg);
      }
      li:nth-child(3){
        background-image: url(../assets/yasf.jpg);
      }
      li:nth-child(4){
        background-image: url(../assets/lsmz.jpg);
      }
      li:nth-child(5){
        background-image: url(../assets/dstjs.jpg);
      }
      li:nth-child(7){
        background-image: url(../assets/fljt.jpg);
      }
      li:nth-child(9){
        background-image: url(../assets/jsny.jpg);
      }
      li:nth-child(11){
        background-image: url(../assets/fzjxs.jpg);
      }
      // li:nth-child(12){
      //   background-image: url(../assets/dstjs.jpg);
      // }
    }
  }

  .lawyer{
    border-bottom: .2rem solid #f3f3f3;
    .zhurenbox{
      margin: .3rem .2rem 0;
      .zhurenwrap{
        display: flex;
        margin-bottom: .2rem;
        a{
          display: flex;
        }
        .zhurenl,img{
          width: 2.05rem;
          height: 2.53rem;
        }
        .zhurenr{
          margin-left: .24rem;
          h2{
            margin-top: .08rem;
            display: flex;
            align-items: flex-end;
          }
          p{
            font-size: .28rem;
            line-height: .36rem;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 5;
            overflow: hidden;
            margin-top: .1rem;
          }
          strong{
            font-size: .32rem;
            font-weight: bold;
          }
          small{
            font-weight: normal;
            font-size: .24rem;
            display: inline-block;
            margin-left: .06rem;
            margin-right: .15rem;
          }
          span{
            font-size: .24rem;
            font-weight: normal;
            width: 1.65rem;
            height: .33rem;
            display: inline-block;
            color: #fff;
            background: linear-gradient(to right, #bf1a26,#ee3b19);
            border-radius: .05rem;
            text-align: center;
            min-width: 95px;
            min-height: 16px;
          }

        }
      }
    }
    .lawyerlist{
      margin: .1rem .2rem 0;
      ul{
        display: flex;
        justify-content: space-between;
        li{
          width: 1.63rem;
          position: relative;
          p{
            position: absolute;
            bottom: 0;
            left: 0;
            height: .38rem;
            line-height: .38rem;
            font-size: .24rem;
            text-align: center;
            width: 100%;
            background-color: #b80816;
            color: #fff;
          }
        }
      }
    }
  }
  .anli{
    border-bottom: .2rem solid #f3f3f3;
    .anlituwen{
      margin: .3rem .2rem 0;
      ul{
        display: flex;
        justify-content: space-between;
        li{
          width: 3.45rem;
          border: 1px solid #e5e5e5;
          padding-bottom: .2rem;
          p{
            font-size: .28rem;
            color: #333333;
            line-height: .4rem;
            margin: 0 .15rem;
          }
          p:nth-of-type(1){
            margin-top: .12rem;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
          }
          p:nth-of-type(2){
            color: #b6b6b6;
            display: flex;
            justify-content: space-between;
            margin-top: .1rem;
          }
        }
      }
    }
    .anliul{
      margin: .3rem .2rem 0;
      ul{
        li:last-child{
          border-bottom: 1px solid #e5e5e5;
        }
        li{
          border-top: 1px solid #e5e5e5;
          padding: .18rem 0;
          a{
            // font-size: 33px;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
            width: 100%;
            font-size: .28rem;
            line-height: .4rem;
            span{
              color: #999999;
              width: .74rem;
              display: inline-block;
              position: relative;
              margin-right: .06rem;
            }
            span::after{
              content: "";
              width: 1px;
              height: .26rem;
              background: #333;
              position: absolute;
              right: .01rem;
              top: 50%;
              margin-top: -.12rem;
            }
          }
        }
      }
    }
  }
  .rongyu{
    border-bottom: .2rem solid #f3f3f3;
    .rongyuimg{
      margin: .3rem .2rem 0;
      p{
        position: relative;
        span{
          position: absolute;
          bottom: -.02rem;
          color: #fff;
          font-size: .22rem;
          height: .4rem;
          width: 2.25rem;
          text-align: center;
          display: flex;
          justify-content: center;
          align-items: center;
        }
        span:nth-of-type(2){
          left: 50%;
          margin-left: -1.15rem;
        }
        span:nth-of-type(3){
          right: 0;
        }
      }
    }
  }
  .ours{
    padding-bottom: .3rem;
    border-bottom: .2rem solid #f3f3f3;
    .oursimg{
      margin: .3rem .52rem 0;
      height: 2rem;
      position: relative;
      .swiper{
        // width: 6.47rem;
      }
      .swiper-button-prev, .swiper-button-next{
        background: #fff;
        height: 3rem;
        top: 0;
        width: .5rem;
      }
      .swiper-button-prev{
        left: -.52rem;
      }
      .swiper-button-next{
        right: -.52rem;
      }
       .swiper-button-prev::after{
         background-image: url(../assets/ourleft.jpg);
       }
       .swiper-button-next::after{
         background-image: url(../assets/ourright.jpg);
       }
       .swiper-button-prev:hover::after{
         background-image: url(../assets/ourleft-s.jpg);
       }
       .swiper-button-next:hover::after{
         background-image: url(../assets/ourright-s.jpg);
       }
       .swiper-button-prev::after, .swiper-button-next::after{
          content: "";
          width: .16rem;
          height: .3rem;
          background-repeat: no-repeat;
          background-size: .16rem .3rem;
          position: absolute;
          top: 32%;
       }
      img{
        width: 2.05rem;
      }
      p{
        text-align: center;
        font-size: .28rem;
        margin-top: .12rem;
      }
    }
  }
  .huoban{
    margin-bottom: .2rem;
    ul{
      margin: .3rem .2rem 0;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      li{
        width: 1.7rem;
        height: .55rem;
        margin-bottom: .2rem;
      }
    }
  }



</style>
