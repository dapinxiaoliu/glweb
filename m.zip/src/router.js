import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import Yewu from './views/Yewu.vue'
import Minshi from './views/zt/yewu/Minshi.vue'
import Gongsi from './views/zt/yewu/Gongsi.vue'
import Zhishi from './views/zt/yewu/Zhishi.vue'
import Shewai from './views/zt/yewu/Shewai.vue'
import Zhaobiao from './views/zt/yewu/Zhaobiao.vue'
import Xingzheng from './views/zt/yewu/Xingzheng.vue'
import Xingshi from './views/zt/yewu/Xingshi.vue'
import Jiaotong from './views/zt/yewu/Jiaotong.vue'
import Shangshi from './views/zt/yewu/Shangshi.vue'
import Branch from './views/Branch.vue'
import Beijing from './views/zt/branch/Beijing.vue'
import Shanghai from './views/zt/branch/Shanghai.vue'
import Shenzhen from './views/zt/branch/Shenzhen.vue'
import Xian from './views/zt/branch/XIan.vue'
import Kunming from './views/zt/branch/kunming.vue'
import Tv from './views/Tv.vue'
import Tvmedia from './views/Tvmedia.vue'
import Anli from './views/Anli.vue'
import Article from './views/Article.vue'
import News from './views/News.vue'
import Team from './views/Team.vue'
import Teamarc from './views/Teamarc.vue'
import Notice from './views/Notice.vue'
import Honor from './views/Honor.vue'

import CaifuView from './views/zt/zt/CaifuView.vue'


Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/yewu',
      name: 'yewu',
      component: Yewu
    },
    {
      path: '/yewu/minshi(.*)',
      name: 'minshi',
      component: Minshi,
      meta:{ parent: [ {path: 'yewu', name: '民事诉讼'}]}
    },
    {
      path: '/yewu/gongsi(.*)',
      name: 'gongsi',
      component: Gongsi,
      meta:{ parent: [ {path: 'yewu', name: '公司诉讼'}]}
    },
    {
      path: '/yewu/zhishi(.*)',
      name: 'zhishi',
      component: Zhishi,
      meta:{ parent: [ {path: 'yewu', name: '知识产权诉讼'}]}
    },
    {
      path: '/yewu/shewai(.*)',
      name: 'shewai',
      component: Shewai,
      meta:{ parent: [ {path: 'yewu', name: '涉外业务'}]}
    },
    {
      path: '/yewu/zhaobiao(.*)',
      name: 'zhaobiao',
      component: Zhaobiao,
      meta:{ parent: [ {path: 'yewu', name: '招投标业务'}]}
    },
    {
      path: '/yewu/xingzheng(.*)',
      name: 'xingzheng',
      component: Xingzheng,
      meta:{ parent: [ {path: 'yewu', name: '行政诉讼'}]}
    },
    {
      path: '/yewu/xingshi(.*)',
      name: 'xingshi',
      component: Xingshi,
      meta:{ parent: [ {path: 'yewu', name: '刑事诉讼'}]}
    },
    {
      path: '/yewu/jiaotong(.*)',
      name: 'jiaotong',
      component: Jiaotong,
      meta:{ parent: [ {path: 'yewu', name: '交通事故诉讼'}]}
    },
    {
      path: '/yewu/shangshi(.*)',
      name: 'shangshi',
      component: Shangshi,
      meta:{ parent: [ {path: 'yewu', name: '商事业务'}]}
    },
    {
      path: '/branch',
      name: 'branch',
      component: Branch
    },
    {
      path: '/branch/beijing(.*)',
      name: 'beijing',
      component: Beijing,
      meta:{ parent: [ {path: 'branch', name: '冠领机构'}]}
    },
    {
      path: '/branch/shanghai(.*)',
      name: 'shanghai',
      component: Shanghai,
      meta:{ parent: [ {path: 'branch', name: '冠领机构'}]}
    },
    {
      path: '/branch/shenzhen(.*)',
      name: 'shenzhen',
      component: Shenzhen,
      meta:{ parent: [ {path: 'branch', name: '冠领机构'}]}
    },
    {
      path: '/branch/xian(.*)',
      name: 'xian',
      component: Xian,
      meta:{ parent: [ {path: 'branch', name: '冠领机构'}]}
    },
    {
      path: '/branch/kunming(.*)',
      name: 'kunming',
      component: Kunming,
      meta:{ parent: [ {path: 'branch', name: '冠领机构'}]}
    },
    {
      path: '/tv',
      name: 'tv',
      component: Tv
    },
    {
      path: '/tv/:id(.*)',
      name: 'tvmedia',
      component: Tvmedia,
      meta:{ parent: [ {path: 'tv', name: '冠领央视'}]}
    },
    {
      path: '/case',
      name: 'case',
      component: Anli
    },
    {
      path: '/case/:id(.*)',
      name: 'casehtml',
      component: Article,
      meta:{ parent: [ {path: 'case', name: '胜诉案例'}]}
    },
    {
      path: '/newslist',
      name: 'newslist',
      component: News
    },
    {
      path: '/newslist/:id(.*)',
      name: 'newslisthtml',
      component: Article,
      meta:{ parent: [ {path: 'newslist', name: '新闻动态'}]}
    },
    {
      path: '/lawyer',
      name: 'lawyer',
      component: Team
    },
    {
      path: '/lawyer/:id(.*)',
      name: 'lawyerhtml',
      component: Teamarc,
      meta:{ parent: [ {path: 'lawyer', name: '律师团队'}]}
    },
    {
      path: '/notice',
      name: 'notice',
      component: Notice
    },
    {
      path: '/notice/:id(.*)',
      name: 'noticehtml',
      component: Article,
      meta:{ parent: [ {path: 'notice', name: '冠领公告'}]}
    },
    {
      path: '/honor',
      name: 'honor',
      component: Honor
    },
    {
      path: '/honor/:id(.*)',
      name: 'honorhtml',
      component: Article,
      meta:{ parent: [ {path: 'honor', name: '冠领荣誉'}]}
    },
    {
      path: '/about/:id(.*)',
      name: 'about',
      component: Article,
      meta:{ parent: [ {path: '/', name: '北京冠领律师事务所'}]}
    },
    {
      path: '/caifu/:id(.*)',
      name: 'caifu',
      component: CaifuView
    },
  ]
})
