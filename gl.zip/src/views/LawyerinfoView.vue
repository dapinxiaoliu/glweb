<template>
  <div class="yangshiinfo">
    <div class="ban"></div>
    <div class="yangshiinfobox w1200">
      <div class="yangshiinfowrap">
        <div class="minabao"><router-link to="/">首页</router-link>&nbsp;>&nbsp;<router-link to="/">冠领公告&nbsp;>&nbsp;</router-link>某一篇文章</div>
        <div class="lawyerbox">
          <div class="lawyerboxl"><img src="../assets/zhouxuliang.jpg" ></div>
          <div class="lawyerboxr">
            <strong>周旭亮</strong>
            <div><em>创始合伙人</em><em>主任律师</em></div>
            <div class="lawintro">
              <b>律师简介：</b>
              <p>专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专域描述专业领域描述专业领域描述专业领域描述专域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业</p>
            </div>
            <div class="lawintro">
              <b>专业领域：</b>
              <p>专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专域描述专业领域描述专业领域描述专业领域描述专域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业领域描述专业</p>
            </div>
            <div class="chatbtn">
              <a href="">在线咨询</a>
              <a href="">咨询电话：400-8789-888</a>
            </div>
          </div>
        </div>
        <div class="lineintro"><strong>详细简介</strong></div>
        <!-- <h2 class="yangshititle">华为申请鸿蒙商标，反遭网友吐槽！商标使用引争议？</h2> -->
<!--        <div class="yangshitype">
          <div>文章来源： 北京冠领律师事务所</div>
          <div>阅读：14</div>
          <div>发布时间： 2021-03-24 17:00:21</div>
          <div>字体： 【<em class="bigfont">大</em> <em class="midfont">中</em> <em class="smfont">小</em>】</div>
        </div> -->
        <div class="yangshicontent">
          <p>此事最大的争议，是鸿蒙教育申请的商标名是“鸿蒙”，在实际使用中却用的是“鸿蒙教育”，此商标到底是属于“商标使用不规范”，还是属于“没有真实有效使用”。</p> <p>很显然，如果认定为没有真实有效使用，那么该商标就符合“撤三”的相关规定，撤销将无法避免。</p> <p>有网友猜测契贝科技申请商标撤销，或许与华为有关，此前，契贝科技曾向华为公司转让了“鸿蒙操作系统”、 “鸿蒙OS”等10个商标，而这家公司准备注册的“鸿蒙”也将转让给华为，他们认为鸿蒙系统即将面世，华为很有可能要将其他鸿蒙品牌收为己有，以防商誉受损。</p> <p>也有网友认为可能是其他企业想借鸿蒙热度，趁机碰瓷博热度，该事件应与华为无关。</p> <p>对此，华为相关人员未做直接回应。</p> <p>品牌注册大有学问</p> <p>《商标法》中规定：“注册商标的专用权，以核准注册的商标和核定使用的商品为限。”企业在注册商标时，不仅需要考虑相关类别，也要根据实际使用需要注册商标，如果在后期使用时有修改，一定要及时提交商标注册，否则，很有可能面临被撤销或侵权的风险。</p>
 <p>有网友猜测契贝科技申请商标撤销，或许与华为有关，此前，契贝科技曾向华为公司转让了“鸿蒙操作系统”、 “鸿蒙OS”等10个商标，而这家公司准备注册的“鸿蒙”也将转让给华为，他们认为鸿蒙系统即将面世，华为很有可能要将其他鸿蒙品牌收为己有，以防商誉受损。</p>
 <p>也有网友认为可能是其他企业想借鸿蒙热度，趁机碰瓷博热度，该事件应与华为无关。</p>
 <p>对此，华为相关人员未做直接回应。</p>

 <p>品牌注册大有学问</p>
 <p>《商标法》中规定：“注册商标的专用权，以核准注册的商标和核定使用的商品为限。”企业在注册商标时，不仅需要考虑相关类别，也要根据实际使用需要注册商标，如果在后期使用时有修改，一定要及时提交商标注册，否则，很有可能面临被撤销或侵权的风险。</p>
 <p>有网友猜测契贝科技申请商标撤销，或许与华为有关，此前，契贝科技曾向华为公司转让了“鸿蒙操作系统”、 “鸿蒙OS”等10个商标，而这家公司准备注册的“鸿蒙”也将转让给华为，他们认为鸿蒙系统即将面世，华为很有可能要将其他鸿蒙品牌收为己有，以防商誉受损。</p>
 <p>也有网友认为可能是其他企业想借鸿蒙热度，趁机碰瓷博热度，该事件应与华为无关。</p>
 <p>对此，华为相关人员未做直接回应。</p>

 <p>品牌注册大有学问</p>
 <p>《商标法》中规定：“注册商标的专用权，以核准注册的商标和核定使用的商品为限。”企业在注册商标时，不仅需要考虑相关类别，也要根据实际使用需要注册商标，如果在后期使用时有修改，一定要及时提交商标注册，否则，很有可能面临被撤销或侵权的风险。</p>

        </div>
 <!--       <div class="prenext">
          <router-link to="">上一篇：富安娜家居两日内新增5起开庭 案由均系商标权权属纠纷</router-link>
          <router-link to="">下一篇：富安娜家居两日内新增5起开庭</router-link>
        </div> -->
      </div>
    </div>
    <div class="yewuline"><img src="../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  export default {
    name: 'LawyerinfoView',
    data(){
      return {}
    },
    mounted(){
      $(".chonggou a").attr('class','')
      if(this.$route.name == 'lawinfo'){
        $(".chonggou a[href='/lawyer']").attr('class','router-link-active')
      }

      let fontem = $('.yangshitype em')
      let bigfont = $('.bigfont')
      let midfont = $('.midfont')
      let smfont = $('.smfont')
      let yangshicontent = $('.yangshicontent p')
      bigfont.click(function(){
        fontem.css('color','#666666')
        $(this).css('color','#b80816')
        yangshicontent.animate({'font-size':'18px','line-height':'30px'})
      })
      midfont.click(function(){
        fontem.css('color','#666666')
        $(this).css('color','#b80816')
        yangshicontent.animate({'font-size':'16px','line-height':'28px'})
      })
      smfont.click(function(){
        fontem.css('color','#666666')
        $(this).css('color','#b80816')
        yangshicontent.animate({'font-size':'14px','line-height':'24px'})
      })
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .lineintro{
    background: url(../assets/lawlinebg.jpg) repeat-x left center;
    width: 1080px;
    margin: 40px auto 40px;
    strong{
      font-size: 24px;
      font-weight: bold;
      color: #666666;
      background: #fff;
      width: 152px;
      display: block;
      text-align: center;
      margin: 0 auto;
    }
  }
  .lawyerbox{
    display: flex;
    width: 1080px;
    margin: 40px auto 0;
    .lawyerboxl{
      margin-right: 36px;
    }
    .lawyerboxr{
      font-size: 18px;
      color: #666;
      strong{
        font-size: 25px;
        font-weight: bold;
        color: #333;
        line-height: 100%;
        margin-top: 15px;
        margin-bottom: 17px;
        display: block;
      }
      em{
        padding: 0 10px;
        height: 30px;
        line-height: 30px;
        display: inline-block;
        background: #e5e5e5;
        margin-right: 10px;
        border-radius: 5px;
      }
      .lawintro{
        display: flex;
        margin-top: 20px;
        b{
          width: 90px;
          font-weight: bold;
          margin-top: 2px;
        }
        p{
          flex: 1;
          line-height: 28px;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          overflow: hidden;
        }
      }
      .chatbtn{
        margin-top: 70px;
        a:hover{
          background-color: #b80816;
          color: #fff !important;
          background-image: url(../assets/lawchat-s.png);
        }
        a:nth-child(1):Hover{
          background-image: url(../assets/lawchat-s.png);
        }
        a:nth-child(2):Hover{
          background-image: url(../assets/dianhua-s.png);
        }
        a{
          border: 1px solid #b80816;
          font-size: 18px;
          color: #b80816;
          height: 45px;
          line-height: 45px;
          display: inline-block;
          width: 160px;
          background-repeat: no-repeat;
          background-position: 30px center;
          padding-left: 55px;
          box-sizing: border-box;
          margin-right: 20px;
        }
        a:nth-child(1){
          background-image: url(../assets/lawchat.png);
        }
        a:nth-child(2){
          width: 300px;
          background-image: url(../assets/dianhua-r.png);
        }
        a:nth-child(3){
          background-image: url(../assets/lawchat.png);
        }
      }
    }

  }
  .prenext{
    display: flex;
    justify-content: space-between;
    font-size: 18px;
    height: 45px;
    align-items: center;
    border-top: 1px dashed #e5e5e5;
    margin: 0 auto;
    width: 1080px;
  }
  .prenext a{
    color: #666666;
    display: block;
    white-space: nowrap;
  }
  .yangshiinfo{
    .ban{
      background-image: url(../assets/lvshiban.jpg);

    }
    .yangshiinfobox{
      background: #fff;
      .yangshiinfowrap{
        position: relative;
        width: 100%;
        background: #fff;
        margin-top: -218px;
        z-index: 99;
        box-shadow: 0 0 8px #dfdddd;
        padding-bottom: 30px;
        border: 1px solid transparent;
        .minabao{
          margin: 30px 60px 0;
          padding-bottom: 20px;
        }
        h2.yangshititle{
          text-align: center;
          margin-top: 35px;
          font-size: 20px;
        }
        .yangshitype{
          display: flex;
          border-bottom: 1px dashed #e5e5e5;
          font-size: 16px;
          color: #666666;
          margin: 30px 40px 0;
          padding-bottom: 14px;
          justify-content: center;
          margin-bottom: 26px;
          div:last-child{
            margin-right: 0;
          }
          div{
            margin-right: 50px;
            em{
               cursor: pointer;
            }
            em:nth-child(2){
              color: #b80816;
            }
          }
        }
        .yangshicontent{
          margin: 0 60px;
          padding-bottom: 10px;
          p{
            font-size: 16px;
            color: #666666;
            line-height: 27px;
            text-indent: 2em;
            margin-bottom: 18px;
          }

        }
      }
    }
  }
</style>
