<template>
  <div class="yewuzt">
    <div class="comban">
      <img src="../../../assets/yewuban.jpg" >
      <div>
        <strong>行政诉讼</strong><p>全球咨询热线：400-8787-888</p>
      </div>
    </div>
    <div class="yewuztwrap">
     <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
        </el-breadcrumb>
      </div>

      <div class="yewuinfo">
        <div class="m20">
          <strong>行政诉讼</strong>
          <div class="yewuslide">
            <div class="yewuheight">
              <p>以民商事法律所调整的社会关系为内容的案件或纠纷，都在民商事诉讼的涉及范畴内。</p>
              <p>冠领律师事务所素有“诉讼大所”之称，民商诉讼业务部是冠领律所大部门之一，也是一支以转职法官和资深律师为核心的“专家派”、“技术派”律师团队。</p>

 <p>冠领民商诉讼部拥有律师五十多名，其中法学硕士25人、法学博士6人，20余位律师执业十年以上，其中有多名民商事审判背景的法官顾问、从事法学教育从事从事法的专家...</p> <p>冠领民商诉讼部拥有律师五十多名，其中法学硕士25人、法学博士6人，20余位律师执业十年以上，其中有多名民商事审判背景的法官顾问、从事法学教育从事从事法的专家...</p>
              <p>冠领律师事务所素有“诉讼大所”之称，民商诉讼业务部是冠领律所大部门之一，也是一支以转职法官和资深律师为核心的“专家派”、“技术派”律师团队。</p>
              <p>冠领律师事务所素有“诉讼大所”之称，民商诉讼业务部是冠领律所大部门之一，也是一支以转职法官和资深律师为核心的“专家派”、“技术派”律师团队。</p>
              <p>冠领民商诉讼部拥有律师五十多名，其中法学硕士25人、法学博士6人，20余位律师执业十年以上，其中有多名民商事审判背景的法官顾问、从事法学教育从事法的专家...  </p>
            </div>
          </div>
          <button class="clickmore">点击查看更多</button>
        </div>
      </div>
      <div class="yewulingyu">
        <div>
          <h2 class="comh2"><strong>业务领域</strong></h2>
          <ul class="m20">
          	<li v-for="item,index in lmdata['child']" :key="index" @click="setColor(index)" :class="{curr: index==initnum}">{{item.name}}</li>
          </ul>
          <div class="lingyuinfo m20">
            <div class="lingyuinfoitem">
              <strong>诉征收决定</strong>
              <p>{{a['description']}}</p>
            </div>
            <div class="lingyuinfoitem">
              <strong>诉强拆违法</strong>
              <p>{{b['description']}}</p>
            </div>
            <div class="lingyuinfoitem">
               <strong>诉征收补偿决定</strong>
               <p>{{c['description']}}</p>
            </div>
            <div class="lingyuinfoitem">
              <strong>行政赔偿</strong>
              <p>{{d['description']}}</p>
            </div>
            <div class="lingyuinfoitem">
              <strong>环保关停</strong>
              <p>{{e['description']}}</p>
            </div>
          </div>
        </div>

      </div>
      <!-- 经典案例 -->
      <div class="anli">
        <h2 class="comh2"><strong>经典案例</strong></h2>
        <ul class="m20">
        	<li v-for="item,index in anlidata" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
        </ul>
        <router-link to="/case/" class="comlink">查看更多</router-link>
      </div>

    </div>

  </div>
</template>

<script>
  import {request} from '../../../network/request.js'
  import GLOBAL from '../../../global/global.js'
  import $ from 'jquery'
  export default {
    name:'Xingzheng',
    data(){
      return{
        breadcrumbList:[],
        lmdata:[],
        anlidata:[],
        lmname:'',
        initnum:0,
        a:[],
        b:[],
        c:[],
        d:[],
        e:[],
        lmid:0
      }
    },
    methods:{
      setColor(index){
        this.initnum = index
        let lingyuinfoitem = $('.lingyuinfoitem')
        lingyuinfoitem.eq(index).fadeIn(200).siblings().hide()

      },
      getlitinfo(id){
        let that = this
        request({
          url: '/lingyu/read?id='+id,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lanmuname = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                switch(id){
                  case 100:
                  that.a = jsondata['data']
                  break;
                  case 101:
                  that.b = jsondata['data']
                  break;
                  case 102:
                  that.c = jsondata['data']
                  break;
                  case 103:
                  that.d = jsondata['data']
                  break;
                  case 104:
                  that.e = jsondata['data']
                  break;
                }
              }
            }
          }]
        })
      },
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lmdata = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                 that.lmdata = newData[1]
                 that.lmname = newData[1]['name']
                 newData[1]['child'].forEach(function(val){
                    if(val['id'] == that.lmid){
                        that.nowname = val['name']
                    }
                 })
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getanliData(){
        let that = this
        request({
          url: '/lingyu/lyanli?id=6',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.anlidata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.anlidata = jsondata['data'];
                 // console.log(newData[0]);
              }
            }
          }]
        })
      }
    },
    mounted() {
      let that = this
      this.getlmData()
      this.getanliData()
      this.getlitinfo(100)
      this.getlitinfo(101)
      this.getlitinfo(102)
      this.getlitinfo(103)
      this.getlitinfo(104)

      //获取id
      let lanmuid = this.$route.query['id']
      if(lanmuid != undefined){
          that.lmid = lanmuid
          switch(lanmuid){
            case '100':
            that.initnum = 0
            break;
            case '101':
            that.initnum = 1
            break;
            case '102':
            that.initnum = 2
            break;
            case '103':
            that.initnum = 3
            break;
            case '104':
            that.initnum = 4
            break;
          }
          // alert($('.yewulingyu').offset().top)
          let lingyuinfoitem = $('.lingyuinfoitem')
          lingyuinfoitem.eq(that.initnum).fadeIn(200).siblings().hide()
          $('body,html').animate({
              scrollTop: $('.yewulingyu').offset().top
          },500);
      }else{
        that.current = 0
      }

      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'xingzheng'){
          $(".chonggou a[href$='/yewu']").attr('class','router-link-active')
        }
      })


      let clickmore = $('.clickmore');
      let yewuslide = $('.yewuslide')
      let h = $('.yewuheight').outerHeight()
      let is = 0
      clickmore.click(function(){
        if(is == 0){
          $(this).html('点击收起更多')
          yewuslide.animate({
            height: h
          })
          is = 1
        }else{
          $(this).html('点击查看更多')
          yewuslide.animate({
            height: '3.5rem'
          })
          is = 0
        }
      })

    }
  }
</script>

<style lang="scss" scoped="scoped">
  .lingyuinfoitem:first-child{
    display: block;
  }
  .lingyuinfoitem{
    display: none;
  }
  .yewuzt{
    .yewuztwrap{
      border-top: .2rem solid #f3f3f3;
      .yewuinfo{
         border-bottom: .2rem solid #f3f3f3;
         padding-bottom: .3rem;
        strong{
          font-size: .26rem;
          font-weight: bold;
          display: block;
          border-bottom: 1px solid #dedede;
          width: 3.8rem;
          margin: .35rem auto .2rem;
          text-align: center;
          padding-bottom: .18rem;
        }
        .yewuslide{
          height: 3.5rem;
          overflow: hidden;
          .yewuheight{
            padding-bottom: .2rem;
          }
          p{
            font-size: .24rem;
            line-height: .36rem;
            margin-top: .22rem;
            text-indent: .5rem;
          }
        }
        button.clickmore{
          cursor: pointer;
          font-size: .24rem;
          color: #b80816;
          display: inline-block;
          float: right;
          margin-top: -.3rem;
          position: relative;
          z-index: 99;
          line-height: 100%;
        }
      }
      .yewulingyu{
        border-bottom: .2rem solid #f3f3f3;
        ul{
          display: flex;
          flex-wrap: wrap;
          justify-content: flex-start;
          margin-top: .3rem;
          li{
            height: .5rem;
            padding: 0 .12rem;
            background: #eeeeee;
            text-align: center;
            line-height: .5rem;
            color: #666666;
            margin-bottom: .2rem;
            font-size: .24rem;
            cursor: pointer;
            margin-right: .12rem;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
          }
          li.curr{
            background: #b80816;
            color: #fff
          }

        }
        .lingyuinfo{
          border-top: 1px solid #dedede;
          margin-top: .1rem;
          padding-top: .25rem;
          padding-bottom: .2rem;
          strong{
            font-size: .26rem;
            color: #333333;
            position: relative;
            height: .4rem;
            line-height: .4rem;
            text-indent: .16rem;
            display: block;
            margin-left: 2em;
          }
          strong::after{
            content:"";
            position: absolute;
            left: 0;
            top: .08rem;
            width: .06rem;
            height: .25rem;
            background: #b80816;
          }
          p{
            font-size: .24rem;
            color: #666;
            line-height: .36rem;
            margin-top: .16rem;
            text-indent: 2em;
          }
        }
      }
      .anli{
        ul{
          li{
            line-height: .36rem;
            padding: .2rem 0;
            border-bottom: 1px solid #e5e5e5;

            a{
              color:#333;
              font-size: .24rem;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 2;
              overflow: hidden;
            }
          }
        }
      }
    }
  }
</style>
