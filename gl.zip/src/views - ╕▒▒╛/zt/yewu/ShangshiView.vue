<template>
  <div class="yewuinfo">
    <div class="linebanbox">
      <img src="../../../assets/yewuinfoline.jpg" class="autoc">
      <div class="linebanhead">
        <strong>商事业务</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="yewuwrap w1200">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
          <el-breadcrumb-item>{{nowname}}</el-breadcrumb-item>

        </el-breadcrumb>
      </div>
      <div class="yewuintro">
        <div class="yewuintrol">
          <h2>商事业务</h2>
          <div class="yewuintrowrap">
            <div class="yewuintrowraph">

            <p>商事业务包括大量的商事单行法，公司法、证券法、票据法、保险法等相关的案件。商事业务北京冠领律师事务所专门设立了从事商事纠纷解决的专业律师团队，该团队提供日常法律顾问和商事纠纷解决法律服务。</p>
            <p>北京冠领律师事务所深知“法律乃知识与经验之结合”的深刻道理，律所成员既有来自北京大学、清华大学、中国人民大学、中国政法大学等顶尖高校的饱学之士，更有长期奋战在法律实务一线，功底深厚、身经百战的“ 律界老将”。</p>
            <p>商事业务调整商事法律关系，包括商事财产法律关系和商事人身法律关系两大类。</p>
            <p>第一，商事财产法律关系，包括内部商事财产经营法律关系（如合伙经营法律关系、投资股份法律关系）和外部财产交易法律关系（如商事买卖合同法律关系、股票交易法律关系）。</p>
            <p>第二，商事人身法律关系，包括商事营业主体内部组织管理法律关系（如公司内部的组织管理法律关系，分支公司与本公司的法律关系）和商事营业主体之间的人身权法律关系（如商业名称法律关系、商誉权法律关系）。</p>
            <p>商事业务涉及的法律包括以下几类主要内容：</p>
            <p>（一）组织规范与交易规范</p>
            <p>大体上可以说，在商事业务涉及的六门法律中，公司法、合伙企业法、破产法属于商事组织法，票据法、证券法和保险法属于商事交易法。</p>
            <p>（二）强制性规范与任意性规范</p>
            <p>商事业务中法律的强制性规范：任何一种法律制度，都必须在稳定性、一致性和灵活性3者之间取得平衡。要求法律具有超越时空的一致性和稳定性的理由是显而易见的。这样可以提高效益、降低成本、保证安全。</p>
            <p>另一方面，除了强制性规范外，任意性规范的作用也是重要的。为了提高经济效率，商法又必须本着自由原则，设立任意性规范以保留意思自治的足够空间。在商事法律中，自由原则主要体现为法律中直接的任意性条款，包括授权性和选择性的条款。</p>
            <p>（三）实体规范与程序规范</p>
            <p>商法中的实体规范主要是有关权利、义务、责任、条件、限制和行为方式的规定。有些商事法律也包括了程序性的规定。</p>
            <p>“唯思将来也，故生希望心”北京冠领律师事务所在团队管理上以“时刻保持强烈的进取精神和忧患意识”为原则，面向未来，倾听不同意见，不断完善自我。强化政治品格的训练与道德品质的修养，廉洁自律，持续学习，保持“进取、日新、破格”。北京冠领律师事务所坚持“以胜诉求共赢——法庭上争胜诉，法庭下谋共赢”的办案理念，以规模化、专业化、品牌化、国际化的优势，为当事人提供优质、高效的法律服务。成功办理了大量行政纠纷、公司法律纠纷、房产纠纷、合同纠纷、侵权纠纷、刑事纠纷等案件，赢得了企事业单位、社会组织、老百姓的广泛好评和持久信任。</p>

            </div>
          </div>

          <router-link to="" class="morelink">查看更多></router-link>
        </div>
        <div class="yewuintror">
          <router-link to="/lawyer/">
            <img src="../../../assets/yewuxgtd.jpg" >
            <strong><router-link to="/lawyer/">相关团队</router-link></strong>
          </router-link>
        </div>
      </div>

    </div>

    <div class="yewurun">
      <strong>商事业务</strong>
      <div class="yewurunbox w1200">
        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide swiperbtn" v-for="item,index in lmdata['child']" :key="index" >{{item.name}}</div>
          </div>
        </div>
        <div thumbsSlider="" class="swiper mySwiper2">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>企业法律顾问</h3>
               <p>{{a['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>个人法律顾问</h3>
                <p>{{b['description']}}</p>
              </div>
            </div>

          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
    <!-- 经典案例 -->
    <div class="jdal w1200">
      <strong>经典案例</strong>
      <div class="jdalwrap">
        <div class="jdalwrapbox">
          <ul>
          	<li v-for="item,index in anlidata" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
          </ul>
          <router-link to="/case/" class="morelink">查看更多></router-link>
        </div>
        <img src="../../../assets/anliimg.jpg" >
      </div>
    </div>

    <!-- 相关新闻 -->
    <div class="aboutnew">
      <div class="aboutnewwrap w1200">
        <strong>相关新闻</strong>
        <div class="aboutnewbox">
          <div class="aboutnewzw">
            <div class="aboutnewl"><img src="../../../assets/newleft.jpg" ></div>
            <ul>
            	<li v-for="item,index in newsdata" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">{{item.title}}</router-link><span>{{item.create_time}}</span></li>
            </ul>
          </div>
          <router-link to="/newslist/" class="morelink">查看更多></router-link>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../../../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  import {request} from '../../../network/request.js'
  import GLOBAL from '../../../global/global.js'
  export default{
    name: 'ZhaobiaoView',
    data(){
      return{
        breadcrumbList:[],
        lmdata:[],
        lmname:'',
        nowname:'',
        lmid:0,
        isActive: false,
        anlidata:[],
        newsdata:[],
        a:[],
        b:[],
        isSelect:false,
        initnum:0

      }
    },
    methods:{
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
              // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lmdata = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                 that.lmdata = newData[8]
                 that.lmname = newData[8]['name']
                 newData[8]['child'].forEach(function(val){

                    if(val['id'] == that.lmid){
                        that.nowname = val['name']
                    }
                 })
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getanliData(){
        let that = this
        request({
          url: '/lingyu/lyanli?id=67',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.anlidata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.anlidata = jsondata['data'];
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getnewsData(){
        let that = this
        request({
          url: '/lingyu/lynews?id=63',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            console.log(jsondata);
            if(jsondata['code'] == 200){
              that.newsdata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data']
                newData.forEach(function(val){
                  val['create_time'] = val['create_time'].split(' ')[0]
                  that.newsdata.push(val)
                });
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getlitinfo(id){
        let that = this
        request({
          url: '/lingyu/read?id='+id,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lanmuname = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                switch(id){
                  case 170:
                  that.a = jsondata['data']
                  break;
                  case 171:
                  that.b = jsondata['data']
                  break;
                }
              }
            }
          }]
        })
      }
    },
    watch:{
      newsdata(){

      }
    },
    created() {

    },
    mounted(){
      let that = this
      this.getlmData()
      this.getanliData()
      this.getnewsData()
      this.getlitinfo(170)
      this.getlitinfo(171)
      //获取id
      let lanmuid = this.$route.query['id']
      if(lanmuid != undefined){
          that.lmid = lanmuid
          switch(lanmuid){
            case '170':
            that.initnum = 0
            break;
            case '171':
            that.initnum = 1
            break;
          }
          // alert($('.yewuwrap').offset().top)
          $('body,html').animate({
                  scrollTop: $('.yewurun').offset().top
          },500);
      }else{
        that.initnum = 0
      }
      // console.log(this.$route.name);
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'shangshi'){
          $(".chonggou a[href$='yewu']").attr('class','router-link-active')
        }
      })


      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      let islock = false;
      let yewuintrowraph = $('.yewuintrowraph')
      let morelink = $('.yewuintrol .morelink')
      morelink.click(function(){
        if(islock == false){
          islock = true
          $('.yewuintrowrap').animate({
            height: yewuintrowraph.height()
          },500,function(){
            morelink.html('收起更多>')
          })

        }else{
          islock = false
          $('.yewuintrowrap').animate({
            height: '268px'
          },500,function(){
            morelink.html('查看更多>')
          })

        }
      })



      setTimeout(function(){
        // alert(that.initialSlide)
        var swiper = new Swiper(".mySwiper", {
          spaceBetween: 10,
          slidesPerView: 9,
          // slidesPerView: "auto",
          freeMode: true,
          watchSlidesProgress: false,
        });
        var swiper2 = new Swiper(".mySwiper2", {
          spaceBetween: 0,
          slidesPerView: 1,
          initialSlide : that.initnum,//默认第三页
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          thumbs: {
            swiper: swiper,
          },
        });
      },800)


    }
  }
</script>

<style scoped="scoped" lang="scss">
  .yewuinfo{

    .yewuwrap{

      .yewuintro{
        display: flex;
        justify-content: space-between;
        .yewuintrol{
          width: 810px;
          h2{
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            position: relative;
            padding-left: 18px;
            line-height: 100%;
            margin-top: 40px;
            margin-bottom: 10px;
          }
          h2::before{
            content: "";
            width: 8px;
            height: 20px;
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: -9px;
            background-color: #b80816;

          }
          .yewuintrowrap{
            height: 268px;
            overflow: hidden;
          }
          p{
            font-size: 18px;
            color: #666666;
            text-indent: 2em;
            line-height: 28px;
            strong{
              font-weight: bold;
              color: #333;
            }
          }
          p:nth-of-type(3){
            margin-top: 12px;
          }
          a{
            margin-right: 0;
          }
        }
        .yewuintror{
          margin-top: 40px;
          position: relative;
          cursor: pointer;
          strong{
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 58px;
            color: #fff;
            width: 114px;
            border-bottom: 3px solid #fff;
            text-align: center;
            left: 50%;
            margin-left: -57px;
            padding-bottom: 5px;
            transition: all .3s linear 0s;
            a,a:hover{
              color: #fff!important;
            }
          }
        }
        .yewuintror:Hover strong{
          transform: scale(1.1);
          top: 55px;
        }
      }
    }
    .yewurun{
      height: 492px;
      margin-top: 60px;
      min-width: 1200px;
      background: url(../../../assets/yewurunbg.jpg) no-repeat center;
      overflow: hidden;
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        color: #fff;
        margin-top: 60px;
        line-height: 100%;
        margin-bottom: 40px;
      }
      .yewurunbox{
        position: relative;
        .swiper{
          width: 1100px;
          margin: 0 auto;
        }
        .mySwiper{
          // overflow: hidden;
          .swiper-wrapper{
            display: flex;
            flex-wrap: wrap;
          }
          .swiper-slide:nth-child(9){
            margin-right: 0 !important;
          }
          .swiper-slide::after{
            content: "";
            width: 20px;
            height: 20px;
            background-color: #fff;
            position: absolute;
            bottom: -35px;
            left: 50%;
            margin-left: -10px;
            transform: rotate(45deg);
            opacity: 0;
            transition: all .2s linear 0s;
          }
          .swiper-slide{
            position: relative;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            padding: 0 15px;
            white-space: nowrap;
            width: auto !important;
            height: 40px;
            background: rgba(255,255,255,.2);
            text-align: center;
            line-height: 40px;
            transition: all .3s linear 0s;
            margin-top: 10px;
          }
          .swiper-slide-thumb-active{
            background: #b80816;
          }
          .swiper-slide-thumb-active::after{
            opacity: 1;
          }
        }
        .mySwiper2{
          margin-top: 25px;
          overflow: hidden;
          .swiper-button-next, .swiper-button-prev{
            top: 62%;
            background-repeat: no-repeat;
            background-position: center;
          }
          .swiper-button-next{
            background-image: url(../../../assets/right.png);
          }
          .swiper-button-prev{
            background-image: url(../../../assets/left.png);
          }
          .swiper-button-next:Hover{
            background-image: url(../../../assets/right-s.png);
          }
          .swiper-button-prev:hover{
            background-image: url(../../../assets/left-s.png);
          }
          .swiper-button-next:after, .swiper-button-prev:after{
           content: "";
          }

          .swiper-slide{
            background: #fff;
            padding-bottom: 30px;
            .swiperbox{
              padding: 0 54px;
              h3{
                font-size: 20px;
                color: #414141;
                line-height: 100%;
                padding: 30px 0 22px 0;
                border-bottom: 1px solid #dfdfdf;
                margin-bottom: 18px;
              }
              p{
                line-height: 28px;
                font-size: 18px;
              }
            }
          }
        }
      }
    }
    .jdal{
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      .jdalwrap{
        position: relative;
        img{
          position: absolute;
          top: 51px;
          left: 615px;
          z-index: -1;
        }
        .jdalwrapbox::before{
          content: "";
          height: 35px;
          width: 16px;
          background-color: #b80816;
          position: absolute;
          top: 0;
          left: 28px;
        }
        .jdalwrapbox{
          padding-bottom: 42px;
          position: relative;
          width: 762px;
          box-shadow: 0 0 8px #d9d9d9;
          overflow: hidden;
          background: #fff;
          height: 470px;
          ul{
            margin-top: 28px;
            margin-left: 72px;
            width: 618px;

            li:before{
              content: "";
              width: 5px;
              height: 5px;
              background: #666666;
              position: absolute;
              left: 0;
              top: 50%;
              margin-top: -2.5px;

            }
            li:hover::before{
              background-color: #b80816;
            }
            li:hover{
              background-image: url(../../../assets/linebg-s.png);
            }
            li{
              position: relative;
              padding-bottom: 17px;
              padding-top: 17px;
              border-bottom: 1px solid #eaeaea;
              padding-left: 15px;
              line-height: 20px;
              background: url(../../../assets/linebg.png) no-repeat 594px center;
              a{
                font-size: 18px;
                color: #666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                padding-right: 50px;
              }
            }
          }
        }
        .morelink{
          margin-right: 70px;
        }

      }

    }
    .aboutnew{

      margin-top: 89px;
      background: url(../../../assets/yewunewbg.jpg) no-repeat top center;
      .aboutnewwrap{
        position: relative;
        overflow: hidden;
        height: 533px;
        strong{
          font-size: 30px;
          color: #fff;
          display: block;
          line-height: 100%;
          text-align: center;
          margin-top: 45px;
          margin-bottom: 36px;
        }
        .aboutnewbox{
          background: #fff;
          height: 420px;
          width: 100%;
          position: absolute;
          top: 110px;

          .aboutnewzw{
            display: flex;
          }
          ul{
            width: 618px;
            box-shadow: 0 0 8px #b5b5b5;
            padding: 30px 45px;
            li:hover{
              background-image: url(../../../assets/newicon-s.jpg);
            }
            li{
              height: 56px;
              border-bottom: 1px solid #eaeaea;
              line-height: 56px;
              display: flex;
              justify-content: space-between;
              background: url(../../../assets/newicon.jpg) no-repeat 3px center;
              padding-left: 31px;
              a{
                font-size: 18px;
                color: #666666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 75%;
              }
              span{
                font-size: 16px;
                color: #666666;
              }
            }
          }
        }
        .morelink{
          position: absolute;
          bottom: 35px;
          right: 0;
          margin-right: 45px;
        }
      }
    }
    .yewuline{
      margin-top: 50px;
    }
  }
</style>
