<template>
  <div class="yangshiinfo">
    <div class="ban"></div>
    <div class="yangshiinfobox w1200">
      <div class="yangshiinfowrap"  v-loading="loading" :element-loading-text="loadtext">
        <div class="minabao">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <router-link :to="{ path: '/' }">首页 ＞</router-link>

            <router-link class="huifumoren" :to="{path: '/newslist'}" @click="setzb">冠领新闻 ＞</router-link>

            <router-link :to="{path:'/newslist'}" v-show="tabname">{{tabname}} ＞</router-link>


            <router-link :to="{path:'/newslist'}">{{lmname}}</router-link>

          </el-breadcrumb>
        </div>
        <h2 class="yangshititle">{{arcTitle}}</h2>
        <div class="yangshitype">
          <div>文章来源： 北京冠领律师事务所</div>
          <!-- <div>阅读：{{readCount}}</div> -->
          <div>发布时间： {{createTime}}</div>
          <div>字体： 【<em @click="bigfont('big')">大</em> <em @click="bigfont('cur')">中</em> <em @click="bigfont('lit')">小</em>】</div>
        </div>
        <div class="yangshicontent">
          <div v-html="content" class="vhtml"></div>
          <!-- <div class="biaoqian">标签： 拆迁 民事 拆迁 民事 拆迁 民事 拆迁 民事</div> -->
        </div>

        <div class="prenext" v-if="ispre == 'k'">
          <span>上一篇：没有了</span>
           <router-link :to="{path: '/'+arcpath+'/'+nextArc['id']+'.html'}" :title="nextArc['title']">下一篇：{{nextArc['title']}}</router-link>
        </div>
        <div class="prenext" v-else-if="isnext == 'k'">
          <router-link :to="{path: '/'+arcpath+'/'+preArc['id']+'.html'}" :title="preArc['title']">上一篇：{{preArc['title']}}</router-link>
           <span>下一篇：没有了</span>
        </div>
        <div class="prenext" v-else>
          <router-link :to="{path: '/'+arcpath+'/'+preArc['id']+'.html'}" :title="preArc['title']">上一篇：{{preArc['title']}}</router-link>
           <router-link :to="{path: '/'+arcpath+'/'+nextArc['id']+'.html'}" :title="nextArc['title']">下一篇：{{nextArc['title']}}</router-link>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  export default {
    name: 'NewsarcView',
    data(){
      return {
        breadcrumbList:[],
        currentArcId:1,
        arcTitle:null,
        readCount:0,
        createTime:0,
        content:'',
        nextArc:[],
        preArc:[],
        loadtext: '数据加载中...',
        loading: false,
        arcpath:'',
        ispre:'',
        isnext:'',
        catid:0,
        alsuoshu:'',
        lmname:'',
        tabname:''

      }
    },
    methods:{

        bigfont(val){
          let yangshiem = $('.yangshitype em')
          let yangshicontent = $('.yangshicontent p')
          let yangshicontentspan = $('.yangshicontent p span')
          let yangshiimg = $('.yangshicontent img')
          yangshiem.css('color','#666666')
          // yangshiimg.css('height','auto')
          if(val == 'big'){
            yangshiem.eq(0).css('color','#b80816')
            yangshicontent.animate({'font-size':'18px'})
            yangshicontentspan.animate({'font-size':'18px'})
            yangshiimg.css('width','57%')
          }
          if(val == 'cur'){
            yangshiem.eq(1).css('color','#b80816')
            yangshicontent.animate({'font-size':'16px'})
            yangshicontentspan.animate({'font-size':'16px'})
            yangshiimg.css('width','50%')
          }
          if(val == 'lit'){
            yangshiem.eq(2).css('color','#b80816')
            yangshicontent.animate({'font-size':'14px'})
            yangshicontentspan.animate({'font-size':'14px'})
            yangshiimg.css('width','43%')
          }
        },
        setzb(){
          localStorage.setItem('jigoupage',1)
          localStorage.setItem("tabname", "冠领总部新闻")
          console.log(localStorage.getItem('jigoupage'));
        },
        // 获取上下篇
        getSX(id,path,catid,alsuoshu){
          let that = this
          let urls = ''
          if(path == 'anli'){
            urls = '/'+path+'/'+path+'next?id='+id +'&catid='+catid+'&alsuoshu='+alsuoshu
          }else{
            urls = '/'+path+'/'+path+'next?id='+id +'&catid='+catid
          }
          request({
            url: urls,
            responseType: 'json',
            transformResponse:[function(data){
              let jsondata = JSON.parse(data)
              // console.log(jsondata);
              if(jsondata['code'] == 200){
                that.ispre = ''
                that.isnext = ''
                if(jsondata['data']['up'] == null){
                  that.ispre = 'k'
                  that.nextArc = jsondata['data']['down']
                }else if(jsondata['data']['down'] == null){
                  that.isnext = 'k'
                  that.preArc = jsondata['data']['up']
                }else{
                  that.preArc = jsondata['data']['up']
                  that.nextArc = jsondata['data']['down']
                }
              }
            }]
          })
        },
        getArc(){
          let meta = this.$route.meta;
          let that = this
          let arcid = that.$route.params.id.split('.')
          that.currentArcId = arcid[0]
          // alert(that.currentArcId)

          let pathdiy = that.$route.path.split('/')[1]
          that.arcpath = pathdiy
          let sx = ''
          // console.log(pathdiy);
          let sendpath = ''
          switch(pathdiy){

            case 'newslist':
            sx = 'news'
            sendpath = '/news/newslist?id='
            break;

          }
          that.loading = true
          that.loadtext = '数据加载中...'
          request({
            url: sendpath+that.currentArcId,
            responseType: 'json',
            transformResponse:[function(data){
              let jsondata = JSON.parse(data)
              console.log(jsondata);
              if(jsondata['code'] == 200){
                // return jsondata
                // console.log(jsondata['data'])
              that.loading = false
              that.arcTitle = jsondata['data']['title']
              that.readCount = jsondata['data']['count']
              that.createTime = jsondata['data']['create_time']
              that.catid = jsondata['data']['catid']
              that.alsuoshu = jsondata['data']['alsuoshu']
              that.alsuoshu = jsondata['data']['alsuoshu']
              //针对律师单独做判断
              if(sx == 'team'){

                that.content= jsondata['data']['content']
                // $('.vhtml img').hide()
              }else{
                that.content= jsondata['data']['content'].replace(/\s(src=")/g, " $1http://api.guanlingms.com")
              }
              that.getSX(that.currentArcId,sx,that.catid,that.alsuoshu)
              that.getlanmu()
              }
            }]
          })
        },
        getlanmu(){
          let that = this
          request({
            url: '/Category/read?id='+that.catid,
            responseType: 'json',
            transformResponse:[function(data){
              let jsondata = JSON.parse(data)
              // console.log(jsondata);
              if(jsondata['code'] == 200){
                that.lmname = jsondata['data']['name']
              }
            }]
          })
        }
    },
    watch:{
      $route(to, from){
       this.getArc()
      }
    },
    mounted(){
      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }
      let tname = localStorage.getItem("tabname")
      if(tname == '冠领机构新闻' || tname == '业务相关新闻'){
        this.tabname = tname
      }


      this.getArc()

      $('.huifumoren').click(function(){
        // alert('aaaa')
         localStorage.setItem("tabname", '冠领总部新闻')
         localStorage.setItem("zbpage", 1)
         localStorage.setItem("otherpage", 1)
         // localStorage.clear();
      })

      this.$nextTick(function(){

        $(".chonggou a").attr('class','')
        if(this.$route.name == 'casehtml'){
          $(".chonggou a[href$='/case']").attr('class','router-link-active')
        }
        if(this.$route.name == 'noticehtml'){
          $(".chonggou a[href$='/notice']").attr('class','router-link-active')
        }
        if(this.$route.name == 'lawyerhtml'){
          $(".chonggou a[href$='/lawyer']").attr('class','router-link-active')
        }
        if(this.$route.name == 'newslisthtml'){
          $(".chonggou a[href$='/newslist']").attr('class','router-link-active')
        }
        if(this.$route.name == 'honorhtml'){
          $(".chonggou a[href$='/honor']").attr('class','router-link-active')
        }

        if(this.$route.name == 'abouthtml'){
          $(".chonggou a[href$='/about/1497.html']").attr('class','router-link-active')
        }
      })



    }
  }
</script>


<style lang="scss" scoped="scoped">

  .prenext{
    display: flex;
    justify-content: space-between;
    font-size: 18px;
    height: 45px;
    align-items: center;
    border-top: 1px dashed #e5e5e5;
    margin: 0 auto;
    width: 1080px;
  }
  .prenext a{
    color: #666666;
    display: block;
    white-space: nowrap;
    width: 45%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .yangshiinfo{
    .ban{
      background-image: url(../assets/shipininfoimg.jpg);
    }
    .yangshiinfobox{
      background: #fff;
      .yangshiinfowrap{
        position: relative;
        width: 100%;
        background: #fff;
        margin-top: -218px;
        z-index: 99;
        box-shadow: 0 0 8px #dfdddd;
        padding-bottom: 30px;
        border: 1px solid transparent;
        .minabao{
          margin: 30px 60px 0;
          padding-bottom: 20px;
        }
        h2.yangshititle{
          text-align: center;
          margin-top: 35px;
          font-size: 20px;
        }
        .yangshitype{
          display: flex;
          border-bottom: 1px dashed #e5e5e5;
          font-size: 16px;
          color: #666666;
          margin: 30px 40px 0;
          padding-bottom: 14px;
          justify-content: center;
          margin-bottom: 26px;
          div:last-child{
            margin-right: 0;
          }
          div{
            margin-right: 50px;
            em{
               cursor: pointer;
               padding: 0 5px;
            }
            em:nth-child(2){
              color: #b80816;
            }
          }
        }

        .yangshicontent{
          margin: 0 60px;
          padding-bottom: 10px;

          span{
            font-size: 16px;
          }
          p{
            font-size: 16px !important;
            color: #666666;
            line-height: 27px;
            text-indent: 2em;
            margin-bottom: 18px;


          }
          .biaoqian{
            padding: 20px 0 25px;
            color: #666;
            font-size: 16px;
          }

        }
      }
    }
  }
</style>
