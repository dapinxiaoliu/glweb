<template>
  <div class="notice">
    <div class="comban">
      <img src="../assets/newsban.jpg" >
      <div>
        <strong>冠领公告</strong><p>全球咨询热线：400-8789-888</p>
      </div>
    </div>
    <div class="noticewrap">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item>冠领公告</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="noticebox">
        <div class="noticebtn m20">
          <button class="f" @click="getData(48)">委托公告</button>
          <button @click="getData(1)">开庭公告</button>
          <button @click="getData(2)">办案公告</button>
        </div>
        <div class="noticelist m20">
          <ul>
          	<li v-for="item,index in noticeData" :key=index><router-link :to="{path:'/notice/'+ item.id +'.html'}">
              <p>
                <span v-if="item.leibie == 1">民商</span>
                <span v-else-if="item.leibie == 2">行政</span>
                <span v-else>无</span>
                {{item.title}}
              </p>
              <div><span>{{item.create_time}}</span><span>{{item.count}}</span></div>
            </router-link></li>
          </ul>
          <div class="page">
            <el-pagination
              background
              @current-change='compage'
              current-page=1
              layout="prev, pager, next"
              prev-text="上一页"
              next-text="下一页"
              pager-count= 5
              :page-count='lastPage'
              :key='lmid'>
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {request} from '../network/request.js'
  import GLOBAL from '../global/global.js'
  import $ from 'jquery'
  export default {
    name:'Notice',
    data(){
      return {
        noticeData:[],
        pageSize:10,
        lmid:0,
        lastPage:0
      }
    },
    methods:{
      getData(id){

        this.getNotice(id)
      },
      getNotice(id){
        let that = this
        that.lmid = id
        $('.noticelist li p span').hide()
        if(id == 1){
          $('.noticelist li p span').show()
        }

        request({
          url: '/gonggao/read?id='+id+'&page=1&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            console.log(jsondata);
            if(jsondata['code'] == 200){
            // alert(jsondata['data']['total'])
              that.noticeData = []
              if(jsondata['data']['total'] == 0){
                that.loading = false
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let riqi = val['create_time'].split(' ')
                    val['create_time'] = riqi[0]
                    that.noticeData.push(val)
                });
                that.lastPage = newData['last_page']

              }
            }
          }]
        })
      },
      compage(val){
        let that = this
        request({
          url: '/gonggao/read?id='+that.lmid+'&page='+val+'&page_size='+that.pageSize,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.noticeData = []
              if(jsondata['data']['total'] == 0){
                that.loading = false
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                newData['data'].forEach(function(val){
                    that.loading = false
                    let riqi = val['create_time'].split(' ')
                    val['create_time'] = riqi[0]
                    that.noticeData.push(val)
                });
                that.lastPage = newData['last_page']

              }
            }
          }]
        })
      }
    },
    mounted() {
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'notice'){
          $(".chonggou a[href$='/notice']").attr('class','router-link-active')
        }
      })

      let noticebtn = $('.noticebtn button')
      noticebtn.click(function(){
        $(this).addClass('f').siblings().removeClass('f')
        $('.noticelist ul').hide(0,function(){
           $('.noticelist ul').fadeIn()
        })
      })

      this.getData(1)
    }
  }
</script>

<style lang="scss" scoped="scoped">
  .notice{
    .f{
      color: #fff !important;
      background: #b80816 !important;
    }
    .comban{
      div{
        color: #333;
      }
    }
    .noticewrap{
      .noticebox{
        .noticebtn{
          display: flex;
          justify-content: space-between;
          margin-top: .25rem;
          margin-bottom: .3rem;
          button{
            height: .58rem;
            width: 2.24rem;
            background: #eeeeee;
            color: #666666;
            text-align: center;
            line-height: .58rem;
            cursor: pointer;
            font-size: .28rem;
          }
        }
        .noticelist{
          ul{
            margin-bottom: .25rem;
            li:first-child{
              border-top: 1px solid #dddddd;
            }
            li{
              height: 1.54rem;
              border-bottom: 1px dashed #dddddd;
               position: relative;
               overflow: hidden;
              a{

                p{
                  font-size: .28rem;
                  color: #333;
                  line-height: .36rem;
                  margin-top: .2rem;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-box-orient: vertical;
                  -webkit-line-clamp: 2;
                  overflow: hidden;
                  position: relative;
                  span{
                    width: .8rem;
                    position: relative;
                    color: #999;
                    padding-right: .18rem;

                    display: none;
                  }
                  span::after{
                    content: "";
                    width: 1px;
                    height: .28rem;
                    background: #333;
                    position: absolute;
                    right: .03rem;
                    top: .05rem;
                  }
                }
                div{
                  position: absolute;
                  bottom: .16rem;
                  span{
                    font-size: .26rem;
                    color: #999;
                    background-repeat: no-repeat;
                    background-position: left center;
                    display: inline-block;
                    text-indent: .28rem;
                  }
                  span:first-child{
                    background-image: url(../assets/riqi.png);
                    background-size: .19rem;
                    margin-right: .65rem;
                  }
                  span:last-child{
                    background-image: url(../assets/yan.png);
                    background-size: .2rem .16rem;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
</style>
