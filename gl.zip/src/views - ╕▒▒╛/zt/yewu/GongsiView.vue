<template>
  <div class="yewuinfo">
    <div class="linebanbox">
      <img src="../../../assets/yewuinfoline.jpg" class="autoc">
      <div class="linebanhead">
        <strong>公司业务</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="yewuwrap w1200">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
          <el-breadcrumb-item>{{nowname}}</el-breadcrumb-item>

        </el-breadcrumb>
      </div>
      <div class="yewuintro">
        <div class="yewuintrol">
          <h2>公司业务</h2>
          <div class="yewuintrowrap">
            <div class="yewuintrowraph">

            <p>北京冠领律师事务所公司业务主要包括法律风险防范，优化公司制度，化解经营或法律危机，企业拆迁纠纷等其他法律服务，在实务中公司相关业务涉及诉讼和非诉两种。</p>
            <p>公司业务是商事业务的主体，体量非常之大，包括了股权收购、股权激励、公司控制权、公司治理纠纷、设立新公司等。主要包括因股东与股东之间纠纷引发的公司业务诉讼、股东与公司之间纠纷引发的公司业务诉讼、公司或股东与公司高级管理人员之间纠纷引发的公司业务诉讼，也包括公司债权人基于与公司的债权而对公司股东、公司高级管理人员提起的公司股东和高级管理人员损害公司债权人利益的公司业务诉讼。</p>
            <p>具体来看，公司业务主要包含以下几部分：</p>
            <p>第一，公司业务参与起草、审核公司规定制度，协助公司逐步建立和完善内部管理制度。实现管理权限合法、管理内容合法、管理手段合法；确保制度既符合国家经济体制的大环境，又与公司内部实际情况相符，具有可操作性；各项制度在内容上避免相互冲突或遗漏，在公司业务批准和发布程序上保持统一性和合法有效。</p>
            <p>第二，协助公司行政部门做好公司内部、分支机构的设立与管理。公司业务对公司内部的行政人员的工作进行指导；定期对公司职员进行民法典、劳动法等法律知识培训，协助公司对职员进行法制教育；根据公司的需要进驻公司单位，对公司业务和管理进行全程跟踪，提供全程的法律服务。</p>
            <p>第三，公司业务参与公司重大经营决策，结合公司经营实际，及时为公司重大决策提供动态法律咨询服务。定期提供与公司经营活动有关的法律信息，确保决策有可靠的法律依据，避免决策的法律风险；促使公司在经济活动中的合法权益最大化；论证决策在法律上的最佳方案，使决策目标更容易实现；参与公司重大经济项目的谈判，包括涉外经济项目的谈判，协助关键性文件的谈判和起草、审核、把关。</p>
            <p>第四，公司业务包含起草、审查各类经济合同，经济合同相关管理工作。建立完善的合同管理制度，从合同会签的流程、签订权限的授予到格式文本的制作、合同专用章的管理、合同登记与台账管理、合同履行监督与统计报表等作出详细规定，保障和促进各项经济活动的顺利进行；根据具体经营业务需要，起草或填制重要合同文本，审查合同条款，排除法律障碍，最大限度地反映公司的经营意志，降低和避免法律风险；及时解决合同履行过程中出现的争议，做好合同变更、补充或解除手续。</p>
            <p>第五，公司的劳动合同、劳资关系管理。公司业务包括对各类劳动合同文本的制作，劳动关系分类协调，协助人事部门及时做好劳动合同续订和解聘的相关法律工作；起草、制订员工竞业禁止协议和商业秘密保护协议以及相关内部规章制度；协助人力资源部门和财务部门做好相关人员的离任审计工作；协调各类劳动争议，及时解决劳动争议，根据专项委托处理各类劳动仲裁和劳动诉讼事务；及时提供最新的相关法律法规规章和相关信息，会同人力资源部培训员工，进行法制教育和法律知识传授。</p>
            <p>第六，配合公司的经营进展，提供资本运作相关的法律服务根据公司专项委托，做好公司收购、兼并、上市、招投标、项目融资、资产重组等专项公司业务法律事务。</p>
            <p>第七，公司商标、专利、商业秘密等知识产权管理熟练运用知识产权的专有性、地域性、时间性的特点，为公司的知识产权保护提供动态的保护和依法管理策略，指导公司商业秘密管理工作。</p>
            <p>第八，根据公司专项委托，通过协商、调解等方式，代理公司解决专项法律纠纷，必要时提起诉讼或仲裁程序。对于已被起诉的诉讼案件，根据公司专项委托应诉。对于非诉案件，接受公司委托对外进行协商、调解。</p>
            <p>第九，其他为完成公司法律事务所必需的法律事务工作根据公司经营与发展需要，向公司提供随时随地的公司业务法律咨询，根据对最新法规和政策的准确把握，使公司在经营的各个环节做到合法化、规范化操作。</p>
            <p>公司业务咨询在北京冠领律师事务所是主要业务之一。在冠领，成功案例众多，专业性强，胜诉率高.公司业务法律咨询，冠领资深律师现场分析，深度解剖案情，定制专属胜诉方案。</p>
            <p>北京冠领律师事务所在周旭亮主任、任战敏执行主任的带领下，全国开设多家分所，办理近万件案件。北京冠领律师事务所坚持“以胜诉求共赢——法庭上争胜诉，法庭下谋共赢”的办案理念，以规模化、专业化、品牌化、国际化的优势，为当事人提供优质、高效的法律服务，赢得了企事业单位、社会组织、老百姓的广泛好评和持久信任。</p>

            </div>
          </div>

          <router-link to="" class="morelink">查看更多></router-link>
        </div>
        <div class="yewuintror">
          <router-link to="/lawyer/">
            <img src="../../../assets/yewuxgtd.jpg" >
            <strong><router-link to="/lawyer/">相关团队</router-link></strong>
          </router-link>
        </div>
      </div>

    </div>

    <div class="yewurun">
      <strong>公司业务</strong>
      <div class="yewurunbox w1200">
        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide swiperbtn" v-for="item,index in lmdata['child']" :key="index" >{{item.name}}</div>
          </div>
        </div>
        <div thumbsSlider="" class="swiper mySwiper2">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>法律顾问</h3>
               <p></p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>上市融资</h3>
                <p></p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>商业谈判</h3>
               <p></p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>重大商业决策法律意见书</h3>
                  <p>

                  </p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>风险防控</h3>
                <p></p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>起草修改合同</h3>
                <p></p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>劳动人事</h3>
                <p></p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>内部章程</h3>
                <p></p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>破产清算</h3>
                <p></p>
              </div>
            </div>

          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
    <!-- 经典案例 -->
    <div class="jdal w1200">
      <strong>经典案例</strong>
      <div class="jdalwrap">
        <div class="jdalwrapbox">
          <ul>
          	<li v-for="item,index in anlidata" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
          </ul>
          <router-link to="/case/" class="morelink">查看更多></router-link>
        </div>
        <img src="../../../assets/anliimg.jpg" >
      </div>
    </div>

    <!-- 相关新闻 -->
    <div class="aboutnew">
      <div class="aboutnewwrap w1200">
        <strong>相关新闻</strong>
        <div class="aboutnewbox">
          <div class="aboutnewzw">
            <div class="aboutnewl"><img src="../../../assets/newleft.jpg" ></div>
            <ul>
            	<li v-for="item,index in newsdata" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">{{item.title}}</router-link><span>{{item.create_time}}</span></li>
            </ul>
          </div>
          <router-link to="/newslist/" class="morelink">查看更多></router-link>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../../../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  import {request} from '../../../network/request.js'
  import GLOBAL from '../../../global/global.js'
  export default{
    name: 'GongsiView',
    data(){
      return{
        breadcrumbList:[],
        lmdata:[],
        lmname:'',
        nowname:'',
        lmid:0,
        isActive: false,
        anlidata:[],
        newsdata:[],
        a:[],
        b:[],
        c:[],
        d:[],
        e:[],
        f:[],
        g:[],
        h:[],
        i:[],
        isSelect:false,
        initnum:0

      }
    },
    methods:{
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)

            if(jsondata['code'] == 200){
              that.lmdata = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                 that.lmdata = newData[2]
                 that.lmname = newData[2]['name']
                // console.log(newData[0]);
                 newData[2]['child'].forEach(function(val){

                    if(val['id'] == that.lmid){
                        that.nowname = val['name']
                    }
                 })
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getanliData(){
        let that = this
        request({
          url: '/lingyu/lyanli?id=7',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.anlidata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.anlidata = jsondata['data'];
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getnewsData(){
        let that = this
        request({
          url: '/lingyu/lynews?id=57',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.newsdata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data']
                newData.forEach(function(val){
                  val['create_time'] = val['create_time'].split(' ')[0]
                  that.newsdata.push(val)
                });
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getlitinfo(id){
        let that = this
        request({
          url: '/lingyu/read?id='+id,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.lanmuname = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                switch(id){
                  case 105:
                  that.a = jsondata['data']
                  break;
                  case 106:
                  that.b = jsondata['data']
                  break;
                  case 107:
                  that.c = jsondata['data']
                  break;
                  case 108:
                  that.d = jsondata['data']
                  break;
                  case 109:
                  that.e = jsondata['data']
                  break;
                  case 110:
                  that.f = jsondata['data']
                  break;
                  case 111:
                  that.g = jsondata['data']
                  break;
                  case 112:
                  that.h = jsondata['data']
                  break;
                  case 113:
                  that.i = jsondata['data']
                  break;
                }
              }
            }
          }]
        })
      }
    },
    watch:{
      newsdata(){

      }
    },
    created() {

    },
    mounted(){
      let that = this
      this.getlmData()
      this.getanliData()
      this.getnewsData()
      this.getlitinfo(105)
      this.getlitinfo(106)
      this.getlitinfo(107)
      this.getlitinfo(108)
      this.getlitinfo(109)
      this.getlitinfo(110)
      this.getlitinfo(111)
      this.getlitinfo(112)
      this.getlitinfo(113)
      //获取id
      let lanmuid = this.$route.query['id']
      if(lanmuid != undefined){
          that.lmid = lanmuid
          switch(lanmuid){
            case '105':
            that.initnum = 0
            break;
            case '106':
            that.initnum = 1
            break;
            case '107':
            that.initnum = 2
            break;
            case '108':
            that.initnum = 3
            break;
            case '109':
            that.initnum = 4
            break;
            case '110':
            that.initnum = 5
            break;
            case '111':
            that.initnum = 6
            break;
            case '112':
            that.initnum = 7
            break;
            case '113':
            that.initnum = 8
            break;
          }
          // alert($('.yewuwrap').offset().top)
          $('body,html').animate({
                scrollTop: $('.yewurun').offset().top
          },500);
      }else{
        that.initnum = 0
      }
      // console.log(this.$route.name);
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        // alert(this.$route.name)
        if(this.$route.name == 'gongsi'){
          $(".chonggou a[href$='yewu']").attr('class','router-link-active')
        }
      })


      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      let islock = false;
      let yewuintrowraph = $('.yewuintrowraph')
      let morelink = $('.yewuintrol .morelink')
      morelink.click(function(){
        if(islock == false){
          islock = true
          $('.yewuintrowrap').animate({
            height: yewuintrowraph.height()
          },500,function(){
            morelink.html('收起更多>')
          })

        }else{
          islock = false
          $('.yewuintrowrap').animate({
            height: '268px'
          },500,function(){
            morelink.html('查看更多>')
          })

        }
      })



      setTimeout(function(){
        // alert(that.initialSlide)
        var swiper = new Swiper(".mySwiper", {
          spaceBetween: 10,
          slidesPerView: 9,
          // slidesPerView: "auto",
          freeMode: true,
          watchSlidesProgress: false,
        });
        var swiper2 = new Swiper(".mySwiper2", {
          spaceBetween: 0,
          slidesPerView: 1,
          initialSlide : that.initnum,//默认第三页
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          thumbs: {
            swiper: swiper,
          },
        });
      },800)


    }
  }
</script>

<style scoped="scoped" lang="scss">
  .yewuinfo{

    .yewuwrap{

      .yewuintro{
        display: flex;
        justify-content: space-between;
        .yewuintrol{
          width: 810px;
          h2{
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            position: relative;
            padding-left: 18px;
            line-height: 100%;
            margin-top: 40px;
            margin-bottom: 10px;
          }
          h2::before{
            content: "";
            width: 8px;
            height: 20px;
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: -9px;
            background-color: #b80816;

          }
          .yewuintrowrap{
            height: 268px;
            overflow: hidden;
          }
          p{
            font-size: 18px;
            color: #666666;
            text-indent: 2em;
            line-height: 28px;
            strong{
              font-weight: bold;
              color: #333;
            }
          }
          p:nth-of-type(3){
            margin-top: 12px;
          }
          a{
            margin-right: 0;
          }
        }
        .yewuintror{
          margin-top: 40px;
          position: relative;
          cursor: pointer;
          strong{
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 58px;
            color: #fff;
            width: 114px;
            border-bottom: 3px solid #fff;
            text-align: center;
            left: 50%;
            margin-left: -57px;
            padding-bottom: 5px;
            transition: all .3s linear 0s;
            a,a:hover{
              color: #fff!important;
            }
          }
        }
        .yewuintror:Hover strong{
          transform: scale(1.1);
          top: 55px;
        }
      }
    }
    .yewurun{
      height: 492px;
      margin-top: 60px;
      min-width: 1200px;
      background: url(../../../assets/yewurunbg.jpg) no-repeat center;
      overflow: hidden;
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        color: #fff;
        margin-top: 60px;
        line-height: 100%;
        margin-bottom: 40px;
      }
      .yewurunbox{
        position: relative;
        .swiper{
          width: 1100px;
          margin: 0 auto;
        }
        .mySwiper{
          // overflow: hidden;
          .swiper-wrapper{
            display: flex;
            flex-wrap: wrap;
          }
          .swiper-slide:nth-child(9){
            margin-right: 0 !important;
          }
          .swiper-slide::after{
            content: "";
            width: 20px;
            height: 20px;
            background-color: #fff;
            position: absolute;
            bottom: -35px;
            left: 50%;
            margin-left: -10px;
            transform: rotate(45deg);
            opacity: 0;
            transition: all .2s linear 0s;
          }
          .swiper-slide{
            position: relative;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            padding: 0 15px;
            white-space: nowrap;
            width: auto !important;
            height: 40px;
            background: rgba(255,255,255,.2);
            text-align: center;
            line-height: 40px;
            transition: all .3s linear 0s;
            margin-top: 10px;
          }
          .swiper-slide-thumb-active{
            background: #b80816;
          }
          .swiper-slide-thumb-active::after{
            opacity: 1;
          }
        }
        .mySwiper2{
          margin-top: 25px;
          overflow: hidden;
          .swiper-button-next, .swiper-button-prev{
            top: 62%;
            background-repeat: no-repeat;
            background-position: center;
          }
          .swiper-button-next{
            background-image: url(../../../assets/right.png);
          }
          .swiper-button-prev{
            background-image: url(../../../assets/left.png);
          }
          .swiper-button-next:Hover{
            background-image: url(../../../assets/right-s.png);
          }
          .swiper-button-prev:hover{
            background-image: url(../../../assets/left-s.png);
          }
          .swiper-button-next:after, .swiper-button-prev:after{
           content: "";
          }

          .swiper-slide{
            background: #fff;
            padding-bottom: 30px;
            .swiperbox{
              padding: 0 54px;
              h3{
                font-size: 20px;
                color: #414141;
                line-height: 100%;
                padding: 30px 0 22px 0;
                border-bottom: 1px solid #dfdfdf;
                margin-bottom: 18px;
              }
              p{
                line-height: 28px;
                font-size: 18px;
              }
            }
          }
        }
      }
    }
    .jdal{
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      .jdalwrap{
        position: relative;
        img{
          position: absolute;
          top: 51px;
          left: 615px;
          z-index: -1;
        }
        .jdalwrapbox::before{
          content: "";
          height: 35px;
          width: 16px;
          background-color: #b80816;
          position: absolute;
          top: 0;
          left: 28px;
        }
        .jdalwrapbox{
          padding-bottom: 42px;
          position: relative;
          width: 762px;
          box-shadow: 0 0 8px #d9d9d9;
          overflow: hidden;
          background: #fff;
          height: 470px;
          ul{
            margin-top: 28px;
            margin-left: 72px;
            width: 618px;

            li:before{
              content: "";
              width: 5px;
              height: 5px;
              background: #666666;
              position: absolute;
              left: 0;
              top: 50%;
              margin-top: -2.5px;

            }
            li:hover::before{
              background-color: #b80816;
            }
            li:hover{
              background-image: url(../../../assets/linebg-s.png);
            }
            li{
              position: relative;
              padding-bottom: 17px;
              padding-top: 17px;
              border-bottom: 1px solid #eaeaea;
              padding-left: 15px;
              line-height: 20px;
              background: url(../../../assets/linebg.png) no-repeat 594px center;
              a{
                font-size: 18px;
                color: #666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                padding-right: 50px;
              }
            }
          }
        }
        .morelink{
          margin-right: 70px;
        }

      }

    }
    .aboutnew{

      margin-top: 89px;
      background: url(../../../assets/yewunewbg.jpg) no-repeat top center;
      .aboutnewwrap{
        position: relative;
        overflow: hidden;
        height: 533px;
        strong{
          font-size: 30px;
          color: #fff;
          display: block;
          line-height: 100%;
          text-align: center;
          margin-top: 45px;
          margin-bottom: 36px;
        }
        .aboutnewbox{
          background: #fff;
          height: 420px;
          width: 100%;
          position: absolute;
          top: 110px;

          .aboutnewzw{
            display: flex;
          }
          ul{
            width: 618px;
            box-shadow: 0 0 8px #b5b5b5;
            padding: 30px 45px;
            li:hover{
              background-image: url(../../../assets/newicon-s.jpg);
            }
            li{
              height: 56px;
              border-bottom: 1px solid #eaeaea;
              line-height: 56px;
              display: flex;
              justify-content: space-between;
              background: url(../../../assets/newicon.jpg) no-repeat 3px center;
              padding-left: 31px;
              a{
                font-size: 18px;
                color: #666666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 75%;
              }
              span{
                font-size: 16px;
                color: #666666;
              }
            }
          }
        }
        .morelink{
          position: absolute;
          bottom: 35px;
          right: 0;
          margin-right: 45px;
        }
      }
    }
    .yewuline{
      margin-top: 50px;
    }
  }
</style>
