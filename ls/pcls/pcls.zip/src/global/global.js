const httpurl = 'http://api.guanlingls.com'

export default{
  httpurl
}