<template>
  <div class="yewuinfo">
    <div class="linebanbox">
      <img src="../../../assets/yewuinfoline.jpg" class="autoc">
      <div class="linebanhead">
        <strong>民事诉讼</strong>
        <small>全球咨询热线：400-8789-888</small>
      </div>
    </div>
    <div class="yewuwrap w1200">
      <div class="minabao">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>

          <el-breadcrumb-item v-for="item in breadcrumbList" :key="item.id" :to="{path: '/'+item.path}">{{item.name}}</el-breadcrumb-item>
          <el-breadcrumb-item>{{nowname}}</el-breadcrumb-item>

        </el-breadcrumb>
      </div>
      <div class="yewuintro">
        <div class="yewuintrol">
          <h2>民事诉讼</h2>
          <div class="yewuintrowrap">
            <div class="yewuintrowraph">

            <p>民事诉讼是诉讼的基本类型之一。北京冠领律师事务所办理各类民事诉讼案件经验丰富，尤其在婚姻家事、遗产继承、房产纠纷、合同纠纷、劳动纠纷等方面，冠领律所民事诉讼律师以“专业化+团队化”的服务，赢得当事人广泛好评和持久信任。</p>
            <p>民事诉讼，是指人民法院、当事人和其他诉讼参与人，在审理民事案件的过程中，所进行的各种诉讼活动，以及由这些活动所产生得各种关系的总和。诉讼参与人包括原告、被告、第三人、证人、鉴定人、勘验人等。</p>
            <p>民事诉讼有以下几点特性：</p>
            <p>1、公权性</p>
            <p>民事诉讼以司法方式解决平等主体之间的纠纷，是由法院代表国家行使审判权解决民事争议。</p>
            <p>2、强制性</p>
            <p>调解、仲裁均建立在当事人自愿的基础上，只要有一方不愿意选择上述方式解决争议，调解、仲裁就无从进行，民事诉讼则不同，只要原告起诉符合民事诉讼法规定的条件，无论被告是否愿意，诉讼均会发生。</p>
            <p>3、程序性</p>
            <p>民事诉讼是依照法定程序进行的诉讼活动，无论是法院还是当事人和其他诉讼参与人，都需要按照民事诉讼法设定的程序实施诉讼行为，违反诉讼程序常常会引起一定的法律后果。</p>
            <p>4、特定性</p>
            <p>民事诉讼解决的争议，是有关民事权利义务的争议。不是民事主体之间民事权益发生争议，不能纳入民事诉讼程序处理。</p>
            <p>提起民事诉讼程序的条件包含以下几点：</p>
            <p>（1）原告应具有民事行为能力。</p>
            <p>根据《民法典》规定，18周岁以上的公民是成年人，具有完全的民事行为能力；16周岁以上不满18周岁的公民，若以自己劳动收入为主要来源的，视为有完全民事行为能力的人，其有资格以自己的名义向法院提起诉讼；未成年人或精神病人属无行为能力人或限制行为能力的人，应由其法定监护人作为法定代理人代为诉讼。</p>
            <p>（2）原告是与本案有直接利害关系的公民、法人和其他组织。</p>
            <p>（3）有明确的被告。</p>
            <p>即原告必须指出被诉对象是谁，是某公民、某单位，还是某公司、企业。没有明确的被告，法律关系无法证实，人民法院也无从开始审判活动。</p>
            <p>（4）有明确的诉讼请求和事实理由。诉讼请求指当事人通过诉讼想要达到的目的。</p>
            <p>（5）向有管辖权的人民法院起诉。</p>
            <p>一般民事案件中，对法人或其他组织提起民事诉讼，由法人住所地人民法院管辖。同一诉讼的几个被告住所地或经常居住地在两个以上人民法院辖区，可向其中的任何一个辖区的法院起诉。</p>
            <p>对侵权行为，应向侵权行为地或者被告所在地法院起诉。因产品质量不合格造成他人财产、人身损害提起的诉讼，产品制造地、产品销售地、侵权行为地和被告住所地的人民法院都有管辖权。</p>
            <p>对铁路、公路、水上、航空运输和联合运输中发生的诉权，应向运输始发地、目的地或被告所在地法院起诉。因铁路、公路、水上和航空事故，请求损害赔偿诉讼，应向事故发生地或车辆、船舶最先到达地、航空器最先降落地或被告住所地法院起诉。</p>
            <p>因不动产提起的诉讼，应向不动产所在地法院起诉。</p>
            <p>（6）向法院提起民事诉讼的诉讼有效期为权利人在知道自己权力受到侵害起二年之内。</p>
            <p>（7）起诉应向人民法院递交诉状，并按被告人数提交副本.书写诉状确有困难的，可以口头起诉由人民法院记入笔录并告知对方当事人。</p>
            <p>民事诉讼涉及面广，实用性强，在社会生活发挥着重要作用。冠领律所已承办上千起疑难复杂民事案件，具有丰富的办案经验和娴熟的出庭技巧。为了给您一个好结果，每个案件我们都会全力以赴。</p>

            </div>
          </div>

          <router-link to="" class="morelink">查看更多></router-link>
        </div>
        <div class="yewuintror">
          <router-link to="/lawyer/">
            <img src="../../../assets/yewuxgtd.jpg" >
            <strong><router-link to="/lawyer/">相关团队</router-link></strong>
          </router-link>
        </div>
      </div>

    </div>

    <div class="yewurun">
      <strong>民事诉讼</strong>
      <div class="yewurunbox w1200">
        <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper ">
          <div class="swiper-wrapper">
            <div class="swiper-slide swiperbtn" v-for="item,index in lmdata['child']" :key="index">{{item.name}}</div>
          </div>
        </div>
        <div thumbsSlider="" class="swiper mySwiper2">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>婚姻家庭</h3>
               <p>{{hunyin['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>房产物权</h3>
                <p>{{fangchan['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>合同纠纷</h3>
               <p>{{hetong['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>劳动仲裁</h3>
                <p>{{laodong['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>侵权纠纷</h3>
                <p>{{qinquan['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>诉讼保全</h3>
                <p>{{susong['description']}}</p>
              </div>
            </div>
            <div class="swiper-slide">
              <div class="swiperbox">
                <h3>调解</h3>
                  <p>{{shenqing['description']}}</p>
              </div>
            </div>

          </div>
          <div class="swiper-button-next"></div>
          <div class="swiper-button-prev"></div>
        </div>
      </div>
    </div>
    <!-- 经典案例 -->
    <div class="jdal w1200">
      <strong>经典案例</strong>
      <div class="jdalwrap">
        <div class="jdalwrapbox">
          <ul>
          	<li v-for="item,index in anlidata" :key="index"><router-link :to="{path:'/case/'+item.id+'.html'}">{{item.title}}</router-link></li>
          </ul>
          <router-link to="/case/" class="morelink">查看更多></router-link>
        </div>
        <img src="../../../assets/anliimg.jpg" >
      </div>
    </div>

    <!-- 相关新闻 -->
    <div class="aboutnew">
      <div class="aboutnewwrap w1200">
        <strong>相关新闻</strong>
        <div class="aboutnewbox">
          <div class="aboutnewzw">
            <div class="aboutnewl"><img src="../../../assets/newleft.jpg" ></div>
            <ul>
            	<li v-for="item,index in newsdata" :key="index"><router-link :to="{path:'/newslist/'+item.id+'.html'}">{{item.title}}</router-link><span>{{item.create_time}}</span></li>
            </ul>
          </div>
          <router-link to="/newslist/" class="morelink">查看更多></router-link>
        </div>
      </div>
    </div>
    <div class="yewuline"><img src="../../../assets/yewuline.jpg" class="autoc"></div>
  </div>
</template>

<script>
  import $ from 'jquery'
  import Swiper from 'swiper'
  import "swiper/css/swiper.min.css"
  import {request} from '../../../network/request.js'
  import GLOBAL from '../../../global/global.js'
  export default{
    name: 'MinshiView',
    data(){
      return{
        breadcrumbList:[],
        lmdata:[],
        lmname:'',
        nowname:'',
        lmid:0,
        isActive: false,
        anlidata:[],
        newsdata:[],
        hunyin:[],
        fangchan:[],
        hetong:[],
        laodong:[],
        qinquan:[],
        susong:[],
        shenqing:[],
        isSelect:false,
        initnum:0

      }
    },
    methods:{
      getlmData(){
        let that = this
        request({
          url: '/Category/getcatelist?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)

            if(jsondata['code'] == 200){
              that.lmdata = []
              if(jsondata['data']['total'] == 0){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data'];
                 that.lmdata = newData[0]
                 that.lmname = newData[0]['name']
                // console.log(newData[0]);
                 newData[0]['child'].forEach(function(val){

                    if(val['id'] == that.lmid){
                        that.nowname = val['name']
                    }
                 })
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getanliData(){
        let that = this
        request({
          url: '/lingyu/lyanli?id=5',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            if(jsondata['code'] == 200){
              that.anlidata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                that.anlidata = jsondata['data'];
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getnewsData(){
        let that = this
        request({
          url: '/lingyu/lynews?id=55',
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            // console.log(jsondata);
            if(jsondata['code'] == 200){
              that.newsdata = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                let newData = jsondata['data']
                newData.forEach(function(val){
                  val['create_time'] = val['create_time'].split(' ')[0]
                  that.newsdata.push(val)
                });
                // that.newsdata = jsondata['data'];
                 // console.log(newData);
                 // console.log(newData[0]);
              }
            }
          }]
        })
      },
      getlitinfo(id){
        let that = this
        request({
          url: '/lingyu/read?id='+id,
          responseType: 'json',
          transformResponse:[function(data){
            let jsondata = JSON.parse(data)
            console.log(jsondata);
            if(jsondata['code'] == 200){
              that.lanmuname = []
              if(jsondata['msg'] == '无数据'){
                that.loadtext = '没有数据'
              }else{
                switch(id){
                  case 143:
                  that.hunyin = jsondata['data']
                  break;
                  case 144:
                  that.fangchan = jsondata['data']
                  break;
                  case 145:
                  that.hetong = jsondata['data']
                  break;
                  case 146:
                  that.laodong = jsondata['data']
                  break;
                  case 147:
                  that.qinquan = jsondata['data']
                  break;
                  case 148:
                  that.susong = jsondata['data']
                  break;
                  case 164:
                  that.shenqing = jsondata['data']
                  break;
                }
              }
            }
          }]
        })
      }
    },
    watch:{
      newsdata(){

      }
    },
    created() {

    },
    mounted(){
      let that = this

      // console.log(that);
      this.getlmData()
      this.getanliData()
      this.getnewsData()
      this.getlitinfo(143)
      this.getlitinfo(144)
      this.getlitinfo(145)
      this.getlitinfo(146)
      this.getlitinfo(147)
      this.getlitinfo(148)
      this.getlitinfo(164)
      //获取id
      let lanmuid = this.$route.query['id']
      if(lanmuid != undefined){
          that.lmid = lanmuid
          switch(lanmuid){
            case '143':
            that.initnum = 0
            break;
            case '144':
            that.initnum = 1
            break;
            case '145':
            that.initnum = 2
            break;
            case '146':
            that.initnum = 3
            break;
            case '147':
            that.initnum = 4
            break;
            case '148':
            that.initnum = 5
            break;
            case '164':
            that.initnum = 6
            break;
          }
          // alert($('.yewuwrap').offset().top)
          $('body,html').animate({
              scrollTop: $('.yewurun').offset().top
          },500);
      }else{
        that.initnum = 0
      }
      this.$nextTick(function(){
        $(".chonggou a").attr('class','')
        if(this.$route.name == 'minshi'){
          $(".chonggou a[href$='/yewu']").attr('class','router-link-active')
        }
      })


      let meta = this.$route.meta;
      if(meta && meta.parent){
        this.breadcrumbList = meta.parent
      }else{
        this.breadcrumbList = [{path: meta.path.split('/')[1], name: meta.name}]
      }

      let islock = false;
      let yewuintrowraph = $('.yewuintrowraph')
      let morelink = $('.yewuintrol .morelink')
      morelink.click(function(){
        if(islock == false){
          islock = true
          $('.yewuintrowrap').animate({
            height: yewuintrowraph.height()
          },500,function(){
            morelink.html('收起更多>')
          })

        }else{
          islock = false
          $('.yewuintrowrap').animate({
            height: '268px'
          },500,function(){
            morelink.html('查看更多>')
          })

        }
      })



      setTimeout(function(){
        // alert(that.initialSlide)
        var swiper = new Swiper(".mySwiper", {
          spaceBetween: 10,
          slidesPerView: 9,
          // slidesPerView: "auto",
          freeMode: true,
          watchSlidesProgress: false,
        });
        var swiper2 = new Swiper(".mySwiper2", {
          spaceBetween: 0,
          slidesPerView: 1,
          initialSlide : that.initnum,//默认第三页
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          thumbs: {
            swiper: swiper,
          },
        });
      },800)


    }
  }
</script>

<style scoped="scoped" lang="scss">
  .yewuinfo{

    .yewuwrap{

      .yewuintro{
        display: flex;
        justify-content: space-between;
        .yewuintrol{
          width: 810px;
          h2{
            font-size: 20px;
            font-weight: bold;
            color: #333333;
            position: relative;
            padding-left: 18px;
            line-height: 100%;
            margin-top: 40px;
            margin-bottom: 10px;
          }
          h2::before{
            content: "";
            width: 8px;
            height: 20px;
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: -9px;
            background-color: #b80816;

          }
          .yewuintrowrap{
            height: 268px;
            overflow: hidden;
          }
          p{
            font-size: 18px;
            color: #666666;
            text-indent: 2em;
            line-height: 28px;
            strong{
              font-weight: bold;
              color: #333;
            }
          }
          p:nth-of-type(3){
            margin-top: 12px;
          }
          a{
            margin-right: 0;
          }
        }
        .yewuintror{
          margin-top: 40px;
          position: relative;
          cursor: pointer;
          strong{
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 58px;
            color: #fff;
            width: 114px;
            border-bottom: 3px solid #fff;
            text-align: center;
            left: 50%;
            margin-left: -57px;
            padding-bottom: 5px;
            transition: all .3s linear 0s;
            a,a:hover{
              color: #fff!important;
            }
          }
        }
        .yewuintror:Hover strong{
          transform: scale(1.1);
          top: 55px;
        }
      }
    }
    .yewurun{
      height: 492px;
      margin-top: 60px;
      min-width: 1200px;
      background: url(../../../assets/yewurunbg.jpg) no-repeat center;
      overflow: hidden;
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        color: #fff;
        margin-top: 60px;
        line-height: 100%;
        margin-bottom: 40px;
      }
      .yewurunbox{
        position: relative;
        .swiper{
          width: 1100px;
          margin: 0 auto;
        }
        .mySwiper{
          // overflow: hidden;
          .swiper-wrapper{
            display: flex;
            flex-wrap: wrap;
          }
          .swiper-slide:nth-child(9){
            margin-right: 0 !important;
          }
          .swiper-slide::after{
            content: "";
            width: 20px;
            height: 20px;
            background-color: #fff;
            position: absolute;
            bottom: -35px;
            left: 50%;
            margin-left: -10px;
            transform: rotate(45deg);
            opacity: 0;
            transition: all .2s linear 0s;
          }
          .swiper-slide{
            position: relative;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            padding: 0 15px;
            white-space: nowrap;
            width: auto !important;
            height: 40px;
            background: rgba(255,255,255,.2);
            text-align: center;
            line-height: 40px;
            transition: all .3s linear 0s;
            margin-top: 10px;
          }
          .swiper-slide-thumb-active{
            background: #b80816;
          }
          .swiper-slide-thumb-active::after{
            opacity: 1;
          }
        }
        .mySwiper2{
          margin-top: 25px;
          overflow: hidden;
          .swiper-button-next, .swiper-button-prev{
            top: 62%;
            background-repeat: no-repeat;
            background-position: center;
          }
          .swiper-button-next{
            background-image: url(../../../assets/right.png);
          }
          .swiper-button-prev{
            background-image: url(../../../assets/left.png);
          }
          .swiper-button-next:Hover{
            background-image: url(../../../assets/right-s.png);
          }
          .swiper-button-prev:hover{
            background-image: url(../../../assets/left-s.png);
          }
          .swiper-button-next:after, .swiper-button-prev:after{
           content: "";
          }

          .swiper-slide{
            background: #fff;
            padding-bottom: 30px;
            .swiperbox{
              padding: 0 54px;
              h3{
                font-size: 20px;
                color: #414141;
                line-height: 100%;
                padding: 30px 0 22px 0;
                border-bottom: 1px solid #dfdfdf;
                margin-bottom: 18px;
              }
              p{
                line-height: 28px;
                font-size: 18px;
              }
            }
          }
        }
      }
    }
    .jdal{
      strong{
        font-size: 30px;
        display: block;
        text-align: center;
        line-height: 100%;
        margin-top: 60px;
        margin-bottom: 50px;
      }
      .jdalwrap{
        position: relative;
        img{
          position: absolute;
          top: 51px;
          left: 615px;
          z-index: -1;
        }
        .jdalwrapbox::before{
          content: "";
          height: 35px;
          width: 16px;
          background-color: #b80816;
          position: absolute;
          top: 0;
          left: 28px;
        }
        .jdalwrapbox{
          padding-bottom: 42px;
          position: relative;
          width: 762px;
          box-shadow: 0 0 8px #d9d9d9;
          overflow: hidden;
          background: #fff;
          ul{
            margin-top: 28px;
            margin-left: 72px;
            width: 618px;

            li:before{
              content: "";
              width: 5px;
              height: 5px;
              background: #666666;
              position: absolute;
              left: 0;
              top: 50%;
              margin-top: -2.5px;

            }
            li:hover::before{
              background-color: #b80816;
            }
            li:hover{
              background-image: url(../../../assets/linebg-s.png);
            }
            li{
              position: relative;
              padding-bottom: 17px;
              padding-top: 17px;
              border-bottom: 1px solid #eaeaea;
              padding-left: 15px;
              line-height: 20px;
              background: url(../../../assets/linebg.png) no-repeat 594px center;
              a{
                font-size: 18px;
                color: #666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                padding-right: 50px;
              }
            }
          }
        }
        .morelink{
          margin-right: 70px;
        }

      }

    }
    .aboutnew{

      margin-top: 89px;
      background: url(../../../assets/yewunewbg.jpg) no-repeat top center;
      .aboutnewwrap{
        position: relative;
        overflow: hidden;
        height: 533px;
        strong{
          font-size: 30px;
          color: #fff;
          display: block;
          line-height: 100%;
          text-align: center;
          margin-top: 45px;
          margin-bottom: 36px;
        }
        .aboutnewbox{
          background: #fff;
          height: 420px;
          width: 100%;
          position: absolute;
          top: 110px;

          .aboutnewzw{
            display: flex;
          }
          ul{
            width: 618px;
            box-shadow: 0 0 8px #b5b5b5;
            padding: 30px 45px;
            li:hover{
              background-image: url(../../../assets/newicon-s.jpg);
            }
            li{
              height: 56px;
              border-bottom: 1px solid #eaeaea;
              line-height: 56px;
              display: flex;
              justify-content: space-between;
              background: url(../../../assets/newicon.jpg) no-repeat 3px center;
              padding-left: 31px;
              a{
                font-size: 18px;
                color: #666666;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                width: 75%;
              }
              span{
                font-size: 16px;
                color: #666666;
              }
            }
          }
        }
        .morelink{
          position: absolute;
          bottom: 35px;
          right: 0;
          margin-right: 45px;
        }
      }
    }
    .yewuline{
      margin-top: 50px;
    }
  }
</style>
